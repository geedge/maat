#include "MESA_handle_logger.h"

#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void *sample_handle = NULL;
void *test_handle = NULL;

#define LOG_NUM 100000
#define MAX_THREAD_NUM 65535

int g_mode = 0;
int g_log_num = 0;
int g_thread_num = 0;
const char *g_zlog_conf = NULL;
volatile long g_start_time = 0;
volatile long g_end_time = 0;

void call_logger(int log_num, int thread_num)
{
		int i = 0;
		struct timespec start, end;
		long start_time, end_time, time_cost;
		clock_gettime(CLOCK_MONOTONIC, &start);
		start_time = start.tv_sec*1000000 + start.tv_nsec/1000;
		if(g_start_time == 0)
		{
			g_start_time = start_time;
		}	
		else
		{
			if(g_start_time > start_time)
			{
				g_start_time = start_time;
			}
		}	
		for(i = 0; i < log_num; i++)
		{
				MESA_handle_runtime_log(sample_handle, RLOG_LV_DEBUG, "sample", "sample_handle MESA_handle_runtime_log, i = %d, thread_num = %d", i, thread_num);
				//sleep(1);
				MESA_handle_runtime_log(test_handle, RLOG_LV_INFO, "test", "test_handle MESA_handle_runtime_log, i = %d, thread_num = %d", i, thread_num);
				//MESA_HANDLE_RUNTIME_LOG(sample_handle, RLOG_LV_FATAL, "sample", "sample_handle RUNTIEM_LOG test, i = %d, thread_num = %d", i, thread_num);
				//sleep(1);
				//MESA_HANDLE_RUNTIME_LOG(test_handle, RLOG_LV_FATAL, "test", "test_handle RUNTIEM_LOG test, i = %d, thread_num = %d", i, thread_num);
		}
		clock_gettime(CLOCK_MONOTONIC, &end);
		end_time = end.tv_sec*1000000 + end.tv_nsec/1000;
		if(g_end_time == 0)
		{
			g_end_time = end_time;
		}	
		else
		{
			if(g_end_time < end_time)
			{
				g_end_time = end_time;
			}
		}	
		time_cost = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_nsec - start.tv_nsec) / 1000 ;
		printf("THREAD %d write %d log using %ld us, avg speed %f /s, %ld -> %ld\n", thread_num, log_num, time_cost, ((float)log_num/(float)time_cost)*1000000, start_time, end_time);
		return;
}


void *thread_logger(void *arg)
{
		int thread_num = (int)(unsigned long long)arg;
		printf("thread %d created! \n", thread_num);
		call_logger(g_log_num, thread_num);
		printf("thread %d finished! \n", thread_num);
		return NULL;
}

void sig_int_handler(int sig)
{
		printf("ctrl+c recviced!\n");
		MESA_destroy_runtime_log_handle(sample_handle);
		MESA_destroy_runtime_log_handle(test_handle);
		sample_handle = NULL;
		test_handle = NULL;
		if (g_mode == 2)
		{
			MESA_handle_runtime_log_destruction();
		}
		printf("%d thread write %d log using %ld us, avg speed %f /s, %ld -> %ld\n", g_thread_num, g_thread_num * g_log_num, g_end_time - g_start_time, ((float)(g_thread_num * g_log_num) / (float)(g_end_time - g_start_time)) * 1000000, g_start_time, g_end_time);
		exit(0);
}

void sig_hup_handler(int sig)
{
	printf("SIGHUP recviced!\n");
	MESA_handle_runtime_log_reconstruction(g_zlog_conf);
}

int main(int argc, char ** args)
{
	pthread_t t[MAX_THREAD_NUM];
	int i = 0;

	if (argc != 5)
	{
		printf("Usage: ./($app) $mode[1 or 2] $zlog_conf_path $thread_num $log_num \n");
		return -1;
	}
	g_mode = atoi(args[1]);
	g_zlog_conf = args[2];
	g_thread_num = atoi(args[3]);
	g_log_num = atoi(args[4]);

	if(g_thread_num <= 0 || g_log_num <= 0)
	{
		printf("Error, wrong parameter!\n");
		return -1;
	}
	if (g_mode == 2)
	{
		if (0 != MESA_handle_runtime_log_creation(g_zlog_conf))
		{
			printf("MESA_handle_runtime_log_creation return error\n");
			return -1;
		}
	}
	sample_handle = MESA_create_runtime_log_handle("./log/sample_log", RLOG_LV_DEBUG);
	if (sample_handle == NULL)
	{
		printf("get log sample_handle error\n");
		return -1;
		}

		test_handle = MESA_create_runtime_log_handle("./log/test_log", RLOG_LV_DEBUG);
		if(test_handle == NULL)
		{
				printf("get log test_handle error\n");
				return -1;
		}

		for(i = 0; i < g_thread_num; i++)
		{	
				pthread_create(&t[i], NULL, thread_logger, (void *)(unsigned long)(i));
		}
		signal(SIGINT, sig_int_handler);
		signal(SIGHUP, sig_hup_handler);
		while(1)
		;
		//MESA_destroy_runtime_log_handle(sample_handle);
		//MESA_destroy_runtime_log_handle(test_handle);
		//sample_handle = NULL;
		//test_handle = NULL;
		return 0;
}
