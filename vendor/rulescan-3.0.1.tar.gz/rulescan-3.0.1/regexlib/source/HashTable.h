#ifndef H_HASH_TABLE_H
#define H_HASH_TABLE_H

#include "regex_def.h"

typedef struct	_hash_node_t{
	vector<int> state;
	int value;
	struct	_hash_node_t * next;
	struct	_hash_node_t * link;
}hash_node_t;

class hash_table
{
public:
	hash_table(unsigned int N=23);
	~hash_table();

	unsigned int hashing(const vector<int>& state);

	int put(unsigned int key, const vector<int>& state, int value);
	int get(unsigned int key, const vector<int>& state);
	const hash_node_t * get_next();

private:
	hash_node_t **	m_hash_table;
	unsigned int			m_hash_table_size;

	hash_node_t * m_F;
	hash_node_t * m_L;
};

#endif
