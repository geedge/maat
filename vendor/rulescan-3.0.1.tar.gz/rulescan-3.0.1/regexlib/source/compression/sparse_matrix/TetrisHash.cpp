/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#include "TetrisHash.h"
#include <set>
#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;

//#define DEBUG_TETRIS_HASH

_uint64_t Rand(_uint64_t a, _uint64_t b)
{
	double p=rand()/(RAND_MAX+1.0);
	return (_uint64_t)(a+(b-a)*p);
}

bool is_prime(_uint64_t n)
{
	if(n<2) return false;
	if(n==2) return true;
	if(n%2==0) return false;
	for(_uint64_t p=3; p*p<=n; p+=2)
	{
		if(n%p==0) return false;
	}
	return true;
}

inline _uint64_t fx(_uint64_t k, _uint64_t p, _uint64_t n, _uint64_t x)
{
	return ((k*x)%p)%(n*n);
}

CTetrisHash::CTetrisHash()
{
}

CTetrisHash::~CTetrisHash()
{
}

int CTetrisHash::PreProcessing(const set<_uint32_t>& keys)
{
	if(keys.size()==0) return -1;

	m_n=(_uint64_t)keys.size();
	m_n2=m_n*m_n;
	_uint64_t _max=*max_element(keys.begin(), keys.end());
	m_p = std::max(m_n2, _max)+1;
	while(!is_prime(m_p)) m_p++;

	m_uiTestK=1; 

#define MAX_TRY_NUM	10
	for(int k=0; k<MAX_TRY_NUM; k++)
	{
#ifdef DEBUG_TETRIS_HASH
		printf("iTryNum=%d.\n", k+1);
#endif

		if( !ComputeK(keys) ) return -1;

		if( ComputeRD(keys) )
		{
#ifdef DEBUG_TETRIS_HASH
			printf("p=%u, n=%u, k=%u.\n", (_uint32_t)m_p, (_uint32_t)m_n, (_uint32_t)m_k);
#endif
			int iMemBytes=(int)( 2*m_n*sizeof(_uint32_t)+5*sizeof(_uint64_t) );
			return iMemBytes;
		}
	}

	return -1;
}

bool CTetrisHash::ComputeK(const set<_uint32_t>& keys)
{
	//�Ƚ������ѡ�����δ�ɹ����ٽ���˳��������
	for(int i=0; i<100; i++)
	{
		m_k=(_uint32_t)Rand(1, m_p);
		if(TestK(keys)) return true;
	}

	//˳������
	for( ; m_uiTestK<m_p; m_uiTestK++)
	{
#ifdef DEBUG_TETRIS_HASH
		if(m_uiTestK%1000==1) printf("try K=%d.\n", (int)m_uiTestK);
#endif
		m_k=m_uiTestK;
		if(TestK(keys)) return true;
	}

	return false;
}

bool CTetrisHash::TestK(const set<_uint32_t>& keys)
{
	set<_uint64_t> KeySet;

	for(set<_uint32_t>::const_iterator pb=keys.begin(), pe=keys.end(); pb!=pe; ++pb)
	{
		_uint64_t _key=fx(m_k, m_p, m_n, *pb);
		if(KeySet.find(_key)!=KeySet.end()) return false;
		KeySet.insert(_key);
	}

	return true;
}

bool CTetrisHash::ComputeRD(const set<_uint32_t>& keys)
{
	m_rd.resize((int)m_n, -1);
	m_keys.resize((int)m_n, -1);
	vector<bool> flag((int)m_n, false);
	vector< vector<_uint32_t> > Rows((int)m_n);

	for(set<_uint32_t>::const_iterator pb=keys.begin(), pe=keys.end(); pb!=pe; ++pb)
	{
		_uint64_t _key=fx(m_k, m_p, m_n, *pb);
		int i=(int)(_key/m_n);
		int j=(int)(_key%m_n);
		Rows[i].push_back(j);
	}

	vector<int> v((int)m_n);
	for(int i=0; i<(int)m_n; i++) v[i]=i;

	for(int i=0; i<(int)m_n; i++)
	{
		if(Rows[i].size()==1) continue;
		if(Rows[i].size()==0)
		{
			m_rd[i]=0;
		}
		else
		{
			random_shuffle(v.begin(), v.end());

			vector<int>::const_iterator pb=v.begin();
			vector<int>::const_iterator pe=v.end();

			for( ; pb!=pe; ++pb)
			{
				int j=0;
				int m=(int)Rows[i].size();

				for( ; j<m; j++)
				{
					int idx=(int)( (*pb+Rows[i][j])%m_n );
					if(flag[idx]) break;
				}

				if(j==m)
				{
					m_rd[i]=*pb;
					for(j=0; j<m; j++)
					{
						int idx=(int)( (m_rd[i]+Rows[i][j])%m_n );
						flag[idx]=true;
					}
					break;
				}
			}

			if(pb==pe) return false;
		}
	}

	for(int i=0; i<(int)m_n; i++)
	{
		if(Rows[i].size()!=1) continue;
		int j=0;
		while(flag[j]) j++;
		assert(j<(int)m_n);
		m_rd[i]=(_uint32_t)( (m_n+j-Rows[i][0])%m_n );
		flag[j]=true;
	}

	for(set<_uint32_t>::const_iterator pb=keys.begin(), pe=keys.end(); pb!=pe; ++pb)
	{
		_uint64_t _key=fx(m_k, m_p, m_n, *pb);
		int i=(int)(_key/m_n);
		int j=(int)(_key%m_n);
		int k=(int)((m_rd[i]+j)%m_n);
		this->m_keys[k]=*pb;
	}

	return true;
}

int CTetrisHash::Find(_uint32_t uiKey)
{
	_uint64_t _key=(((m_k*uiKey)%m_p)%m_n2);
	int i=(int)(_key/m_n);
	int j=(int)(_key%m_n);
	int k=(int)((m_rd[i]+j)%m_n);
	return (m_keys[k]==uiKey) ? k : -1;
}

//#define TEST

#ifdef TEST
int main()
{
	int iCnt1=0, iCnt2=0;

	for(int k=0; k<10000; k++)
	{
		printf("test %d:\n", k);

		CTetrisHash HashSet;

		set<unsigned int> uiSet;

		for(int i=0; i<1000; i++)
		{
			unsigned int key=(unsigned int)Rand(0, 1000000);
			uiSet.insert(key);
		}

		vector<unsigned int> Keys;
		for(int i=0; i<10000; i++)
		{
			unsigned int key=(unsigned int)Rand(0, 1000000);
			Keys.push_back(key);
		}

		if( HashSet.PreProcessing(uiSet)<0 )
		{
			iCnt1++;
			continue;
		}

		int iCnt=0;

		for(int i=0; i<(int)Keys.size(); i++)
		{
			bool bFind1 = (uiSet.find(Keys[i])!=uiSet.end());
			bool bFind2 = (HashSet.Find(Keys[i])>=0);
			if(bFind1!=bFind2) iCnt++;
		}

		if(iCnt>0) iCnt2++;
	}

	printf("iCnt1=%d, iCnt2=%d\n", iCnt1, iCnt2);

	return 1;
}
#endif
