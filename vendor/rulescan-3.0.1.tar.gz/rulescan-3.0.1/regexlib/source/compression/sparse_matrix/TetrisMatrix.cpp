/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#include "TetrisMatrix.h"
#include <map>
using namespace std;

int CTetrisMatrix::Init(int row_num, const vector<tuple_t>& matrix, int null_cell)
{
	this->m_null_cell=null_cell;

	set<unsigned int> KeySet;
	map<unsigned int, int> KeyMap;

	for(int k=0; k<(int)matrix.size(); k++)
	{
		unsigned int key=matrix[k].r*256+matrix[k].c;
		KeySet.insert(key);
		KeyMap[key]=matrix[k].v;
	}

	int iRet=m_hash.PreProcessing(KeySet);
	if(iRet<0) return -1;

	m_Values.resize(KeyMap.size());
	for(map<unsigned int, int>::const_iterator pb=KeyMap.begin(), pe=KeyMap.end(); pb!=pe; ++pb)
	{
		int k=m_hash.Find(pb->first);
		if(k<0) return -1;
		this->m_Values[k]=pb->second;
	}

	int iMemBytes=iRet+(int)( m_Values.size()*sizeof(int)+sizeof(int) );

	return iMemBytes;
}

int CTetrisMatrix::Get(int r, unsigned char c)
{
	int k=m_hash.Find(r*256+c);
	return (k>=0) ? m_Values[k] : m_null_cell;
}
