/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#include <stdlib.h>
#include "SparseMatrix.h"
#include "BinarySearch.h"
#include "TripleArray.h"
#include "TetrisMatrix.h"

CSparseMatrix * new_instance(int algor)
{
	CSparseMatrix * instance=NULL;

	switch (algor)
	{
	case 1:
		instance=new CBinarySearch;
		break;

	case 2:
		instance=new CTripleArray;
		break;

	case 3:
		instance=new CTetrisMatrix;
		break;
	}

	return instance;
}
