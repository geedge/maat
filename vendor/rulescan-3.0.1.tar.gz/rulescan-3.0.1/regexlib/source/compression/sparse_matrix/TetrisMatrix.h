/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#ifndef H_TETRIS_MATRIX_CPP_H
#define H_TETRIS_MATRIX_CPP_H

#include "SparseMatrix.h"
#include "TetrisHash.h"

class CTetrisMatrix : public CSparseMatrix
{
public:
	virtual int Init(int row_num, const vector<tuple_t>& matrix, int null_cell);

	virtual int Get(int r, unsigned char c);

private:
	CTetrisHash m_hash;
	vector<int> m_Values;
	int m_null_cell;
};

#endif
