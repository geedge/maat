/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#ifndef H_TETRISHASH_CPP_H
#define H_TETRISHASH_CPP_H

#include <vector>
#include <set>
using namespace std;

typedef unsigned int _uint32_t;
typedef unsigned long long _uint64_t;

class CTetrisHash
{
public:
	CTetrisHash();

	~CTetrisHash();

	int PreProcessing(const set<_uint32_t>& keys);

	int Find(_uint32_t uiKey);

private:
	bool ComputeK(const set<_uint32_t>& keys);

	bool TestK(const set<_uint32_t>& keys);

	bool ComputeRD(const set<_uint32_t>& keys);

private:
	vector<_uint32_t> m_rd;
	vector<_uint32_t> m_keys;
	_uint64_t m_k;
	_uint64_t m_p;
	_uint64_t m_n;
	_uint64_t m_n2;
	_uint64_t m_uiTestK;
};

#endif
