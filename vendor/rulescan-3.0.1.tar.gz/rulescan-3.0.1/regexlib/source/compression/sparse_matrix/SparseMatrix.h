/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#ifndef H_SPARSE_MATRIX_H
#define H_SPARSE_MATRIX_H

#define SPARSE_COMPR_ALGOR	 1

#include <vector>
using namespace std;

struct tuple_t
{
	int r;
	unsigned char c;
	int v;
};

class CSparseMatrix
{
public:
	CSparseMatrix() {}
	virtual ~CSparseMatrix() {}

	virtual int Init(int row_num, const vector<tuple_t>& matrix, int null_cell)=0;

	virtual int Get(int r, unsigned char c)=0;
};

CSparseMatrix * new_instance(int algor);

#endif
