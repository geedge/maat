/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#include "TripleArray.h"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
using namespace std;

int CTripleArray::Init(int row_num, const vector<tuple_t>& matrix, int null_cell)
{
	printf("init triple array.\n");

	m_null_cell=null_cell;

	int iRow=row_num;

	m_base.clear();
	m_check.clear();
	m_next.clear();

	m_base.resize(iRow, 0);
	m_check.resize(iRow*256, -1);
	m_next.resize(iRow*256, 0);

	int iNotZeroCnt=0;

	int p=0;

	for(int r=0; r<iRow; r++)
	{
		vector<int> idx;
		vector<int> v;

		while(p<(int)matrix.size() && matrix[p].r==r)
		{
			idx.push_back(matrix[p].c);
			v.push_back(matrix[p].v);
			p++;
		}

		m_base[r]=FindBase(idx);

		for(int k=0; k<(int)idx.size(); k++)
		{
			int c=idx[k];
			int t=m_base[r]+c;
			m_check[t]=r;
			m_next[t]=v[k];
			iNotZeroCnt++;
		}
	}

	int iMaxIndex=*max_element(m_base.begin(), m_base.end())+256;

	vector<int> _check(m_check.begin(), m_check.begin()+iMaxIndex);
	vector<int> _next(m_next.begin(), m_next.begin()+iMaxIndex);
	m_check.swap(_check);
	m_next.swap(_next);

	printf("density=%5.3f.\n", (double)(2*iNotZeroCnt+iRow)/(m_base.size()+m_check.size()+m_next.size()));

	int iMemBytes=(int)( sizeof(int)*(m_base.size()+m_check.size()+m_next.size()) );

	printf("~init triple array.\n");

	return iMemBytes;
}

int CTripleArray::FindBase(const vector<int>& idx)
{
	for(int offset=0; true; offset++)
	{
		int i=0;
		while(i<(int)idx.size())
		{
			if(m_check[offset+idx[i]]!=-1) break;
			i++;
		}
		if(i==(int)idx.size()) return offset;
	}
}

int CTripleArray::Get(int r, unsigned char c)
{
	int t=m_base[r]+c;
	return (m_check[t]==r) ? m_next[t] : m_null_cell;
}
