/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#include "BinarySearch.h"
#include <stdlib.h>
using namespace std;

CBinarySearch::CBinarySearch()
{
	m_N=0;
	m_row_ptr=NULL;
	m_key=NULL;
	m_value=NULL;
	m_null_cell=0;
}

CBinarySearch::~CBinarySearch()
{
	if(m_row_ptr!=NULL) delete [] m_row_ptr;

	if(m_key!=NULL) delete [] m_key;

	if(m_value!=NULL) delete [] m_value;
}

int CBinarySearch::Init(int row_num, const vector<tuple_t>& matrix, int null_cell)
{
	if(matrix.size()==0 || row_num==0) return 0;

	int mem_bytes=0;

	m_N=row_num;
	m_null_cell=null_cell;

	m_key=new unsigned char[matrix.size()];
	m_value=new int[matrix.size()];
	m_row_ptr=new int[m_N+1];

	mem_bytes+=(int)matrix.size()*(sizeof(unsigned char)+sizeof(int))+(m_N+1)*(int)sizeof(int);

	for(int i=0; i<=m_N; i++) m_row_ptr[i]=0;
	for(int i=0; i<(int)matrix.size(); i++)
	{
		m_key[i]=matrix[i].c;
		m_value[i]=matrix[i].v;
		m_row_ptr[matrix[i].r+1]++;
	}
	for(int i=1; i<=m_N; i++) m_row_ptr[i]+=m_row_ptr[i-1];

	return mem_bytes;
}

int CBinarySearch::Get(int r, unsigned char c)
{
	if(m_key==NULL) return m_null_cell;

	int L=m_row_ptr[r];
	int H=m_row_ptr[r+1]-1;

	while(L<=H)
	{
		int M=((L+H)>>1);
		if(m_key[M]<=c)
		{
			L=M+1;
		}
		else
		{
			H=M-1;
		}
	}

	if(H>=m_row_ptr[r] && m_key[H]==c)
	{
		return m_value[H];
	}
	else
	{
		return m_null_cell;
	}
}
