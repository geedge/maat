/*
*
* Copyright (c) 2008--2012
* String Matching Group, Lab for Intelligent Information Processing Technology,
* Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
* All rights reserved.
*
* Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
* Last modification: 2012-07-12
*
* This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
* or indirect commercial advantage is not allowed without written permission from 
* the authors.
*
*/

#include <assert.h>
#include "TopKState.h"
#include "../regex_def.h"
#include "../DFA.h"

bool operator<(const k_tuple_t& lhs, const k_tuple_t& rhs)
{
	return (memcmp(lhs.a, rhs.a, sizeof(rhs.a))<0);
}

bool operator>(const k_tuple_t& lhs, const k_tuple_t& rhs)
{
	return (rhs<lhs);
}

bool operator<(const bitmap_t& lhs, const bitmap_t& rhs)
{
	return (memcmp(lhs.bitmap, rhs.bitmap, sizeof(rhs.bitmap))<0);
}

bool operator>(const bitmap_t& lhs, const bitmap_t& rhs)
{
	return (rhs<lhs);
}

CTopKState::CTopKState()
{
	m_T1=NULL;
	m_T2=NULL;
	m_B1=NULL;
	m_B2=NULL;
	m_M =NULL;
	m_S =NULL;
	m_matched_ptr=NULL;
	m_matched_patterns=NULL;
	m_state_num=0;
	m_char_set_size=256;
	m_initial_state=0;
	m_trap_state=-1;
}

CTopKState::~CTopKState()
{
	if(m_T1!=NULL) delete [] m_T1;
	if(m_T2!=NULL) delete [] m_T2;
	if(m_B1!=NULL) delete [] m_B1;
	if(m_B2!=NULL) delete [] m_B2;
	if(m_M !=NULL) delete [] m_M;
	if(m_S !=NULL) delete m_S;
	if(m_matched_ptr!=NULL) delete [] m_matched_ptr;
	if(m_matched_patterns!=NULL) delete [] m_matched_patterns;
}

int CTopKState::load_DFA_from_file(const char * dfa_file, const CDFA * dfa)
{
	FILE * stream=NULL;
	int ret;

	if(dfa_file!=NULL)
	{
		stream=fopen(dfa_file, "rb");
		if(stream==NULL) return -1;

		fseek(stream, 16, SEEK_SET);
		ret=READ_INT(m_state_num,     stream); assert(ret==1);
		ret=READ_INT(m_char_set_size, stream); assert(ret==1);
		ret=READ_INT(m_initial_state, stream); assert(ret==1);
	}
	else if(dfa!=NULL)
	{
		m_state_num    =dfa->m_state_num;
		m_char_set_size=dfa->m_char_set_size;
		m_initial_state=dfa->m_initial_state;
	}
	else
	{
		return -1;
	}

	unsigned long long mem_bytes=0;

	m_T1=new unsigned int[m_state_num];
	m_B1=new unsigned int[m_state_num];
	m_matched_ptr=new int[m_state_num+1];
	mem_bytes+=(3*m_state_num+1)*sizeof(int);

	map<k_tuple_t, unsigned int> T2;
	map<k_tuple_t, unsigned int> B2;
	map<bitmap_t,  unsigned int> M;
	vector<tuple_t>              S;
	vector<int> matched_patterns;

	m_matched_ptr[0]=0;
	FOR(s, m_state_num)
	{
		int * next_state;
		unsigned int pattern_num;
		int __next_state[256];

		if(dfa_file!=NULL)
		{
			next_state=__next_state;
			FOR(c, m_char_set_size)
			{
				ret=READ_INT(__next_state[c], stream); assert(ret==1);
			}

			ret=READ_INT(pattern_num, stream); assert(ret==1);
			m_matched_ptr[s+1]=m_matched_ptr[s]+pattern_num;
			FOR(k, pattern_num)
			{
				unsigned int pattern_id;
				ret=READ_INT(pattern_id, stream); assert(ret==1);
				matched_patterns.push_back(pattern_id);
			}
		}
		else
		{
			next_state =dfa->m_state_table[s].next_state;
			pattern_num=dfa->m_state_table[s].pattern_num;
			m_matched_ptr[s+1]=m_matched_ptr[s]+pattern_num;
			FOR(k, pattern_num)
			{
				matched_patterns.push_back(dfa->m_state_table[s].pattern_id[k]);
			}
		}

		//����trap state
		if(pattern_num==0)
		{
			int c=0;
			for( ; c<m_char_set_size; c++)
			{
				if(next_state[c]!=s) break;
			}
			if(c==m_char_set_size) m_trap_state=s;
		}

		k_tuple_t top;
		k_tuple_t idx;
		char flag[256]={0};

		FOR(k, K) top.a[k]=idx.a[k]=-1;

		map<int, int> cnt;

		FOR(c, m_char_set_size)
		{
			int e=next_state[c];
			cnt[e]++;
		}

		FOR(k, K)
		{
			if(cnt.empty()) break;

			map<int, int>::iterator F=cnt.begin();

			for(map<int, int>::iterator p=cnt.begin(); p!=cnt.end(); ++p)
			{
				if(p->second>F->second) F=p;
			}

			top.a[k]=F->first;
			cnt.erase(F);
		}

		FOR(k, K)
		{
			bitmap_t bm;
			memset(bm.bitmap, 0, sizeof(bm.bitmap));

			FOR(c, m_char_set_size)
			{
				if((unsigned int)next_state[c]==top.a[k])
				{
					bm.bitmap[c>>5]|=(1u<<(c&31));
					flag[c]=1;
				}
			}

			map<bitmap_t, unsigned int>::const_iterator p=M.find(bm);
			if(p==M.end())
			{
				unsigned int q=M.size();
				M.insert(make_pair(bm, q));
				idx.a[k]=q;
			}
			else
			{
				idx.a[k]=p->second;
			}
		}

		FOR(c, m_char_set_size)
		{
			if(flag[c]==0)
			{
				tuple_t tp;

				tp.r=s;
				tp.c=c;
				tp.v=next_state[c];

				S.push_back(tp);
			}
		}

		map<k_tuple_t, unsigned int>::const_iterator it=T2.find(top);
		if(it==T2.end())
		{
			unsigned int q=T2.size();
			T2.insert(make_pair(top, q));
			m_T1[s]=q;
		}
		else
		{
			m_T1[s]=it->second;
		}

		it=B2.find(idx);
		if(it==B2.end())
		{
			unsigned int q=B2.size();
			B2.insert(make_pair(idx, q));
			m_B1[s]=q;
		}
		else
		{
			m_B1[s]=it->second;
		}
	}

	if(dfa_file!=NULL)
	{
		fclose(stream);
	}

	m_matched_patterns=new int[matched_patterns.size()];
	copy(matched_patterns.begin(), matched_patterns.end(), m_matched_patterns);
	matched_patterns.clear();
	mem_bytes+=matched_patterns.size()*sizeof(int);

	m_T2=new k_tuple_t[T2.size()];
	for(map<k_tuple_t, unsigned int>::const_iterator it=T2.begin(); it!=T2.end(); ++it)
	{
		m_T2[it->second]=it->first;
	}
	T2.clear();
	mem_bytes+=T2.size()*sizeof(k_tuple_t);

	m_B2=new k_tuple_t[B2.size()];
	for(map<k_tuple_t, unsigned int>::const_iterator it=B2.begin(); it!=B2.end(); ++it)
	{
		m_B2[it->second]=it->first;
	}
	B2.clear();
	mem_bytes+=B2.size()*sizeof(k_tuple_t);

	m_M=new bitmap_t[M.size()];
	for(map<bitmap_t, unsigned int>::const_iterator it=M.begin(); it!=M.end(); ++it)
	{
		m_M[it->second]=it->first;
	}
	M.clear();
	mem_bytes+=M.size()*sizeof(bitmap_t);

	m_S=new_instance(SPARSE_COMPR_ALGOR);
	ret=m_S->Init(m_state_num, S, -1);
	if(ret<0) return -1;
	S.clear();
	mem_bytes+=ret;

	//printf("m_state_num=%d, mem_bytes=%5.3lf (MB), compr_ratio=%5.3lf\n", m_state_num, (double)mem_bytes/(1U<<20), 
	//	(double)mem_bytes/((m_state_num*m_char_set_size+m_state_num+m_matched_ptr[m_state_num])*sizeof(int)));

	return 1;
}

int CTopKState::next_state(int s, unsigned char c)
{
	for(unsigned int k=0; k<K; k++)
	{
		unsigned int j=m_B2[m_B1[s]].a[k];
		if(m_M[j].bitmap[c>>5]&(1u<<(c&31))) return m_T2[m_T1[s]].a[k];
	}
	return m_S->Get(s, c);
}
