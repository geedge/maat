/*
 *
 * Copyright (c) 2008--2012
 * String Matching Group, Lab for Intelligent Information Processing Technology,
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
 * All rights reserved.
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2012-07-12
 *
 * This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
 * or indirect commercial advantage is not allowed without written permission from 
 * the authors.
 *
 */

#ifndef H_TOPK_STATE_CPP_H
#define H_TOPK_STATE_CPP_H

#include "../regex_def.h"
#include "sparse_matrix/SparseMatrix.h"

class CDFA;

const unsigned int K=8;

struct k_tuple_t
{
	unsigned int a[K];
};

struct bitmap_t
{
	unsigned int bitmap[8];
};

class CTopKState
{
public:
	CTopKState();

	~CTopKState();

	int load_DFA_from_file(const char * dfa_file, const CDFA * dfa);

	int next_state(int s, unsigned char c);

public:
	unsigned int  * m_T1;
	k_tuple_t     * m_T2;
	unsigned int  * m_B1;
	k_tuple_t     * m_B2;
	bitmap_t      * m_M;
	CSparseMatrix * m_S;
	int           * m_matched_ptr;
	int           * m_matched_patterns;

	int             m_state_num;
	int             m_char_set_size;
	int             m_initial_state;
	int             m_trap_state;
};

#endif
