#include "DFA.h"
#include "md5.h"
#include "ThompsonNFA.h"
#include "HashTable.h"
#include "parse_tree/ParseTree.h"

CDFA::CDFA()
{
	m_state_num=0;
	m_state_table=NULL;
	m_char_set_size=256;
	m_trap_state=-1;
	m_initial_state=0;
#ifdef USE_DFA_PTR
	m_state_table_address=NULL;
	m_state_num_address=0;
#endif
	m_case_sensitive=true;

	FOR(c, 256)
	{
		m_char_map[c]=(unsigned char)tolower(c);
	}
}

CDFA::~CDFA()
{
	FOR(i, m_patterns.size())
	{
		FOR(j, m_patterns[i].sub_patterns.size())
		{
			if(m_patterns[i].sub_patterns[j].reverse_DFA!=NULL)
			{
#ifdef USE_DFA_PTR
				delete (CDFA *)m_patterns[i].sub_patterns[j].reverse_DFA;
#else
				delete (CTopKState *)m_patterns[i].sub_patterns[j].reverse_DFA;
#endif
			}
		}

		if(m_patterns[i].forward_NFA!=NULL)
		{
			pcre_free(m_patterns[i].forward_NFA);
		}
	}
	m_patterns.clear();

	if(m_state_num>0 && m_state_table!=NULL)
	{
		FOR(i, m_state_num)
		{
			if(m_state_table[i].next_state!=NULL)
			{
				delete [] m_state_table[i].next_state;
			}
			if(m_state_table[i].pattern_num>0 && m_state_table[i].pattern_id!=NULL)
			{
				delete [] m_state_table[i].pattern_id;
			}
		}
		delete [] m_state_table;
	}

	m_state_num=0;
	m_char_set_size=256;
	m_state_table=NULL;
	m_trap_state=-1;

#ifdef USE_DFA_PTR
	if(m_state_num_address>0 && m_state_table_address!=NULL)
	{
		FOR(i, m_state_num_address)
		{
			if(m_state_table_address[i].pattern_num>0)
			{
				delete [] m_state_table_address[i].pattern_id;
			}
		}
		delete [] m_state_table_address;
	}
	m_state_table_address=NULL;
	m_state_num_address=0;
#endif
}

int CDFA::preprocessing(const char * pattern_file, bool case_sensitive, unsigned int * failed_ids, unsigned int num, int max_limit, bool fast_try)
{
	int ret;

	m_max_limit=max_limit;
	m_case_sensitive=case_sensitive;

	/*����ԭʼ��ģʽ���ļ�*/
	ret=CDFA::load_patterns_from_file(pattern_file, m_patterns, case_sensitive, NULL, failed_ids, num);
	if(ret<0 || m_patterns.size()==0)
	{
		printf_regex_log("[%s:%d]: load_patterns_from_file() failed!\n", __FILE__, __LINE__);
		return -1;
	}

	/*�Ը��ӵ��������ʽ���в�֣��洢����չģʽ���ļ�*/
	cstring ext_pattern_file=cstring(pattern_file)+cstring(".ext");
	cstring ext_dfa_file=ext_pattern_file+cstring(".dfa");
	unsigned char ext_md5[16]={0};

	ret=translate_rules(pattern_file, m_patterns, ext_pattern_file.c_str());
	if(ret<0)
	{
		printf_regex_log("[%s:%d]: translate_rules() failed!\n", __FILE__, __LINE__);
		return -1;
	}

	vector<regex_pattern_t> ext_patterns;
	ret=CDFA::load_patterns_from_file(ext_pattern_file.c_str(), ext_patterns, case_sensitive, ext_md5,NULL, 0);
	if(ret<0 || ext_patterns.size()==0)
	{
		printf_regex_log("[%s:%d]: load_patterns_from_file() failed!\n", __FILE__, __LINE__);
		return -1;
	}

	/*��ʼ������DFA*/
#ifdef LOAD_DFA_FROM_FILE
	ret=check_md5(ext_dfa_file.c_str(), ext_md5);//���MD5�����һ�£���ֱ�Ӵ��ļ�����DFA
	if(ret<0)
	{
#endif
		//Ϊ��֤�ȶ��ԣ�����ϵͳ�����ʼ��ʱ��ÿ�ζ��ӹ��򹹽��Զ��������ٴ���ǰ���Զ����ļ��м��ء�
		ret=this->BuildDFAFromMultiDFAs(ext_patterns, case_sensitive, ext_dfa_file.c_str(), ext_md5);
		if(ret<0)
		{
			printf_regex_log("[%s:%d]: BuildDFAFromMultiDFAs() failed!\n", __FILE__, __LINE__);
			return -1;
		}
#ifdef LOAD_DFA_FROM_FILE
	}
#endif

#ifdef USE_DFA_PTR
	ret=load_DFA_from_file_address(ext_dfa_file.c_str());
	if(ret<0)
	{
		printf_regex_log("[%s:%d]: load_DFA_from_file_address() failed!\n", __FILE__, __LINE__);
		return -1;
	}

	if(m_state_num_address > m_max_limit) 
	{
		printf_regex_log("[%s:%d]: failed by m_state_num_address > m_max_limit!\n", __FILE__, __LINE__);
		return -1;
	}
#else
	ret=m_TOPK.load_DFA_from_file(ext_dfa_file.c_str(), NULL);
	if(ret<0)
	{
		printf_regex_log("[%s:%d]: m_TOPK.load_DFA_from_file() failed!\n", __FILE__, __LINE__);
		return -1;
	}

	if(m_TOPK.m_state_num>m_max_limit)
	{
		printf_regex_log("[%s:%d]: failed by m_state_num>m_max_limit!\n", __FILE__, __LINE__);
		return -1;
	}
#endif

	remove(ext_pattern_file.c_str());
#ifndef LOAD_DFA_FROM_FILE
	remove(ext_dfa_file.c_str());
#endif

	/*�ڹ�������У���Ҫ���Թ���DFA��һ�������ɹ�����Ҫ���ٷ��ء�*/
	if(fast_try) return 1; 

	/*����ÿ���������ʽ������DFA�������ҵ�ƥ�����ʼλ�á�*/
	//printf("build anchored reverse_prefix_DFA for each regular expression...\n");
#ifdef USE_OMP
#pragma omp parallel for
#endif
	for(int i=0; i<(int)m_patterns.size(); i++)
	{
#ifdef DEBUG_DFA
		printf_regex_log("build reverse_DFA for pattern_id=%u\n", m_patterns[i].pattern_id);
#endif

		for(int j=0; j<(int)m_patterns[i].sub_patterns.size(); j++)
		{
			regex_pattern_t pt=m_patterns[i];

			pt.reverse=true;
			pt.pattern=m_patterns[i].sub_patterns[j].prefix; /*����ǰ׺��������DFA*/

			CDFA * dfaptr=new CDFA;

			if(dfaptr->BuildDFAFromNFA(&pt, case_sensitive, true)>=0)
			{
#ifdef USE_DFA_PTR
				dfaptr->table_to_address();
				m_patterns[i].sub_patterns[j].reverse_DFA=(void *)dfaptr;
#else
				CTopKState * topk=new CTopKState;
				int ret=topk->load_DFA_from_file(NULL, dfaptr);
				if(ret>=0)
				{
					m_patterns[i].sub_patterns[j].reverse_DFA=topk;
				}
				else
				{
					delete topk;
					m_patterns[i].sub_patterns[j].reverse_DFA=NULL;
					return -1;
				}
#endif
				m_patterns[i].sub_patterns[j].prefix_max_len=pt.max_len;
				m_patterns[i].sub_patterns[j].prefix_min_len=pt.min_len;
			}
			else
			{
				delete dfaptr;
				m_patterns[i].sub_patterns[j].reverse_DFA=NULL;
				m_patterns[i].sub_patterns[j].prefix_max_len=UINT_MAX;
				m_patterns[i].sub_patterns[j].prefix_min_len=0;
			}

			m_patterns[i].sub_patterns[j].wnd_size=m_patterns[i].sub_patterns[j].prefix_max_len;
			if(m_patterns[i].sub_patterns[j].wnd_size==UINT_MAX)
			{
				m_patterns[i].sub_patterns[j].wnd_size=65536;
			}
		}
	}

	/*����ÿ���������ʽ������NFA������У�顣*/
	//printf("build anchored forward_NFA for each regular expression...\n");
#ifdef USE_OMP
#pragma omp parallel for
#endif
	for(int i=0; i<(int)m_patterns.size(); i++)
	{
#ifdef DEBUG_DFA
		printf_regex_log("build forward_NFA for pattern_id=%u\n", m_patterns[i].pattern_id);
#endif

		const char * errptr=NULL;
		int erroffset=0;
		if(case_sensitive)
		{
			m_patterns[i].forward_NFA=pcre_compile(m_patterns[i].pattern.c_str(), PCRE_ANCHORED|PCRE_DOTALL|PCRE_DOLLAR_ENDONLY, &errptr, &erroffset, NULL);
		}
		else
		{
			m_patterns[i].forward_NFA=pcre_compile(m_patterns[i].pattern.c_str(), PCRE_ANCHORED|PCRE_DOTALL|PCRE_DOLLAR_ENDONLY|PCRE_CASELESS, &errptr, &erroffset, NULL);
		}
	}

	return 1;
}

int CDFA::check_md5(const char * dfa_file, unsigned char * md5)
{
	FILE * stream=fopen(dfa_file, "rb");
	if(stream==NULL) return -1;

	unsigned char _md5[16]={0};
	int ret=fread(_md5, sizeof(unsigned char), 16, stream);
	assert(ret==16);
	fclose(stream);

	if(memcmp(md5, _md5, 16)!=0)
	{
#ifdef DEBUG_DFA
		printf("md5 verification failed, the DFA will be reconstructed...\n");
		printf_regex_log("md5 verification failed, the DFA will be reconstructed...\n");
#endif
		return -1;
	}
	else
	{
		return 1;
	}
}

#ifdef USE_DFA_PTR
int CDFA::table_to_address()
{
	if(m_state_num==0 || m_state_table==NULL) return -1;

	m_state_num_address=m_state_num;
	m_state_table_address=new dfa_state_address_t[m_state_num_address];

	FOR(i, m_state_num)
	{
		FOR(c, m_char_set_size)
		{
			int J=m_state_table[i].next_state[c];
			if(J==this->m_trap_state)
			{
				m_state_table_address[i].next_state[c]=NULL;
			}
			else
			{
				m_state_table_address[i].next_state[c]=m_state_table_address+J;
			}
		}
		delete [] m_state_table[i].next_state;

		m_state_table_address[i].pattern_num=m_state_table[i].pattern_num;

		if(m_state_table_address[i].pattern_num>0)
		{
			m_state_table_address[i].pattern_id=m_state_table[i].pattern_id;
		}
	}

	delete [] m_state_table;
	m_state_table=NULL;
	m_state_num=0;

	return 1;
}
#endif

int CDFA::BuildDFAFromNFA(regex_pattern_t * pat, bool case_sensitive, bool anchored)
{
	CThompsonNFA NFA;

	int ret=NFA.BuildNFA(pat, case_sensitive, anchored);
	if(ret<0) return -1;

	/*���������DFA״̬�����ܳ���SINGLE_DFA_STATE_NUM��������Ըù��� */
	const int SINGLE_DFA_STATE_NUM=(1<<14);
	vector< dfa_state_t> tab(SINGLE_DFA_STATE_NUM);

	int id=0;
	hash_table ht;

	vector<int> start_states=NFA.get_start_states();
	ht.put(ht.hashing(start_states), start_states, id);
	++id;

	const hash_node_t * p;

	while((p=ht.get_next())!=NULL)
	{
		const vector<int>& current=p->state;
		int current_id=p->value;

#ifdef DEBUG_DFA
		if(current_id>0 && current_id%1000==0)
		{
			printf("build DFA states from NFA: %6d processed, %6d in processing.\n", current_id, id-current_id);
		}
#endif

		vector<int> v=NFA.get_matched_patterns(current);

		tab[current_id].pattern_num=(int)v.size();
		if(v.size()>0)
		{
			tab[current_id].pattern_id=new int[v.size()];
			copy(v.begin(), v.end(), tab[current_id].pattern_id);
		}

		tab[current_id].next_state=new int[m_char_set_size];

		FOR(c, m_char_set_size)
		{
			vector<int> next=NFA.get_next_states(current, c);

			unsigned int key=ht.hashing(next);

			int next_id=ht.get(key, next);
			if(next_id<0)
			{
				if(id>=(int)tab.size())
				{
#ifdef DEBUG_DFA
					printf    ("[%s: %d]: pid=%u, # of DFA states exceeds %d.\n", __FILE__, __LINE__, pat->pattern_id, (int)tab.size());
					printf_regex_log("[%s: %d]: pid=%u, # of DFA states exceeds %d.\n", __FILE__, __LINE__, pat->pattern_id, (int)tab.size());
#endif
					goto clean_up;
				}
				next_id=id++;
				ht.put(key, next, next_id);
			}

			tab[current_id].next_state[c]=next_id;
		}
	}

	m_state_num=id;
	m_state_table=new dfa_state_t[m_state_num];
	copy(tab.begin(), tab.begin()+m_state_num, m_state_table);

	//����trap_state
	FOR(i, m_state_num)
	{
		if(m_state_table[i].pattern_num>0) continue;

		int c=0;
		for( ; c<m_char_set_size; c++)
		{
			if(m_state_table[i].next_state[c]!=i) break;
		}
		if(c==m_char_set_size)
		{
			m_trap_state=i;
			break;
		}
	}

#ifdef DEBUG_DFA
	printf("pattern_id=%u, # of DFA states=%d\n", pat->pattern_id, m_state_num);
#endif

	return 1;

clean_up:
	FOR(i, (int)tab.size())
	{
		if(tab[i].next_state!=NULL)
		{
			delete [] tab[i].next_state;
		}
		if(tab[i].pattern_num>0)
		{
			delete [] tab[i].pattern_id;
		}
	}
	tab.clear();

	return -1;
}

int CDFA::BuildDFAFromMultiDFAs(vector<regex_pattern_t>& pats, bool case_sensitive, const char * dfa_file, unsigned char * md5)
{
#ifdef DEBUG_DFA
	printf("build single DFA for each regular expression...\n");
#endif

	vector<CDFA *> DFAs(pats.size(), NULL);

#ifdef USE_OMP
#pragma omp parallel for
#endif
	for(int i=0; i<(int)pats.size(); i++)
	{
#ifdef DEBUG_DFA
		printf("build DFA for pattern_id=%u\n", pats[i].pattern_id);
#endif
		DFAs[i]=new CDFA;
		if(DFAs[i]->BuildDFAFromNFA(&(pats[i]), case_sensitive, false)<0)
		{
			printf_regex_log("[%s: %d]: build DFA for rule_id=%u failed!\n", __FILE__, __LINE__, pats[i].pattern_id);
			delete DFAs[i];
			DFAs[i]=NULL;
		}
	}

	DFAs.erase(remove(DFAs.begin(), DFAs.end(), (CDFA *)NULL), DFAs.end());

	if(DFAs.size()==0) return -1;

#ifdef DEBUG_DFA
	printf("start multi-threading merging...\n");
#endif

	int K=16;
	//int rounds=0;

	while((int)DFAs.size()>K)
	{
#ifdef DEBUG_DFA
		printf("start the %d-th round of merging...\n", ++rounds);
#endif

		int G=((int)DFAs.size()+K-1)/K;

		vector< vector<CDFA *> > sub_groups(G);
		FOR(i, DFAs.size()) sub_groups[i%G].push_back(DFAs[i]);

		DFAs.clear();
		DFAs.resize(G, NULL);

#ifdef USE_OMP
#pragma omp parallel for
#endif
		for(int i=0; i<G; i++)
		{
			DFAs[i]=new CDFA;
			if(this->merge_DFA(i, sub_groups[i], DFAs[i], MAX_DFA_STATE_NUM/G)<0)
			{
#ifdef DEBUG_DFA
				printf    ("[%s: %d]: merge_DFA() failed: group=%d!\n", __FILE__, __LINE__, i);
				printf_regex_log("[%s: %d]: merge_DFA() failed: group=%d!\n", __FILE__, __LINE__, i);
#endif
				delete DFAs[i];
				DFAs[i]=NULL;
			}
		}

		//�����һ������鲢ʧ�ܣ������幹��ʧ�ܣ�ɾ�����е�DFA�������ء�
		for(int i=0; i<G; i++)
		{
			if(DFAs[i]==NULL)
			{
				for(int k=0; k<G; k++)
				{
					if(DFAs[k]!=NULL) delete DFAs[k];
				}
				return -1;
			}
		}
	}
#ifdef DEBUG_DFA
	printf("end of multi-threading merging.\n");
#endif

#ifdef DEBUG_DFA
	printf("start the final merging...\n");
#endif

	int ret=this->merge_final_DFA(DFAs, md5, dfa_file);
	if(ret<0) 	
	{
		printf_regex_log("[%s: %d]: this->merge_final_DFA() failed!\n", __FILE__, __LINE__);
		return -1;
	}

#ifdef DEBUG_DFA
	printf("end of the final merging.\n");
#endif

	return 1;
}

int CDFA::merge_DFA(int gid, const vector<CDFA*>& DFAs, CDFA * DFA, int state_num_limit)
{
	int __limit_num=state_num_limit;
	FOR(k, (int)DFAs.size())
	{
		__limit_num-=DFAs[k]->m_state_num;
	}
	if(__limit_num<=0)
	{
		if(gid!=-1)
		{
			FOR(i, DFAs.size()) delete DFAs[i];
		}
		return -1;
	}

#ifdef USE_OMP
	int thread_id=omp_get_thread_num();
#else
	//int thread_id=0;
#endif

	int id=0;
	DFA->m_state_table=new dfa_state_t[__limit_num];

	hash_table ht;

	vector<int> start_states(DFAs.size(), 0);

	ht.put(ht.hashing(start_states), start_states, id);
	++id;

	const hash_node_t * p;

	while((p=ht.get_next())!=NULL)
	{
		const vector<int>& current=p->state;
		int current_id=p->value;

#ifdef DEBUG_DFA
		if(current_id>0 && current_id%1000==0)
		{
			printf("[thread_id=%d]: build DFA states: %6d processed, %6d in processing.\n", thread_id, current_id, id-current_id);
		}
#endif

		DFA->m_state_table[current_id].next_state=new int[DFA->m_char_set_size];

		FOR(c, DFA->m_char_set_size)
		{
			vector<int> next(DFAs.size());

			for(int i=0; i<(int)DFAs.size(); i++)
			{
				next[i]=DFAs[i]->m_state_table[current[i]].next_state[c];
			}

			unsigned int key=ht.hashing(next);

			int next_id=ht.get(key, next);
			if(next_id<0)
			{
				if(id>=__limit_num)
				{
#ifdef DEBUG_DFA
					printf("[%s: %d]: thread_id=%d, # of DFA node exceeds %d.\n", __FILE__, __LINE__, thread_id, __limit_num);
					printf_regex_log("[%s: %d]: thread_id=%d, # of DFA node exceeds %d.\n", __FILE__, __LINE__, thread_id, __limit_num);
#endif
					goto clean_up;
				}
				next_id=id++;
				ht.put(key, next, next_id);
			}

			DFA->m_state_table[current_id].next_state[c]=next_id;
		}

		int pat_num=0;
		FOR(i, DFAs.size()) pat_num+=DFAs[i]->m_state_table[current[i]].pattern_num;
		DFA->m_state_table[current_id].pattern_num=pat_num;
		if(pat_num>0)
		{
			DFA->m_state_table[current_id].pattern_id=new int[pat_num];
			int k=0;
			FOR(i, DFAs.size())
			{
				int * p=DFAs[i]->m_state_table[current[i]].pattern_id;
				int n=DFAs[i]->m_state_table[current[i]].pattern_num;
				copy(p, p+n, DFA->m_state_table[current_id].pattern_id+k);
				k+=n;
			}
		}
	}

	DFA->m_state_num=id;

	if(gid!=-1)
	{
		FOR(i, DFAs.size()) delete DFAs[i];
	}

	if(DFA->m_state_num<(int)(0.8*__limit_num))
	{
		dfa_state_t * ptab=new dfa_state_t[DFA->m_state_num];
		copy(DFA->m_state_table, DFA->m_state_table+DFA->m_state_num, ptab);
		delete [] DFA->m_state_table;
		DFA->m_state_table=ptab;
	}

#ifdef DEBUG_DFA
	printf("[thread_id=%d, group_id=%d]: # of DFA states=%d\n", thread_id, gid, DFA->m_state_num);
#endif

	return 1;

clean_up:

	if(gid!=-1)
	{
		FOR(i, DFAs.size()) delete DFAs[i];
	}

	FOR(i, __limit_num)
	{
		if(DFA->m_state_table[i].next_state!=NULL)
		{
			delete [] DFA->m_state_table[i].next_state;
		}
		if(DFA->m_state_table[i].pattern_num>0 && DFA->m_state_table[i].pattern_id!=NULL)
		{
			delete [] DFA->m_state_table[i].pattern_id;
		}
	}
	delete [] DFA->m_state_table;
	 DFA->m_state_table=NULL;
	 DFA->m_state_num=0;

	return -1;
}

int CDFA::merge_final_DFA(const vector<CDFA*>& DFAs, unsigned char md5[], const char * dfa_file)
{
	FILE * stream=fopen(dfa_file, "wb");
	if(stream==NULL) return -1;

	fseek(stream, 16, SEEK_SET);
	WRITE_INT(m_state_num, stream);
	WRITE_INT(m_char_set_size, stream);
	m_initial_state=0;
	WRITE_INT(m_initial_state, stream);

	const int N=(1<<16);

	int id=0;
	dfa_state_t * ptab=new dfa_state_t[N];
	FOR(i, N)
	{
		ptab[i].next_state=new int[m_char_set_size];
		ptab[i].pattern_num=0;
		ptab[i].pattern_id=NULL;
	}

	hash_table ht;

	vector<int> start_states(DFAs.size(), 0);

	ht.put(ht.hashing(start_states), start_states, id);
	++id;

	const hash_node_t * p;
	bool suc_flag=true; //�����ɹ���־

	while((p=ht.get_next())!=NULL)
	{
		const vector<int>& current=p->state;
		int current_id=p->value;

#ifdef DEBUG_DFA
		if(current_id>0 && current_id%1000==0)
		{
			printf("build DFA states: %6d processed, %6d in processing.\n", current_id, id-current_id);
		}
#endif

		if(current_id>0 && current_id%N==0)
		{
#ifdef DEBUG_DFA
			printf("dump DFA states to disk: [%d, %d)\n", current_id-N, current_id);
#endif
			FOR(i, N)
			{
				FOR(c, m_char_set_size)
				{
					WRITE_INT(ptab[i].next_state[c], stream);
				}

				WRITE_INT(ptab[i].pattern_num, stream);

				FOR(k, ptab[i].pattern_num)
				{
					WRITE_INT(ptab[i].pattern_id[k], stream);
				}

				//add by luyuhai,2015.07.14
				if(ptab[i].pattern_id != NULL)
				{
					delete[] ptab[i].pattern_id;
					ptab[i].pattern_id = NULL;
				}
			}
		}

		FOR(c, m_char_set_size)
		{
			vector<int> next(DFAs.size());

			for(int i=0; i<(int)DFAs.size(); i++)
			{
				next[i]=DFAs[i]->m_state_table[current[i]].next_state[c];
			}

			unsigned int key=ht.hashing(next);

			int next_id=ht.get(key, next);
			if(next_id<0)
			{
				if(id>m_max_limit) //״̬��������ֵ
				{
					suc_flag=false;
					goto END_OF_MERGE;
				}
				next_id=id++;
				ht.put(key, next, next_id);
			}

			ptab[current_id%N].next_state[c]=next_id;
		}

		int pat_num=0;
		FOR(i, DFAs.size()) pat_num+=DFAs[i]->m_state_table[current[i]].pattern_num;
		ptab[current_id%N].pattern_num=pat_num;
		if(pat_num>0)
		{
			int k=0;
			ptab[current_id%N].pattern_id = new int[pat_num];
			FOR(i, DFAs.size())
			{
				int * p=DFAs[i]->m_state_table[current[i]].pattern_id;
				int n=DFAs[i]->m_state_table[current[i]].pattern_num;
				copy(p, p+n, ptab[current_id%N].pattern_id+k);
				k+=n;
			}
		}
	}

END_OF_MERGE:

#ifdef DEBUG_DFA
	printf("dump DFA states to disk: [%d, %d)\n", id/N*N, id);
#endif

	for(int i=0; i<id%N; i++)
	{
		FOR(c, m_char_set_size)
		{
			WRITE_INT(ptab[i].next_state[c], stream);
		}

		WRITE_INT(ptab[i].pattern_num, stream);

		FOR(k, ptab[i].pattern_num)
		{
			WRITE_INT(ptab[i].pattern_id[k], stream);
		}
	}

	fseek(stream, 0, SEEK_SET);
	fwrite(md5, sizeof(char), 16, stream);
	WRITE_INT(id, stream);
	fclose(stream);

	FOR(i, N)
	{
		delete [] ptab[i].next_state;
		if(ptab[i].pattern_id != NULL)
			delete [] ptab[i].pattern_id;
	}
	delete [] ptab;
	ptab=NULL;

	FOR(i, DFAs.size()) delete DFAs[i];

	if(!suc_flag)
	{
		remove(dfa_file);
		return -1;
	}

	return id;
}

int CDFA::load_DFA_from_file(const char * dfa_file)
{
#ifdef DEBUG_DFA
	printf("load_DFA_from_file: %s\n", dfa_file);
#endif

	FILE * stream=fopen(dfa_file, "rb");
	if(stream==NULL) return -1;

	fseek(stream, 16, SEEK_SET);
	int ret;

	ret=READ_INT(m_state_num, stream);     assert(ret==1);
	ret=READ_INT(m_char_set_size, stream); assert(ret==1);
	ret=READ_INT(m_initial_state, stream); assert(ret==1);

	m_state_table=new dfa_state_t[m_state_num];
	FOR(i, m_state_num)
	{
		m_state_table[i].next_state=NULL;
		m_state_table[i].pattern_num=0;
		m_state_table[i].pattern_id=NULL;
	}

	FOR(i, m_state_num)
	{
		m_state_table[i].next_state=new int[m_char_set_size];

		FOR(c, m_char_set_size)
		{
			ret=READ_INT(m_state_table[i].next_state[c], stream); assert(ret==1);
		}

		ret=READ_INT(m_state_table[i].pattern_num, stream); assert(ret==1);

		if(m_state_table[i].pattern_num>0)
		{
			m_state_table[i].pattern_id=new int[m_state_table[i].pattern_num];
			FOR(k, m_state_table[i].pattern_num)
			{
				ret=READ_INT(m_state_table[i].pattern_id[k], stream); assert(ret==1);
			}
		}
	}

	fclose(stream);

	//����trap_state
	FOR(i, m_state_num)
	{
		if(m_state_table[i].pattern_num>0) continue;

		int c=0;
		for( ; c<m_char_set_size; c++)
		{
			if(m_state_table[i].next_state[c]!=i) break;
		}
		if(c==m_char_set_size)
		{
			m_trap_state=i;
			break;
		}
	}

	int final_state_num=0;
	FOR(i, m_state_num)
	{
		if(m_state_table[i].pattern_num>0) final_state_num++;
	}

#ifdef DEBUG_DFA
	printf("load DFA finishes: state_num=%d, final_state_num=%d, trap_state=%d.\n", m_state_num, final_state_num, m_trap_state);
#endif

	return 1;
}

#ifdef USE_DFA_PTR
int CDFA::load_DFA_from_file_address(const char * dfa_file)
{
#ifdef DEBUG_DFA
	printf("load_DFA_from_file_address: %s\n", dfa_file);
#endif

	FILE * stream=fopen(dfa_file, "rb");
	if(stream==NULL) return -1;

	fseek(stream, 16, SEEK_SET);

	READ_INT(m_state_num_address, stream);
	READ_INT(m_char_set_size, stream);
	READ_INT(m_initial_state, stream);

	if(m_state_num_address<=0)
	{
		fclose(stream);
		return -1;
	}

	m_state_table_address=new dfa_state_address_t[m_state_num_address];
	FOR(i, m_state_num_address)
	{
		m_state_table_address[i].pattern_num=0;
		m_state_table_address[i].pattern_id=NULL;
	}

	FOR(i, m_state_num_address)
	{
		FOR(c, m_char_set_size)
		{
			int J;
			READ_INT(J, stream);
			m_state_table_address[i].next_state[c]=m_state_table_address+J;
		}

		READ_INT(m_state_table_address[i].pattern_num, stream);

		if(m_state_table_address[i].pattern_num>0)
		{
			m_state_table_address[i].pattern_id=new int[m_state_table_address[i].pattern_num];
			FOR(k, m_state_table_address[i].pattern_num)
			{
				READ_INT(m_state_table_address[i].pattern_id[k], stream);
			}
		}
	}

	fclose(stream);

	int final_state_num=0;
	FOR(i, m_state_num_address)
	{
		if(m_state_table_address[i].pattern_num>0) final_state_num++;
	}

#ifdef DEBUG_DFA
	printf("load DFA finishes: state_num=%d, final_state_num=%d.\n", m_state_num_address, final_state_num);
#endif

	return 1;
}
#endif

int CDFA::load_patterns_from_file(const char * pattern_file, vector<regex_pattern_t>& patterns, bool case_sensitive, unsigned char * md5, unsigned int * failed_ids, unsigned int num)
{
	patterns.clear();

	if(pattern_file==NULL)
	{
		printf_regex_log("[%s:%d]: pattern_file is NULL!\n", __FILE__, __LINE__);
		return -1;
	}

	FILE * stream=fopen(pattern_file, "rb");
	if(stream==NULL)
	{
		printf_regex_log("[%s:%d]: can not open file: %s\n", __FILE__, __LINE__, pattern_file);
		return -1;
	}

	fseek(stream, 0, SEEK_END);
	unsigned int size=ftell(stream);
	fseek(stream, 0, SEEK_SET);

	char * buff=new char[size+1];
	unsigned int ret=(unsigned int)fread(buff, sizeof(char), size, stream);
	if(ret!=size)
	{
		delete [] buff;
		return -1;
	}
	buff[size]=0;
	fclose(stream);

	if(md5!=NULL)
	{
		//��������ļ���md5ֵ
		MD5_CTX md5ctx;
		MD5Init(&md5ctx);
		MD5Update(&md5ctx, (unsigned char *)buff, size);
		MD5Update(&md5ctx, (unsigned char *)&case_sensitive, 1);
		MD5Final(md5, &md5ctx);
	}

	char * pb=buff;
	char * pe=buff+size;

	while(pb<pe)
	{
		char * ps=pb;
		while(ps<pe && *ps!='\t') ++ps;
		if(ps==pe) break;
		*ps=0;

		unsigned int pid=(unsigned int)strtoul(pb, NULL, 10);

		pb=++ps;
		while(ps<pe && *ps!='\n' && *ps!='\r') ++ps;
		if(ps==pb) break;
		*ps='\0';

		const char * re=pb;

		const char * errptr=NULL;
		int erroffset=0;
		pcre * nfa=pcre_compile(re, PCRE_ANCHORED|PCRE_DOTALL|PCRE_DOLLAR_ENDONLY, &errptr, &erroffset, NULL);
		if(nfa==NULL)
		{
			if(failed_ids!=NULL && failed_ids[0]+1<num)
			{
				failed_ids[1+failed_ids[0]] = pid;
				failed_ids[0]++;
			}
			printf_regex_log("invalid regular expression: %s, errptr=%s, erroffset=%d\n", re, errptr, erroffset);
		}
		else
		{
			pcre_free(nfa);

			if(strlen(re)>=2 && re[0]=='.' && re[1]=='*')
			{
				re+=2;
			}

			regex_pattern_t pt;

			pt.pattern_id=pid;
			pt.pattern=re;
			pt.reverse=false;
			pt.forward_NFA=NULL;
			pt.max_len=UINT_MAX;
			pt.min_len=0;

			patterns.push_back(pt);
		}

		pb=++ps;
		while(pb<pe && (*pb=='\n' || *pb=='\r')) ++pb;
	}

	delete [] buff;

	return (int)patterns.size();
}

int CDFA::searching(stream_state_t * streamstate, long long *pattern_ids,
					size_t n_pattern_ids, const char *data, size_t data_len,
					int pos_offset, match_event_handler onEvent, void *context)
{
	memset(streamstate->barrier, 0, m_patterns.size() * sizeof(unsigned int));
	memset(streamstate->match_prefix, 0, m_sub_pattern_num * sizeof(unsigned int));

#ifdef USE_DFA_PTR
	dfa_state_address_t * pCurrState=m_state_table_address+m_initial_state;
#else
	int s=m_TOPK.m_initial_state;
#endif

	for(size_t i = 0; i < data_len; i++) {
		//��ת���Զ�������һ��״̬
		unsigned char c = (unsigned char)data[i];
		if(!m_case_sensitive) c=m_char_map[c];

#ifdef USE_DFA_PTR
		pCurrState=pCurrState->next_state[c];
#else
		s=m_TOPK.next_state(s, c);
#endif

		//��鵱ǰ״̬�Ƿ��й�������
		streamstate->endpos=i;

#ifdef USE_DFA_PTR
		FOR(k, pCurrState->pattern_num)
		{
			unsigned int pid=pCurrState->pattern_id[k];
#else
		for(int t=m_TOPK.m_matched_ptr[s]; t<m_TOPK.m_matched_ptr[s+1]; t++)
		{
			unsigned int pid=m_TOPK.m_matched_patterns[t];
#endif
			unsigned int j=(pid&0xFF);
			pid>>=16;

			if(streamstate->match_prefix[pid]!=j) continue;
			streamstate->match_prefix[pid]++;

			if(streamstate->match_prefix[pid]==m_sub_expr_num[pid]) {
				unsigned int I=m_pid_to_index_I[pid];
				unsigned int J=m_pid_to_index_J[pid];

				if(I < m_patterns.size() && J < m_patterns[I].sub_patterns.size() &&
				   i >= streamstate->barrier[I]) {
					this->backward_search(I, J, pattern_ids, n_pattern_ids, data,
										  data_len, pos_offset, streamstate, onEvent, context);
				}

				streamstate->match_prefix[pid]=0;
			}
		}
	}

	return 1;
}

int CDFA::backward_search(unsigned int I, unsigned int J, long long *pattern_ids,
						  size_t n_pattern_ids, const char *data, size_t data_len,
						  int pos_offset, stream_state_t *streamstate,
						  match_event_handler onEvent, void *context)
{
	const regex_pattern_t *pt = &(m_patterns[I]);

	unsigned int left_most;
	if (streamstate->endpos + 1 >= pt->sub_patterns[J].wnd_size) {
		left_most = streamstate->endpos + 1 - pt->sub_patterns[J].wnd_size;
	} else {
		left_most = 0;
	}

	if(left_most<streamstate->barrier[I]) left_most=streamstate->barrier[I];

	if (m_patterns[I].sub_patterns[J].prefix_max_len == m_patterns[I].sub_patterns[J].prefix_min_len) {
		if (streamstate->endpos + 1 < m_patterns[I].sub_patterns[J].prefix_max_len) {
			return 0;
		}

		streamstate->begpos = streamstate->endpos + 1 - m_patterns[I].sub_patterns[J].prefix_max_len;
		if (streamstate->begpos >= streamstate->barrier[I]) {
			int ret = this->forward_search(I, pattern_ids, n_pattern_ids, data, data_len,
										   pos_offset, streamstate, onEvent, context);
			if (ret == 1) return 1;
		}
		return 0;
	} else {
#ifdef USE_DFA_PTR
		CDFA * dfaptr=(CDFA *)pt->sub_patterns[J].reverse_DFA;
		if(dfaptr==NULL || dfaptr->m_state_num_address<1) return -1;
		dfa_state_address_t * pCurrState=dfaptr->m_state_table_address+dfaptr->m_initial_state;
#else
		CTopKState * dfaptr=(CTopKState  *)pt->sub_patterns[J].reverse_DFA;
		if(dfaptr==NULL || dfaptr->m_state_num<1) return -1;
		int s=dfaptr->m_initial_state;
#endif

		streamstate->cand_num=0;

		for (int i = (int)streamstate->endpos; i >= (int)left_most; --i) {
			unsigned char c = (unsigned char)data[i];
			if(!m_case_sensitive) c=m_char_map[c];

#ifdef USE_DFA_PTR
			pCurrState=pCurrState->next_state[c];
			if(pCurrState==NULL) break;
			if(pCurrState->pattern_num>0)
#else
			s=dfaptr->next_state(s, c);
			if(s==dfaptr->m_trap_state) break;
			if(dfaptr->m_matched_ptr[s]<dfaptr->m_matched_ptr[s+1])
#endif
			{
				streamstate->candidates[streamstate->cand_num++]=i;
			}
		}

		for (int k = (int)streamstate->cand_num - 1; k >= 0; --k) {
			streamstate->begpos = streamstate->candidates[k];
			if (streamstate->begpos >= streamstate->barrier[I]) {
				int ret = this->forward_search(I, pattern_ids, n_pattern_ids, data, data_len,
											   pos_offset, streamstate, onEvent, context);
				if (ret == 1) return 1;
			}
		}

		return 0;
	}
}

int CDFA::forward_search(unsigned int I, long long *pattern_ids, size_t n_pattern_ids,
						 const char *data, size_t data_len, int pos_offset,
						 stream_state_t *streamstate,match_event_handler onEvent,
						 void *context)
{
	const regex_pattern_t *pt = &(m_patterns[I]);
	if(pt->forward_NFA==NULL) return 0;

	int ret = pcre_exec(pt->forward_NFA, NULL, data, data_len, streamstate->begpos,
					  0, streamstate->ovector, OVECSIZE);
	if (ret <= 0) {
		return 0;
	}

	for(int j = 0; j < ret; j++) {
		int from = streamstate->ovector[2 * j]; 
		int to = from + (streamstate->ovector[2 * j + 1] - streamstate->ovector[2 * j]);
		unsigned int m_pat_id = m_patterns[I].pattern_id;
		onEvent(pattern_ids[m_pat_id - 1], pos_offset, from, to, data_len, context);
	}

	streamstate->barrier[I]=streamstate->ovector[1];

	return 1;
}

int re_min_len(const char * re)
{
	parse_tree pt;
	if(pt.parse(re, (int)strlen(re), true)<0) return -1;

	unsigned int max_len, min_len;
	pt.max_min_length(pt.get_root(), max_len, min_len);

	return (int)min_len;
}

#define RE_MIN_LEN  2

/*�ֲ� .* �� .{m,n} ����� */
bool dotstar_or_dotrepeat(const parse_tree_node_t * nodeptr)
{
	return (nodeptr!=NULL) 
		&& (nodeptr->type==RE_ASTERISK || nodeptr->type==RE_BRACE) 
		&& (nodeptr->lchild!=NULL) 
		&& (nodeptr->lchild->type==RE_DOT);
}

/*��ȷ�ַ���*/
bool is_exact_string(const parse_tree_node_t * nodeptr)
{
	if(nodeptr==NULL) return false;

	if(nodeptr->type==RE_CONCAT)
	{
		return is_exact_string(nodeptr->lchild) && is_exact_string(nodeptr->rchild);
	}
	else
	{
		return (nodeptr->type==RE_NORMAL_CHAR);
	}
}

/* ����A|B|C��ѡ��*/
bool is_union_string(const parse_tree_node_t * nodeptr)
{
	if(nodeptr==NULL) return false;

	if(nodeptr->type==RE_UNION)
	{
		return is_union_string(nodeptr->lchild) && is_union_string(nodeptr->rchild);
	}
	else
	{
		return is_exact_string(nodeptr);
	}
}

/* ����(A|B|C)(D|E|F)(G|H|I)����ϴ�*/
bool is_compound_string(const parse_tree_node_t * nodeptr)
{
	if(nodeptr==NULL) return false;

	if(nodeptr->type==RE_CONCAT)
	{
		return is_compound_string(nodeptr->lchild) && is_compound_string(nodeptr->rchild);
	}
	else
	{
		return is_union_string(nodeptr);
	}
}

bool is_char_fixed_repeat(const parse_tree_node_t * nodeptr)
{
	return nodeptr!=NULL
		&& nodeptr->type==RE_BRACE
		&& nodeptr->tag[0]==nodeptr->tag[1]
		&& nodeptr->lchild!=NULL
		&& nodeptr->lchild->type==RE_NORMAL_CHAR; 
}

int CDFA::split_rule(sub_regex_pattern_t * pat)
{
	const char * re=pat->pattern.c_str();

	parse_tree pt;
	if(pt.parse(re, (int)strlen(re), true)<0)
	{
		return -1;
	}

	parse_tree_node_t * nodeptr=pt.get_root();
	if(nodeptr==NULL) return -1;

	if(is_compound_string(nodeptr))
	{
		pat->factors.push_back(pat->pattern);
		pat->prefix=pat->pattern;
		return (int)pat->factors.size();
	}

	vector<parse_tree_node_t *> node_array;
	vector<cstring> node_expr;

	while(nodeptr!=NULL && nodeptr->type==RE_CONCAT)
	{
		if(nodeptr->rchild!=NULL)
		{
			node_array.push_back(nodeptr->rchild);
			node_expr.push_back(pt.parse_tree_to_expr(nodeptr->rchild));
		}
		nodeptr=nodeptr->lchild;
	}
	if(nodeptr!=NULL)
	{
		node_array.push_back(nodeptr);
		node_expr.push_back(pt.parse_tree_to_expr(nodeptr));
	}
	std::reverse(node_array.begin(), node_array.end());
	std::reverse(node_expr.begin(), node_expr.end());

	cstring s, prefix;

	FOR(k, (int)node_array.size())
	{
		if(node_array[k]->type==RE_NORMAL_CHAR 
			|| is_compound_string(node_array[k]) 
			|| is_char_fixed_repeat(node_array[k]))
		{
			s+=node_expr[k];
		}
		else if(node_array[k]->type==RE_PLUS) 
		{
			cstring t;
			if( (node_array[k]->lchild!=NULL) 
				&& (node_array[k]->lchild->type==RE_NORMAL_CHAR || is_compound_string(node_array[k]->lchild)))
			{
				t=pt.parse_tree_to_expr(node_array[k]->lchild);
				s+=t;
			}

			if(s.length()>0 && re_min_len(s.c_str())>=RE_MIN_LEN)
			{
				pat->factors.push_back(s);
				pat->prefix=prefix+t;
			}
			s="";
		}
		else if(node_array[k]->type==RE_BRACE) 
		{
			cstring t;
			if(node_array[k]->lchild!=NULL && node_array[k]->lchild->type==RE_NORMAL_CHAR)
			{
				FOR(i, node_array[k]->tag[0])
				{
					t+=pt.parse_tree_to_expr(node_array[k]->lchild);
				}
				s+=t;
			}

			if(s.length()>0 && re_min_len(s.c_str())>=RE_MIN_LEN)
			{
				pat->factors.push_back(s);
				pat->prefix=prefix+t;
			}
			s="";
		}
		else
		{
			if(s.length()>0 && re_min_len(s.c_str())>=RE_MIN_LEN)
			{
				pat->factors.push_back(s);
				pat->prefix=prefix;
			}
			s="";
		}

		prefix+=node_expr[k];
	}

	if(s.length()>0 && re_min_len(s.c_str())>=RE_MIN_LEN)
	{
		pat->factors.push_back(s);
		pat->prefix=prefix;
	}
	s="";

	if(pat->factors.size()>0)
	{
		return (int)pat->factors.size();
	}

	prefix="";
	pat->prefix="";

	int star_repeat_num=0;
	FOR(k, (int)node_array.size())
	{
		if(dotstar_or_dotrepeat(node_array[k])) star_repeat_num++;
	}
	if(star_repeat_num==0)
	{
		pat->prefix=pat->pattern;
		pat->factors.push_back(pat->pattern);
		return (int)pat->factors.size();
	}

	FOR(k, (int)node_array.size())
	{
		if(dotstar_or_dotrepeat(node_array[k])) 
		{
			if(s.length()>0 && re_min_len(s.c_str())>=RE_MIN_LEN)
			{
				pat->factors.push_back(s);
				pat->prefix=prefix;
			}
			s="";
		}
		else
		{
			s+=node_expr[k];
		}

		prefix+=node_expr[k];
	}

	if(s.length()>0 && re_min_len(s.c_str())>=RE_MIN_LEN)
	{
		pat->factors.push_back(s);
		pat->prefix=prefix;
	}
	s="";

	if(pat->factors.size()==0)
	{
		pat->prefix=pat->pattern;
		pat->factors.push_back(pat->pattern);
	}

	return (int)pat->factors.size();
}

int split_a_union_rule(const char * re, vector<cstring>& sub_exprs)
{
	sub_exprs.clear();
	int n=(int)strlen(re);
	parse_tree pt;
	if(pt.parse(re, n, true)<0) return -1;

	parse_tree_node_t * root=pt.get_root();
	if(root==NULL) return -1;

	queue<parse_tree_node_t *> node_queue;
	set<unsigned int> pos;

	for(node_queue.push(root); !node_queue.empty(); node_queue.pop())
	{
		parse_tree_node_t * nodeptr=node_queue.front();
		if(nodeptr->type==RE_UNION)
		{
			if(nodeptr->lchild!=NULL) node_queue.push(nodeptr->lchild);
			if(nodeptr->rchild!=NULL) node_queue.push(nodeptr->rchild);
			pos.insert(nodeptr->pos);
		}
	}

	unsigned int last_pos=0;
	for(set<unsigned int>::const_iterator it=pos.begin(); it!=pos.end(); ++it)
	{
		cstring s(re+last_pos, re+*it);
		if(s.size()>0) sub_exprs.push_back(s);
		last_pos=*it+1;
	}
	if(last_pos<(unsigned int)n)
	{
		cstring s=re+last_pos;
		if(s.size()>0) sub_exprs.push_back(s);
	}

	if(sub_exprs.size()==0)
	{
		sub_exprs.push_back(cstring(re));
		return sub_exprs.size();
	}

	for(unsigned int j=0; j<sub_exprs.size(); j++)
	{
		parse_tree pt;
		if(pt.parse(sub_exprs[j].c_str(), sub_exprs[j].length(), true)<0)
		{
			sub_exprs.clear();
			sub_exprs.push_back(cstring(re));
			return sub_exprs.size();
		}
	}

	return sub_exprs.size();
}

int CDFA::translate_rules(const char * rule_file, vector<regex_pattern_t>& patterns, const char * ext_rule_file)
{
	m_sub_pattern_num=0;
	FOR(t, 65536)
	{
		m_pid_to_index_I[t]=-1;
		m_pid_to_index_J[t]=-1;
		m_sub_expr_num[t]=0;
	}

	if(ext_rule_file==NULL) return -1;
	FILE * fp=fopen(ext_rule_file, "wb");
	if(fp==NULL) return -1;

	int ret;

	FOR(i, (int)patterns.size())
	{
		vector<cstring> sub_exprs;
		ret=split_a_union_rule(patterns[i].pattern.c_str(), sub_exprs);
		if(ret<0) continue;

		for(unsigned int j=0; j<sub_exprs.size(); j++)
		{
			sub_regex_pattern_t sp;

			sp.pattern=sub_exprs[j];
			sp.reverse_DFA=NULL;
			sp.wnd_size=65536;
			sp.prefix_min_len=0;
			sp.prefix_max_len=UINT_MAX;

			patterns[i].sub_patterns.push_back(sp);

			int ret=split_rule(&(patterns[i].sub_patterns[j]));
			if(ret<0)
			{
				printf_regex_log("[%s: %d]: invalid regular expression: pattern_id=%u, pattern=%s\n", __FILE__, __LINE__, patterns[i].pattern_id, patterns[i].pattern.c_str());
				continue;
			}

			if(m_sub_pattern_num>=65536) return -1;

			for(unsigned int k=0; k<patterns[i].sub_patterns[j].factors.size(); k++)
			{
				fprintf(fp, "%u\t%s\n", (m_sub_pattern_num<<16)+k, patterns[i].sub_patterns[j].factors[k].c_str());
			}

			m_pid_to_index_I[m_sub_pattern_num]=i;
			m_pid_to_index_J[m_sub_pattern_num]=j;
			m_sub_expr_num[m_sub_pattern_num]=patterns[i].sub_patterns[j].factors.size();
			m_sub_pattern_num++;

			fflush(fp);
		}
	}

	fclose(fp);

	return 1;
}
