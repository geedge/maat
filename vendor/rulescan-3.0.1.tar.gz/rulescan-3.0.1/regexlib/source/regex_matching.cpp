#include "../include/regex_matching.h"
#include "parse_tree/ParseTree.h"
#include "DFA.h"
#include "partition.h"
#include "regex_def.h"

/* DFA queue */
struct dfa_matcher {
	CDFA **DFAs;
	unsigned int n_DFAs;
	unsigned int thread_num;
	stream_state_t *stream_states;
};

struct dfa_matcher *regex_preprocessing(const char *rule_file, size_t thread_num,
						  				bool case_sensitive, int max_state_num,
						  				unsigned int *failed_ids, unsigned int num)
{
	clear_regex_log();

	if (NULL == rule_file) {
		return NULL;
	}

	if (0 == thread_num) {
		printf_regex_log("[%s: %d]: thread_num==0!\n", 
						 __FILE__, __LINE__);
		return NULL;
	}

	if (max_state_num <= 0) {
		printf_regex_log("[%s: %d]: max_state_num<=0!\n", 
						 __FILE__, __LINE__);
		return NULL;
	}

	if (failed_ids != NULL && num == 0) {
		printf_regex_log("[%s: %d]: failed_ids!=NULL && num==0!\n", 
						 __FILE__, __LINE__);
		return NULL;
	}

	if (failed_ids != NULL) {
		failed_ids[0] = 0;
	}

	struct dfa_matcher *matcher = new struct dfa_matcher;
	matcher->n_DFAs = 0;
	matcher->DFAs = NULL;
	matcher->thread_num = thread_num;
	matcher->stream_states = new stream_state_t[thread_num];

	/* Grouping and establish DFA for each group */
	vector<cstring> part_files;

	part_files.push_back(cstring(rule_file));

	if (part_files.size() > 0) {
		int N = (int)part_files.size();

		matcher->n_DFAs = N;
		matcher->DFAs = new CDFA*[N];

		FOR(i, N) {
			matcher->DFAs[i] = new CDFA;
			if(matcher->DFAs[i]->preprocessing(part_files[i].c_str(), case_sensitive,
											   failed_ids, num, max_state_num, false) < 0) {
				delete matcher->DFAs[i];
				matcher->DFAs[i] = NULL;
				printf_regex_log("[%s: %d]: DFA preprocessing for %s failed!\n",
								 __FILE__, __LINE__, part_files[i].c_str());
				delete [] matcher->DFAs;
				delete [] matcher->stream_states;
				delete matcher;
				return NULL;
			}
		}
	}

	return matcher;
}

int regex_searching(struct dfa_matcher *matcher, long long *pattern_ids,
					size_t n_pattern_ids, int thread_id, const char *data,
					size_t data_len, int pos_offset, match_event_handler onEvent,
					void *context)
{
	if (NULL == matcher) {
		printf_regex_log("[%s: %d]: matcher==NULL!\n", __FILE__, __LINE__);
		return -1;
	}

	if (data==NULL || data_len==0) {
		printf_regex_log("[%s: %d]: text==NULL!\n", __FILE__, __LINE__);
		return -1;
	}

	if (thread_id >= (int)matcher->thread_num) {
		printf_regex_log("[%s: %d]: thread_id>=dfa_matcher->thread_num!\n",
						__FILE__, __LINE__);
		return -1;
	}

	FOR(i, matcher->n_DFAs) {
		if (matcher->DFAs[i] != NULL) {
			int ret = matcher->DFAs[i]->searching(matcher->stream_states+thread_id,
												  pattern_ids, n_pattern_ids, data,
												  data_len, pos_offset, onEvent, context);
			if (ret < 0) {
				printf_regex_log("[%s: %d]: DFA[%d] searching failed!\n", 
								__FILE__, __LINE__, i);
			}
		}
	}

	return 0;
}

void regex_destroy(struct dfa_matcher *matcher)
{
	if (matcher != NULL) {
		if (matcher->n_DFAs > 0) {
			FOR(i, matcher->n_DFAs) {
				if (matcher->DFAs[i] != NULL) {
					delete matcher->DFAs[i];
				}
			}
			delete [] matcher->DFAs;
		}
		delete [] matcher->stream_states;
		delete matcher;
	}
}
