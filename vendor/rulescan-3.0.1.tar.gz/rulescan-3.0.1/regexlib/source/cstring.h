#ifndef H_C_STRING_CPP_H
#define H_C_STRING_CPP_H

class cstring
{
public:
	cstring();
	cstring(const char * str);
	cstring(const char * s, const char * e);
	cstring(char c);
	cstring(const cstring& rhs);
	~cstring();

	cstring& operator= (const cstring &rhs);
	cstring& operator+=(const cstring& rhs);
	char& operator[](int i);

	const char * c_str();
	unsigned int length();
	unsigned int size();

private:
	char * m_str;
};

cstring operator+(const cstring& lhs, const cstring& rhs);

#endif

