#include "ThompsonNFA.h"

bool operator<(const nfa_state_t& lhs, const nfa_state_t& rhs)
{
	if(lhs.state_id!=rhs.state_id) return (lhs.state_id< rhs.state_id);
	return false;
}

bool operator<(const nfa_trans_t& lhs, const nfa_trans_t& rhs)
{
	if(lhs.fr!=rhs.fr) return (lhs.fr<rhs.fr);
	if(lhs.ch!=rhs.ch) return (lhs.ch<rhs.ch);
	if(lhs.to!=rhs.to) return (lhs.to<rhs.to);
	return false;
}

CThompsonNFA::CThompsonNFA()
{
	m_state_num=0;
	m_trans_num=0;
	m_eps_trans_num=0;
	m_pat_id=NULL;
	m_eps_closure_ptr=NULL;
	m_eps_closure_buff=NULL;
	m_next_state_ptr=NULL;
	m_next_state_buff=NULL;
}

CThompsonNFA::~CThompsonNFA()
{
	m_state_num=0;
	m_trans_num=0;
	m_eps_trans_num=0;
	if(m_pat_id!=NULL) delete [] m_pat_id;
	if(m_eps_closure_ptr!=NULL) delete [] m_eps_closure_ptr;
	if(m_eps_closure_buff!=NULL) delete [] m_eps_closure_buff;
	if(m_next_state_ptr!=NULL) delete [] m_next_state_ptr;
	if(m_next_state_buff!=NULL) delete [] m_next_state_buff;
}

void CThompsonNFA::ClearNFA()
{
	m_state.clear();
	m_trans.clear();
	m_eps_trans.clear();
}

int CThompsonNFA::BuildNFA(regex_pattern_t * pat, bool case_sensitive, bool anchored)
{
	int ret=-1;

#ifdef DEBUG_THOMPSON_NFA
	printf_regex_log("build NFA for pattern_id=%u, pattern=%s\n", pat->pattern_id, pat->pattern.c_str());
#endif

	const char * ps=pat->pattern.c_str();
	int n=(int)pat->pattern.length();

	if(!anchored)
	{
		FOR(c, 256)
		{
			nfa_trans_t self_loop;

			self_loop.fr=0;
			self_loop.to=0;
			self_loop.ch=c;

			m_trans.push_back(self_loop);
		}
	}

	parse_tree pt;

	if(pt.parse(ps, n, case_sensitive)<0)
	{
		printf_regex_log("[%s: %d]: build parse tree for pattern_id=%u failed!\n", __FILE__, __LINE__, pat->pattern_id);
		return -1;
	}

	pt.max_min_length(pt.get_root(), pat->max_len, pat->min_len);

	ret=this->BuildAutomata(pt.get_root(), 0, pat->pattern_id, pat->reverse);
	if(ret<0)
	{
		printf_regex_log("[%s: %d]: BuildAutomata() for pattern_id=%u failed!\n", __FILE__, __LINE__, pat->pattern_id);
		return -1;
	}

	sort(m_state.begin(), m_state.end());
	sort(m_trans.begin(), m_trans.end());
	sort(m_eps_trans.begin(), m_eps_trans.end());

#ifdef DEBUG_THOMPSON_NFA
	//this->ShowNFA(stdout);
	//FILE * stream=fopen("__nfa.txt", "w");
	//this->ShowNFA(stream);
	//fclose(stream);
#endif

	FOR(i, m_state.size())
	{
		if(m_state[i].state_id!=i)
		{
			printf_regex_log("[%s: %d]: NFA inconsitent!\n", __FILE__, __LINE__);
		}
	}

#ifdef DEBUG_THOMPSON_NFA
	printf_regex_log("start to build NFA EpsClosure...\n");
#endif
	//ret=this->BuildEpsClosure();
	//ret=this->BuildEpsClosure_Warshall();
	ret=this->BuildEpsClosure_Graphsearch();
	if(ret>=0)
	{
#ifdef DEBUG_THOMPSON_NFA
		printf_regex_log("build NFA EpsClosure finished!\n");
#endif
	}
	else
	{
		printf_regex_log("[%s: %d]: build NFA EpsClosure failed!\n", __FILE__, __LINE__);
		return -1;
	}

#ifdef DEBUG_THOMPSON_NFA
	printf_regex_log("start NFA::optmize_storage()...\n");
#endif
	ret=this->optmize_storage();
	if(ret>=0)
	{
#ifdef DEBUG_THOMPSON_NFA
		printf_regex_log("NFA::optmize_storage() finished: NFA_state_num=%d, NFA_trans_num=%d, NFA_eps_trans_num=%d, NFA_memory=%lf (MB)\n", 
			m_state_num, m_trans_num, m_eps_trans_num, (double)ret/(1<<20));
#endif
	}
	else
	{
		printf_regex_log("[%s: %d]: NFA::optmize_storage() failed!\n", __FILE__, __LINE__);
		return -1;
	}

	this->ClearNFA();

	return 1;
}

int CThompsonNFA::BuildAutomata(parse_tree_node_t * root, int start_id, int pat_id, bool reverse)
{
	if(root==NULL) return start_id;

	CThompsonNFA nfal, nfar;
	nfa_state_t initial, final;
	nfa_trans_t trans, ieps, feps, ieps1, ieps2, feps1, feps2;

	switch(root->type)
	{
	case RE_EPSILON:
		{
			initial.state_id=start_id++;
			initial.pat_id=-1;
			m_state.push_back(initial);

			final.state_id=start_id++;
			final.pat_id=pat_id;
			m_state.push_back(final);

			trans.fr=initial.state_id;
			trans.to=final.state_id;
			trans.ch=RE_EPSILON;
			m_eps_trans.push_back(trans);
		}
		break;

	case RE_NORMAL_CHAR:
		{
			initial.state_id=start_id++;
			initial.pat_id=-1;
			m_state.push_back(initial);

			final.state_id=start_id++;
			final.pat_id=pat_id;
			m_state.push_back(final);

			trans.fr=initial.state_id;
			trans.to=final.state_id;
			trans.ch=(int)root->tag[0];
			m_trans.push_back(trans);
		}
		break;

	case RE_CONCAT:
		{
			if(root->lchild==NULL || root->rchild==NULL)
			{
				printf_regex_log("[%s: %d]: invalid parse tree!\n", __FILE__, __LINE__);
				return -1;
			}

			if(!reverse) //����˳����Զ���
			{
				start_id=nfal.BuildAutomata(root->lchild, start_id, pat_id, reverse);
				this->CopyNFA(nfal);

				--start_id;
				m_state.pop_back();

				start_id=nfar.BuildAutomata(root->rchild, start_id, pat_id, reverse);
				this->CopyNFA(nfar);
			}
			else //���췴����Զ���
			{
				start_id=nfar.BuildAutomata(root->rchild, start_id, pat_id, reverse);
				this->CopyNFA(nfar);

				--start_id;
				m_state.pop_back();

				start_id=nfal.BuildAutomata(root->lchild, start_id, pat_id, reverse);
				this->CopyNFA(nfal);
			}
		}
		break;

	case RE_UNION:
		{
			if(root->lchild==NULL || root->rchild==NULL)
			{
				printf_regex_log("[%s: %d]: invalid parse tree!\n", __FILE__, __LINE__);
				return -1;
			}

			initial.state_id=start_id++;
			initial.pat_id=-1;
			m_state.push_back(initial);

			start_id=nfal.BuildAutomata(root->lchild, start_id, pat_id, reverse);
			nfal.m_state.end()[-1].pat_id=-1;
			this->CopyNFA(nfal);

			start_id=nfar.BuildAutomata(root->rchild, start_id, pat_id, reverse);
			nfar.m_state.end()[-1].pat_id=-1;
			this->CopyNFA(nfar);

			final.state_id=start_id++;
			final.pat_id=pat_id;
			m_state.push_back(final);

			ieps1.fr=initial.state_id;
			ieps1.to=nfal.m_state[0].state_id;
			ieps1.ch=RE_EPSILON;
			m_eps_trans.push_back(ieps1);

			ieps2.fr=initial.state_id;
			ieps2.to=nfar.m_state[0].state_id;
			ieps2.ch=RE_EPSILON;
			m_eps_trans.push_back(ieps2);

			feps1.fr=nfal.m_state.end()[-1].state_id;
			feps1.to=final.state_id;
			feps1.ch=RE_EPSILON;
			m_eps_trans.push_back(feps1);

			feps2.fr=nfar.m_state.end()[-1].state_id;
			feps2.to=final.state_id;
			feps2.ch=RE_EPSILON;			
			m_eps_trans.push_back(feps2);
		}
		break;

	case RE_ASTERISK:
	case RE_PLUS:
	case RE_QUESTION_MARK:
	case RE_BRACE:
		{
			if(root->lchild==NULL)
			{
				printf_regex_log("[%s: %d]: invalid parse tree!\n", __FILE__, __LINE__);
				return -1;
			}

			int n1=root->tag[0];
			int n2=root->tag[1];

			if((unsigned int)n2==UINT_MAX)
			{
				FOR(i, n1-1)
				{
					nfal.ClearNFA();
					start_id=nfal.BuildAutomata(root->lchild, start_id, pat_id, reverse);
					this->CopyNFA(nfal);

					--start_id;
					m_state.pop_back();
				}

				nfal.ClearNFA();
				start_id=nfal.BuildAutomata(root->lchild, start_id, pat_id, reverse);
				this->CopyNFA(nfal);

				feps.fr=nfal.m_state.end()[-1].state_id;
				feps.to=nfal.m_state[0].state_id;
				feps.ch=RE_EPSILON;
				m_eps_trans.push_back(feps);

				if(n1==0)
				{
					ieps.fr=nfal.m_state[0].state_id;
					ieps.to=nfal.m_state.end()[-1].state_id;
					ieps.ch=RE_EPSILON;
					m_eps_trans.push_back(ieps);
				}
			}
			else if(n2==0)
			{
				initial.state_id=start_id++;
				initial.pat_id=-1;
				m_state.push_back(initial);

				final.state_id=start_id++;
				final.pat_id=pat_id;
				m_state.push_back(final);

				trans.fr=initial.state_id;
				trans.to=final.state_id;
				trans.ch=RE_EPSILON;
				m_eps_trans.push_back(trans);
			}
			else
			{
				vector<int> v;

				FOR(i, n2)
				{
					if(i>=(int)n1) v.push_back(start_id);

					nfal.ClearNFA();
					start_id=nfal.BuildAutomata(root->lchild, start_id, pat_id, reverse);
					this->CopyNFA(nfal);

					if(i<(int)n2-1)
					{
						--start_id;
						m_state.pop_back();
					}
				}

				FOR(k, v.size())
				{
					trans.fr=v[k];
					trans.to=start_id-1;
					trans.ch=RE_EPSILON;
					m_eps_trans.push_back(trans);
				}
			}
		}
		break;

	case RE_DOT:
	case RE_BRACKET:
		{
			initial.state_id=start_id++;
			initial.pat_id=-1;

			final.state_id=start_id++;
			final.pat_id=pat_id;

			m_state.push_back(initial);
			m_state.push_back(final);

			FOR(c, 256)
			{
				if(root->tag[c>>5]&(1U<<(c&31)))
				{
					trans.fr=initial.state_id;
					trans.to=final.state_id;
					trans.ch=c;
					m_trans.push_back(trans);
				}
			}
		}
		break;

	default:
		break;
	}

	return start_id;
}

void CThompsonNFA::CopyNFA(const CThompsonNFA& rhs)
{
	vcopy(rhs.m_state, m_state);
	vcopy(rhs.m_trans, m_trans);
	vcopy(rhs.m_eps_trans, m_eps_trans);
}

int CThompsonNFA::optmize_storage()
{
	int mem_bytes=0;

	m_state_num=(int)m_state.size();
	m_trans_num=(int)m_trans.size();
	m_eps_trans_num=(int)m_eps_trans.size();

	m_pat_id=new int[m_state_num+1];
	mem_bytes+=(m_state_num+1)*sizeof(int);
	FOR(i, m_state_num) m_pat_id[i]=m_state[i].pat_id;

	m_eps_closure_ptr=new int[m_state_num+1];
	mem_bytes+=(m_state_num+1)*sizeof(int);
	int eps_closure_size=0;
	FOR(i, m_state_num) eps_closure_size+=(int)m_state[i].eps_closure.size();
	m_eps_closure_buff=new int[eps_closure_size+1];
	mem_bytes+=(eps_closure_size+1)*sizeof(int);
	int k=0;
	FOR(i, m_state_num)
	{
		m_eps_closure_ptr[i]=k;
		copy(m_state[i].eps_closure.begin(), m_state[i].eps_closure.end(), m_eps_closure_buff+k);
		k+=(int)m_state[i].eps_closure.size();
	}
	m_eps_closure_ptr[m_state_num]=eps_closure_size;

	m_next_state_ptr=new int[m_state_num*256+1];
	mem_bytes+=(m_state_num*256+1)*sizeof(int);
	FOR(i, m_state_num*256+1) m_next_state_ptr[i]=0;
	m_next_state_buff=new int[m_trans.size()+1];
	mem_bytes+=((int)m_trans.size()+1)*sizeof(int);
	FOR(i, m_trans.size())
	{
		m_next_state_ptr[m_trans[i].fr*256+m_trans[i].ch]++;
		m_next_state_buff[i]=m_trans[i].to;
	}
	for(int i=1; i<=m_state_num*256; i++)
	{
		m_next_state_ptr[i]+=m_next_state_ptr[i-1];
	}
	for(int i=m_state_num*256; i>0; i--)
	{
		m_next_state_ptr[i]=m_next_state_ptr[i-1];
	}
	m_next_state_ptr[0]=0;

	return mem_bytes;
}

void CThompsonNFA::ShowNFA(FILE * stream)
{
	fprintf(stream, "Thompson NFA states (state_num=%d):\n", (int)m_state.size());
	FOR(i, m_state.size())
	{
		fprintf(stream, "state_id=%d, pat_id=%d\n", m_state[i].state_id, m_state[i].pat_id);
	}

	fprintf(stream, "Thompson NFA transitions (trans_num=%d):\n", (int)m_trans.size());
	FOR(i, m_trans.size())
	{
		fprintf(stream, "from=%d, to=%d, ch=%d\n", m_trans[i].fr, m_trans[i].to, m_trans[i].ch);
	}

	fprintf(stream, "Thompson NFA epsilon transitions (eps_trans_num=%d):\n", (int)m_eps_trans.size());
	FOR(i, m_eps_trans.size())
	{
		fprintf(stream, "from=%d, to=%d, ch=%d\n", m_eps_trans[i].fr, m_eps_trans[i].to, m_eps_trans[i].ch);
	}
}

int CThompsonNFA::BuildEpsClosure()
{
	FOR(i, m_state.size())
	{
		m_state[i].eps_closure.insert(m_state[i].state_id);
	}

	bool changed=true;
	while(changed)
	{
		changed=false;
		FOR(i, m_eps_trans.size())
		{
			int fr=m_eps_trans[i].fr;
			int to=m_eps_trans[i].to;

			for(set<int>::iterator pb=m_state[to].eps_closure.begin(), pe=m_state[to].eps_closure.end(); 
				pb!=pe; ++pb)
			{
				changed=changed || m_state[fr].eps_closure.insert(*pb).second;
			}
		}
	}
	return 1;
}

int CThompsonNFA::BuildEpsClosure_Warshall()
{
	const unsigned long long ONE=1;
	unsigned int N=m_state.size();
	unsigned int M=((N+63)>>6);
	unsigned long long * A=new unsigned long long[N*M];

	memset(A, 0, N*M*sizeof(unsigned long long));

	FOR(k, m_eps_trans.size())
	{
		int i=m_eps_trans[k].fr;
		int j=m_eps_trans[k].to;
		A[i*M+(j>>6)]|=(ONE<<(j&63));
	}

	FOR(k, N)
	{
		FOR(i, N)
		{
			if(k!=i && (A[i*M+(k>>6)]&(ONE<<(k&63))))
			{
				FOR(j, M) A[i*M+j]|=A[k*M+j];
			}
		}
	}

	FOR(i, N)
	{
		m_state[i].eps_closure.insert(i);
		FOR(j, N)
		{
			if(A[i*M+(j>>6)]&(ONE<<(j&63)))
			{
				m_state[i].eps_closure.insert(j);
			}
		}
	}

	delete [] A;
	return 1;
}

int CThompsonNFA::BuildEpsClosure_Graphsearch()
{
	int sn= m_state.size();
	unsigned char *flag = new unsigned char[sn+1];

	for(int i=sn-1; i>=0; i--)
	{
		memset(flag, 0x00, sizeof(char)*(sn+1));
		flag[i]=1;
		stack<int> stk;	
		stk.push(i);
		while(!stk.empty())
		{
			int top=stk.top();
			stk.pop();
			m_state[i].eps_closure.insert(top);
			FOR(j, m_eps_trans.size())
			{
				if(top==m_eps_trans[j].fr && flag[m_eps_trans[j].to]==0)
				{
					int ts=m_eps_trans[j].to;	

					if(m_state[ts].eps_closure.size()>0) //�Ѽ�����Ĳ��ظ�����
					{	
						for(set<int>::const_iterator itr=m_state[ts].eps_closure.begin(); 
							itr!=m_state[ts].eps_closure.end(); ++itr)
						{
							m_state[i].eps_closure.insert(*itr);
							flag[*itr]=1;
						}
					}
					else
					{
						stk.push(m_eps_trans[j].to);
						flag[m_eps_trans[j].to]=1;
					}	
				}
			}	
		}
	}

	delete [] flag;

	return 1;
}

vector<int> CThompsonNFA::get_start_states()
{
	if(m_state_num>0)
	{
		int F=m_eps_closure_ptr[0];
		int L=m_eps_closure_ptr[1];
		return vector<int>(m_eps_closure_buff+F, m_eps_closure_buff+L);
	}
	else
	{
		return vector<int>();
	}
}

vector<int> CThompsonNFA::get_next_states(const vector<int>& states, int c)
{
	set<int> next;

	FOR(i, states.size())
	{
		if(states[i]<0 || states[i]>=m_state_num)
		{
			printf_regex_log("[%s: %d]: invalid state id!\n", __FILE__, __LINE__);
			continue;
		}
		int k=states[i]*256+c;
		for(int F=m_next_state_ptr[k], L=m_next_state_ptr[k+1]; F<L; ++F)
		{
			int x=m_next_state_buff[F];
			for(int p=m_eps_closure_ptr[x], q=m_eps_closure_ptr[x+1]; p<q; ++p)
			{
				next.insert(m_eps_closure_buff[p]);
			}
		}
	}

	return vector<int>(next.begin(), next.end());
}

vector<int> CThompsonNFA::get_matched_patterns(const vector<int>& states)
{
	vector<int> v;

	FOR(i, states.size())
	{
		int k=states[i];
		if(k<0 || k>=m_state_num)
		{
			printf_regex_log("[%s: %d]: invalid state id!\n", __FILE__, __LINE__);
			continue;
		}
		int pat_id=m_pat_id[k];
		if(pat_id>=0) v.push_back(pat_id);
	}

	return v;
}
