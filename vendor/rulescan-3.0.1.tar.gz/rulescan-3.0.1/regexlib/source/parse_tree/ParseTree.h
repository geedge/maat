/*
 *
 * Copyright (c) 2008--2009
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:        Liu Yanbing    (liuyanbing@software.ict.ac.cn)
 * Date:           2009-01-08
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written permission 
 * from the authors.
 *
 */

/*
	build a binary parse tree for regular expression
*/

#ifndef H_PARSE_TREE_CPP_H
#define H_PARSE_TREE_CPP_H

//#define DEBUG_PARSE_TREE

#include "../regex_def.h"
#include "../cstring.h"

#define RE_EPSILON                  -1 /* epsilon character */
#define RE_NORMAL_CHAR               0 /* normal character */
#define RE_CONCAT                    1 /* concatenation */
#define RE_UNION                     2 /* union: | */
#define RE_ASTERISK                  3 /* asterisk: * */
#define RE_PLUS                      4 /* plus: + */
#define RE_QUESTION_MARK             5 /*question mark: ? */
#define RE_BRACE                     6 /* brace: {} */
#define RE_BRACKET                   7 /* bracket: [] */
#define RE_DOT                       8 /* dot: . */
#define RE_PARENTHESIS               9 /* parenthesis: () */

typedef struct _parse_tree_node_t
{
	unsigned int type;
	unsigned int tag[8];
	unsigned int pos;
	_parse_tree_node_t * lchild;
	_parse_tree_node_t * rchild;
	_parse_tree_node_t * link;
}parse_tree_node_t;

class parse_tree
{
public:
	parse_tree();

	~parse_tree();

	int parse(const char * p, int n, bool case_sensitive, const char * parse_tree_file=NULL);

	parse_tree_node_t * get_root();

	int max_min_length(parse_tree_node_t * root, unsigned int& _max, unsigned int& _min);

	cstring parse_tree_to_expr(parse_tree_node_t * root);

private:
	void do_operation();

	void push_operator(parse_tree_node_t * node);

	parse_tree_node_t * new_node();

	void print(vector<cstring>& vs, parse_tree_node_t * root, int depth);

	int parse_character_class(const char * p, int n, parse_tree_node_t * node);

	int parse_char_or_escape(const char * p, int n, parse_tree_node_t * node);

	int parse_repeat(const char * p, int n, parse_tree_node_t * node);

public:
	parse_tree_node_t * m_root;
	parse_tree_node_t * m_head;
	int m_node_count;

	stack<parse_tree_node_t *> m_operators;
	stack<parse_tree_node_t *> m_operands;
	int * m_priority;

	unsigned int m_is_meta_char[8];
};

#endif

