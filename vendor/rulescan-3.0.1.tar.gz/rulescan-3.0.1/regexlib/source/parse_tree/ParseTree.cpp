/*
*
* Copyright (c) 2008--2009
* DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Authors:        Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Date:           2009-01-08
*
* This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

#include "ParseTree.h"

#define set_bit(bitmap, c)     ( (bitmap)[(c)>>5]|=(1U<<((c)&31)) )
#define test_bit(bitmap, c)     ( (bitmap)[(c)>>5]&(1U<<((c)&31)) )

parse_tree::parse_tree()
{
	m_root=NULL;
	m_head=NULL;
	m_node_count=0;

	m_priority=new int[256];
	FOR(i, 256) m_priority[i]=-1;

	m_priority[RE_ASTERISK]=100;
	m_priority[RE_PLUS]=100;
	m_priority[RE_QUESTION_MARK]=100;
	m_priority[RE_BRACE]=100;

	m_priority[RE_CONCAT]=90;

	m_priority[RE_UNION]=80;

	memset(m_is_meta_char, 0, sizeof(m_is_meta_char));

	set_bit(m_is_meta_char, '(');
	set_bit(m_is_meta_char, ')');
	set_bit(m_is_meta_char, '[');
	set_bit(m_is_meta_char, ']');
	set_bit(m_is_meta_char, '{');
	set_bit(m_is_meta_char, '}');
	set_bit(m_is_meta_char, '*');
	set_bit(m_is_meta_char, '+');
	set_bit(m_is_meta_char, '?');
	set_bit(m_is_meta_char, '.');
	set_bit(m_is_meta_char, '|');
	set_bit(m_is_meta_char, '^');
	set_bit(m_is_meta_char, '$');
	set_bit(m_is_meta_char, '-');
	set_bit(m_is_meta_char, '\\');
	set_bit(m_is_meta_char, '/');
	set_bit(m_is_meta_char, ',');
	set_bit(m_is_meta_char, '=');
	set_bit(m_is_meta_char, ':');
	set_bit(m_is_meta_char, '!');
	set_bit(m_is_meta_char, '@');
	set_bit(m_is_meta_char, '%');
	set_bit(m_is_meta_char, '&');
	set_bit(m_is_meta_char, '>');
}

parse_tree::~parse_tree()
{
	parse_tree_node_t * p=m_head;
	while(p)
	{
		parse_tree_node_t * q=p->link;
		delete p;
		m_node_count--;
		p=q;
	}
	m_root=NULL;
	m_head=NULL;

	if(m_node_count!=0)
	{
		printf_regex_log("[%s : %d] : m_node_count=%d, fatal error!\n", __FILE__, __LINE__, m_node_count);
	}

	delete [] m_priority;
}

int process_zero_width_assertion(const char * re, int n, int i)
{
	int j=i+3;
	int par_cnt=1;

	while(j<n && par_cnt!=0)
	{
		if(re[j]=='\\')
		{
			if(j+1>=n) return -1;
			if(re[j+1]=='x' || re[j+1]=='X')
			{
				if(j+3>=n) return -1;
				j+=4;
			}
			else
			{				
				j+=2;
			}
		}
		else
		{
			if(re[j]=='(') ++par_cnt;
			if(re[j]==')') --par_cnt;
			j++;
		}
	}
	if(par_cnt!=0) return -1;

	return j;
}

int parse_tree::parse(const char * p, int n, bool case_sensitive, const char * parse_tree_file)
{
	if(p==NULL || n<1) return -1;

#ifdef DEBUG_PARSE_TREE
	printf_regex_log("parsing regular expression: \"%s\"\n", p);
#endif

	m_node_count=0;
	m_root=NULL;

	parse_tree_node_t * node=NULL;
	int ret;

	/*�ж�������'('��������')'�Ƿ�ƥ�䣺
	���κ�ʱ�̣������ŵĸ�������>=�����ŵĸ�����
	����������ʱ�������ŵĸ���������������ŵĸ�����
	����Ϊ�Ƿ����������ʽ��*/
	int diff_parenthesis=0;

	/*��Ԫ�������ĸ����Ͷ�Ԫ�������ĸ�����
	�������Ͳ�������������Լ����0 <= binary_operands_num-binary_operators_num <=1��
	����Ϊ�Ƿ����������ʽ��*/
	int diff_operands_operators=0; // =binary_operands_num-binary_operators_num

	int i=0;
	while(i<n)
	{
		switch(p[i])
		{
		case '(' :
			if(i+2<n && p[i+1]=='?' && (p[i+2]=='='||p[i+2]=='!'))
			{
				ret=process_zero_width_assertion(p, n, i);
				if(ret<0) return -1;
				i=ret;
				break;
			}

			if(i+2<n && p[i+1]=='?' && p[i+2]==':')
			{
				i+=2;
			}
			if(diff_operands_operators==1)
			{
				node=new_node();
				node->type=RE_CONCAT;
				node->pos=i;
				this->push_operator(node);
				diff_operands_operators=0;
			}
			++diff_parenthesis;
			node=new_node();
			node->type=RE_PARENTHESIS;
			node->pos=i;
			m_operators.push(node);
			i++;
			break;

		case ')' :
			if(diff_operands_operators==0)
			{
				node=new_node();
				node->type=RE_EPSILON;
				node->pos=i;
				m_operands.push(node);
				diff_operands_operators=1;
			}
			--diff_parenthesis;
			if(diff_parenthesis<0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: invalid expression: parenthesis ( and ) do not match!\n", __FILE__, __LINE__);
#endif
				return -1;
			}
			while(m_operators.top()->type!=RE_PARENTHESIS)
			{
				do_operation();
			}
			m_operators.pop();
			i++;
			break;

		case '|' :
			if(diff_operands_operators==0)
			{
				node=new_node();
				node->type=RE_EPSILON;
				node->pos=i;
				m_operands.push(node);
				diff_operands_operators=1;
			}
			--diff_operands_operators;
			node=new_node();
			node->type=RE_UNION;
			node->pos=i;
			this->push_operator(node);
			i++;
			break;

		case '*' :
			if(diff_operands_operators==0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: invalid expression: %s.\n", __FILE__, __LINE__, p+i);
#endif
				return -1;
			}
			node=new_node();
			node->type=RE_ASTERISK;
			node->tag[0]=0;
			node->tag[1]=UINT_MAX;
			node->pos=i;
			m_operators.push(node);
			this->do_operation();
			i++;
			if(i<n && (p[i]=='?'||p[i]=='+')) i++;
			break;

		case '+' :
			if(diff_operands_operators==0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: invalid expression: %s.\n", __FILE__, __LINE__, p+i);
#endif
				return -1;
			}
			node=new_node();
			node->type=RE_PLUS;
			node->tag[0]=1;
			node->tag[1]=UINT_MAX;
			node->pos=i;
			m_operators.push(node);
			this->do_operation();
			i++;
			if(i<n && (p[i]=='?'||p[i]=='+')) i++;
			break;

		case '?' :
			if(diff_operands_operators==0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: invalid expression: %s.\n", __FILE__, __LINE__, p+i);
#endif
				return -1;
			}
			node=new_node();
			node->type=RE_QUESTION_MARK;
			node->tag[0]=0;
			node->tag[1]=1;
			node->pos=i;
			m_operators.push(node);
			this->do_operation();
			i++;
			if(i<n && (p[i]=='?'||p[i]=='+')) i++;
			break;

		case '{' :
			if(diff_operands_operators==0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: invalid expression: %s.\n", __FILE__, __LINE__, p+i);
#endif
				return -1;
			}
			node=new_node();
			node->type=RE_BRACE;
			node->pos=i;
			ret=parse_repeat(p+i, n-i, node);
			if(ret<0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: invalid repeat: %s.\n", __FILE__, __LINE__, p+i);
#endif
				return -1;
			}
			i+=ret;
			if(i<n && (p[i]=='?'||p[i]=='+')) i++;
			m_operators.push(node);
			this->do_operation();
			break;

		case '}' :
#ifdef DEBUG_PARSE_TREE
			printf_regex_log("[%s: %d]: invalid expression: %s.\n", __FILE__, __LINE__, p+i);
#endif
			return -1;
			break;

		case '.' :
			if(diff_operands_operators==1)
			{
				node=new_node();
				node->type=RE_CONCAT;
				node->pos=i;
				this->push_operator(node);
				diff_operands_operators=0;
			}
			node=new_node();
			node->type=RE_DOT;
			node->pos=i;
			FOR(k, 8) node->tag[k]=~0;
			i++;
			m_operands.push(node);
			++diff_operands_operators;
			break;

		case '[' :
			if(diff_operands_operators==1)
			{
				node=new_node();
				node->type=RE_CONCAT;
				node->pos=i;
				this->push_operator(node);
				diff_operands_operators=0;
			}
			node=new_node();
			node->type=RE_BRACKET;
			node->pos=i;
			ret=parse_character_class(p+i, n-i, node);
			if(ret<0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: invalid character class: %s.\n", __FILE__, __LINE__, p+i);
#endif
				return -1;
			}

			if(!case_sensitive)
			{
				if(p[i+1]=='^')
				{
					for(int C='A'; C<='Z'; C++)
					{
						int c=C-'A'+'a';
						if( (node->tag[C>>5]&(1U<<(C&31)))==0 || (node->tag[c>>5]&(1U<<(c&31)))==0 )
						{
							node->tag[C>>5]&=~(1U<<(C&31));
							node->tag[c>>5]&=~(1U<<(c&31));
						}
					}
				}
				else
				{
					for(int C='A'; C<='Z'; C++)
					{
						if(node->tag[C>>5]&(1U<<(C&31)))
						{
							node->tag[C>>5]^=(1U<<(C&31));
							int c=C-'A'+'a';
							node->tag[c>>5]|=(1U<<(c&31));
						}
					}
				}
			}

			i+=ret;

			m_operands.push(node);
			++diff_operands_operators;
			break;

		case ']' :
#ifdef DEBUG_PARSE_TREE
			printf_regex_log("[%s: %d]: invalid expression: %s.\n", __FILE__, __LINE__, p+i);
#endif
			return -1;
			break;

		case '$':
			i++;
			break;

		default :
			if(i+1<n && p[i]=='\\' && (p[i+1]=='b'||p[i+1]=='B')) /*����word boundary�ַ�\b��\B*/
			{
				i+=2;
				break;
			}

			if(p[i]=='^') /*����^�ַ�*/
			{
				i++;
				break;
			}

			if(diff_operands_operators==1)
			{
				node=new_node();
				node->type=RE_CONCAT;
				node->pos=i;
				this->push_operator(node);
				diff_operands_operators=0;
			}
			node=new_node();
			node->pos=i;
			ret=parse_char_or_escape(p+i, n-i, node);
			if(ret<0)
			{
#ifdef DEBUG_PARSE_TREE
				printf_regex_log("[%s: %d]: parse_char_or_escape error: %s.\n", __FILE__, __LINE__, p+i);
#endif
				return -1;
			}
			i+=ret;

			if(!case_sensitive)
			{
				node->tag[0]=tolower(node->tag[0]);
			}

			m_operands.push(node);
			++diff_operands_operators;
			break;
		}
	}

	if(diff_parenthesis!=0)
	{
#ifdef DEBUG_PARSE_TREE
		printf_regex_log("[%s: %d]: invalid expression: parenthesis ( and ) do not match!\n", __FILE__, __LINE__);
#endif
		return -1;
	}

	if(diff_operands_operators!=1)
	{
#ifdef DEBUG_PARSE_TREE
		printf_regex_log("[%s: %d]: invalid expression: too many operators!\n", __FILE__, __LINE__);
#endif
		return -1;
	}

	while(!m_operators.empty())
	{
		do_operation();
	}

	if(!m_operands.empty())
	{
		m_root=m_operands.top();
	}

#ifdef DEBUG_PARSE_TREE

	vector<cstring> vs;
	this->print(vs, m_root, 0);

	printf_regex_log("# of parse tree nodes=%d.\n", (int)vs.size());
	FOR(i, vs.size()) printf_regex_log("%s\n", vs[i].c_str());

	if(parse_tree_file!=NULL)
	{
		FILE * stream=fopen(parse_tree_file, "w");
		if(stream!=NULL)
		{
			FOR(i, vs.size()) fprintf(stream, "%s\n", vs[i].c_str());
			fflush(stream);
			fclose(stream);
		}
	}

	printf_regex_log("parsing regular expression finished!\n");

#endif

	return 1;
}

void parse_tree::push_operator(parse_tree_node_t * node)
{
	while(!m_operators.empty() && m_operators.top()->type!=RE_PARENTHESIS 
		&& m_priority[node->type]<=m_priority[m_operators.top()->type]) 
	{
		do_operation();
	}
	m_operators.push(node);
}

void parse_tree::do_operation()
{
	assert(!m_operators.empty());
	parse_tree_node_t * z=m_operators.top();
	m_operators.pop();

	switch(z->type)
	{
	case RE_CONCAT:
	case RE_UNION:
		assert(!m_operands.empty());
		z->rchild=m_operands.top();
		m_operands.pop();
		assert(!m_operands.empty());
		z->lchild=m_operands.top();
		m_operands.pop();
		break;

	case RE_ASTERISK:
	case RE_BRACE:
	case RE_PLUS:
	case RE_QUESTION_MARK:
		assert(!m_operands.empty());
		z->lchild=m_operands.top();
		m_operands.pop();
		break;

	default:
		printf("[%s: %d]: error: invalid operator: %d", __FILE__, __LINE__, z->type);
		printf_regex_log("[%s: %d]: error: invalid operator: %d", __FILE__, __LINE__, z->type);
		break;
	}

	m_operands.push(z);
}

parse_tree_node_t * parse_tree::new_node()
{
	parse_tree_node_t * node=new parse_tree_node_t;
	FOR(k, 8) node->tag[k]=0;
	node->lchild=node->rchild=NULL;
	node->link=m_head;
	m_head=node;
	m_node_count++;
	return node;
}

parse_tree_node_t * parse_tree::get_root()
{
	return m_root;
}

int parse_tree::max_min_length(parse_tree_node_t * root, unsigned int& _max, unsigned int& _min)
{
	unsigned int Lmax, Rmax, Lmin, Rmin;

	switch(root->type)
	{
	case RE_CONCAT:
		max_min_length(root->lchild, Lmax, Lmin);
		max_min_length(root->rchild, Rmax, Rmin);
		if(Lmax==UINT_MAX || Rmax==UINT_MAX)
		{
			_max=UINT_MAX;
		}
		else
		{
			_max=Lmax+Rmax;
		}

		_min=Lmin+Rmin;
		break;

	case RE_UNION:
		max_min_length(root->lchild, Lmax, Lmin);
		max_min_length(root->rchild, Rmax, Rmin);
		if(Lmax==UINT_MAX || Rmax==UINT_MAX)
		{
			_max=UINT_MAX;
		}
		else
		{
			_max=(Lmax>Rmax) ? Lmax : Rmax;
		}

		_min=(Lmin<Rmin) ? Lmin : Rmin;
		break;

	case RE_BRACE:
		max_min_length(root->lchild, Lmax, Lmin);
		if(Lmax==UINT_MAX || root->tag[1]==UINT_MAX)
		{
			_max=UINT_MAX;
		}
		else
		{
			_max=Lmax*root->tag[1];
		}

		_min=Lmin*root->tag[0];
		break;

	case RE_QUESTION_MARK:
		max_min_length(root->lchild, Lmax, Lmin);
		_max=Lmax;
		_min=0;
		break;

	case RE_ASTERISK:
		_max=UINT_MAX;
		_min=0;
		break;

	case RE_PLUS:
		_max=UINT_MAX;
		max_min_length(root->lchild, Lmax, Lmin);
		_min=Lmin;
		break;

	case RE_DOT:
	case RE_BRACKET:
	case RE_NORMAL_CHAR:
		_max=1;
		_min=1;
		break;

	case RE_EPSILON:
		_max=0;
		_min=0;
		break;
	}

	return 1;
}

const char * hexmap="0123456789abcdef";

cstring parse_tree::parse_tree_to_expr(parse_tree_node_t * root)
{
	cstring s;
	char line[256]={0};
	int F, L;

	if(root==NULL) return s;

	switch(root->type)
	{
	case RE_CONCAT:
		s+="(";
		s+=parse_tree_to_expr(root->lchild);
		s+=parse_tree_to_expr(root->rchild);
		s+=")";
		break;

	case RE_UNION:
		s+="(";
		s+=parse_tree_to_expr(root->lchild);
		s+="|";
		s+=parse_tree_to_expr(root->rchild);
		s+=")";
		break;

	case RE_ASTERISK:
		s+="(";
		s+=parse_tree_to_expr(root->lchild);
		s+="*";
		s+=")";
		break;

	case RE_BRACE:
		s+="(";
		s+=parse_tree_to_expr(root->lchild);
		if(root->tag[1]==UINT_MAX)
		{
			sprintf(line, "{%u,}", root->tag[0]);
		}
		else if(root->tag[0]==root->tag[1])
		{
			sprintf(line, "{%u}", root->tag[0]);
		}
		else
		{
			sprintf(line, "{%u,%u}", root->tag[0], root->tag[1]);
		}
		s+=line;
		s+=")";
		break;

	case RE_PLUS:
		s+="(";
		s+=parse_tree_to_expr(root->lchild);
		s+="+";
		s+=")";
		break;

	case RE_QUESTION_MARK:
		s+="(";
		s+=parse_tree_to_expr(root->lchild);
		s+="?";
		s+=")";
		break;

	case RE_DOT:
		s=".";
		break;

	case RE_BRACKET:
		s+="[";
		F=0;
		while(F<256)
		{
			while(F<256 && ((root->tag[F>>5])&(1U<<(F&31)))==0) F++;
			if(F==256) break;
			L=F+1;
			while(L<256 && ((root->tag[L>>5])&(1U<<(L&31)))!=0) L++;
			if(L-F==1)
			{
				sprintf(line, "\\x%c%c", hexmap[F/16], hexmap[F%16]);
			}
			else
			{
				sprintf(line, "\\x%c%c-\\x%c%c", hexmap[F/16], hexmap[F%16], hexmap[(L-1)/16], hexmap[(L-1)%16]);
			}
			s+=line;
			if(L==256) break;
			F=L+1;
		}
		s+="]";
		break;

	case RE_EPSILON:
		s="";
		break;

	case RE_NORMAL_CHAR:
		if(test_bit(m_is_meta_char, root->tag[0]))
		{
			sprintf(line, "\\x%c%c", hexmap[root->tag[0]/16], hexmap[root->tag[0]%16]);
			s=cstring(line);
		}
		else if(isprint(root->tag[0]))
		{
			s=(char)root->tag[0];
		}
		else
		{
			sprintf(line, "\\x%c%c", hexmap[root->tag[0]/16], hexmap[root->tag[0]%16]);
			s=cstring(line);
		}
		break;
	}

	return s;
}

void parse_tree::print(vector<cstring>& vs, parse_tree_node_t * root, int depth)
{
	if(root!=NULL)
	{
		cstring s;
		char * line=new char[128];
		int F, L;

		int indent=3*(depth-1);
		FOR(i, indent) s+=" ";
		if(depth>0) s+="|__";

		for(int k=(int)vs.size()-1; k>=0; --k)
		{
			if(indent<0 && indent>=(int)vs[k].size()) continue;
			if(vs[k][indent]!=' ') break;
			vs[k][indent]='|';
		}

		switch(root->type)
		{
		case RE_CONCAT:
			s+="(.)";
			vs.push_back(s);
			print(vs, root->lchild, depth+1);
			print(vs, root->rchild, depth+1);
			break;

		case RE_UNION:
			s+="(|)";
			vs.push_back(s);
			print(vs, root->lchild, depth+1);
			print(vs, root->rchild, depth+1);
			break;

		case RE_ASTERISK:
			s+="(*)";
			vs.push_back(s);
			print(vs, root->lchild, depth+1);
			break;

		case RE_BRACE:
			sprintf(line, "{%u,%u}", root->tag[0], root->tag[1]);
			s+=line;
			vs.push_back(s);
			print(vs, root->lchild, depth+1);
			break;

		case RE_PLUS:
			s+="(+)";
			vs.push_back(s);
			print(vs, root->lchild, depth+1);
			break;

		case RE_QUESTION_MARK:
			s+="(?)";
			vs.push_back(s);
			print(vs, root->lchild, depth+1);
			break;

		case RE_DOT:
			s+="any char";
			vs.push_back(s);
			break;

		case RE_BRACKET:
			s+="[ ";
			F=0;
			while(1)
			{
				while(F<256 && ((root->tag[F>>5])&(1U<<(F&31)))==0) F++;
				if(F==256) break;
				L=F+1;
				while(L<256 && ((root->tag[L>>5])&(1U<<(L&31)))!=0) L++;
				if(L-F==1)
				{
					sprintf(line, "%d ", F);
				}
				else
				{
					sprintf(line, "%d-%d ", F, L-1);
				}
				s+=line;
				if(L==256) break;
				F=L+1;
			}
			s+="]";
			vs.push_back(s);
			break;

		case RE_EPSILON:
			s+="EPS";
			vs.push_back(s);
			break;

		case RE_NORMAL_CHAR:
			if(isprint(root->tag[0]))
			{
				sprintf(line, "'%c'", (char)root->tag[0]);
			}
			else
			{
				sprintf(line, "'\\x%c%c'", hexmap[root->tag[0]/16], hexmap[root->tag[0]%16]);
			}
			s+=line;
			vs.push_back(s);
			break;
		}

		delete [] line;
	}
}

int hex2dec(int c)
{
	if(c>='0' && c<='9')
	{
		return c-'0';
	}
	else if(c>='a' && c<='z')
	{
		return c-'a'+10;
	}
	else if(c>='A' && c<='Z')
	{
		return c-'A'+10;
	}

	return -1;
}

int parse_tree::parse_char_or_escape(const char * p, int n, parse_tree_node_t * node)
{
	FOR(k, 8) node->tag[k]=0;

	if(n<1) return -1;

	if(p[0]=='\\')
	{
		int H, L, c;
		if(n<2) return -1;

		switch(p[1])
		{
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			return -1; //�ݲ�֧�ַ��������﷨
			break;
		case 'x':
		case 'X':
			if(n<4) return -1;
			H=hex2dec(p[2]);
			L=hex2dec(p[3]);
			if(H<0 || L<0) return -1;
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(H<<4)+L;
			return 4;
			break;

		case 'd':
			node->type=RE_BRACKET;
			for(c='0'; c<='9'; c++)
			{
				node->tag[c>>5]|=(1<<(c&31));
			}
			return 2;
			break;

		case 'D':
			node->type=RE_BRACKET;
			for(c=0; c<256; c++)
			{
				if(c<'0' || c>'9')
				{
					node->tag[c>>5]|=(1<<(c&31));
				}
			}
			return 2;
			break;

		case 'l':
			node->type=RE_BRACKET;
			for(c='a'; c<='z'; c++)
			{
				node->tag[c>>5]|=(1<<(c&31));
			}
			return 2;
			break;

		case 'L':
			node->type=RE_BRACKET;
			for(c=0; c<256; c++)
			{
				if(c<'a' || c>'z')
				{
					node->tag[c>>5]|=(1<<(c&31));
				}
			}
			return 2;
			break;

		case 'u':
			node->type=RE_BRACKET;
			for(c='A'; c<='Z'; c++)
			{
				node->tag[c>>5]|=(1<<(c&31));
			}
			return 2;
			break;

		case 'U':
			node->type=RE_BRACKET;
			for(c=0; c<256; c++)
			{
				if(c<'A' || c>'Z')
				{
					node->tag[c>>5]|=(1<<(c&31));
				}
			}
			return 2;
			break;

		case 's':
			node->type=RE_BRACKET;
			for(c=0; c<256; c++)
			{
				if(isspace(c))
				{
					node->tag[c>>5]|=(1<<(c&31));
				}
			}
			return 2;
			break;

		case 'S':
			node->type=RE_BRACKET;
			for(c=0; c<256; c++)
			{
				if(!isspace(c))
				{
					node->tag[c>>5]|=(1<<(c&31));
				}
			}
			return 2;
			break;

		case 'w':
			node->type=RE_BRACKET;
			for(c=0; c<256; c++)
			{
				if(isalpha(c) || isdigit(c) || c=='_')
				{
					node->tag[c>>5]|=(1<<(c&31));
				}
			}
			return 2;
			break;

		case 'W':
			node->type=RE_BRACKET;
			for(c=0; c<256; c++)
			{
				if(!isalpha(c) && !isdigit(c) && c!='_')
				{
					node->tag[c>>5]|=(1<<(c&31));
				}
			}
			return 2;
			break;

		case 'a':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(unsigned char)'\a';
			return 2;
			break;

		case 'b':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(unsigned char)'\b';
			return 2;
			break;

		case 'e':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=0x1B;
			return 2;
			break;

		case 'f':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(unsigned char)'\f';
			return 2;
			break;

		case 'r':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(unsigned char)'\r';
			return 2;
			break;

		case 'n':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(unsigned char)'\n';
			return 2;
			break;

		case 't':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(unsigned char)'\t';
			return 2;
			break;

		case 'v':
			node->type=RE_NORMAL_CHAR;
			node->tag[0]=(unsigned char)'\v';
			return 2;
			break;

		default:
			if(test_bit(m_is_meta_char, p[1])) /*��Ԫ�ַ���ת��*/
			{
				node->type=RE_NORMAL_CHAR;
				node->tag[0]=(unsigned char)p[1];
				return 2;
			}
			else  /*�������ַ���ת����Ϊ�Ƿ�*/
			{
				return -1;
			}
			break;
		}
	}
	else
	{
		node->type=RE_NORMAL_CHAR;
		node->tag[0]=(unsigned char)p[0];
		return 1;
	}
}

int parse_tree::parse_character_class(const char * p, int n, parse_tree_node_t * node)
{
	FOR(k, 8) node->tag[k]=0;

	if(n<2) return -1;
	if(p[0]!='[') return -1;

	int ret=-1;
	int i=1;

	if(i<n && p[i]=='^')
	{
		FOR(k, 8) node->tag[k]=~node->tag[k];
		i++;
	}

	while(i<n && p[i]!=']')
	{
		//if(p[i]=='[') return -1;

		parse_tree_node_t tmp;
		ret=parse_char_or_escape(p+i, n-i, &tmp);
		if(ret<0) return -1;
		i+=ret;

		if(tmp.type==RE_BRACKET)
		{
			for(int c=0; c<256; c++)
			{
				if(tmp.tag[c>>5]&(1U<<(c&31)))
				{
					node->tag[c>>5]^=(1<<(c&31));
				}
			}
		}
		else
		{
			int c1=tmp.tag[0];

			if(i<n && p[i]=='-')
			{
				i++;	
				ret=parse_char_or_escape(p+i, n-i, &tmp);
				if(ret<0 || tmp.type==RE_BRACKET) return -1;
				i+=ret;
				int c2=tmp.tag[0];

				for(int c=c1; c<=c2; c++)
				{
					node->tag[c>>5]^=(1<<(c&31));
				}
			}
			else
			{
				node->tag[c1>>5]^=(1<<(c1&31));
			}
		}
	}

	if(i>=n)
	{
		return -1;
	}
	else
	{
		return i+1;
	}
}


/*
{n}
{m, n}
{m,}
*/
int parse_tree::parse_repeat(const char * p, int n, parse_tree_node_t * node)
{
	if(n<3) return -1;
	if(p[0]!='{') return -1;

	int L=0;
	while(L<n && p[L]!='}') ++L;
	if(L==n) return -1;

	int M=0;
	while(M<L && p[M]!=',') ++M;

	cstring sx, sy;

	int i=1;
	while(i<M && isspace(p[i])) ++i;

	while(i<M && !isspace(p[i]))
	{
		if(!isdigit(p[i])) return -1;
		sx+=p[i];
		i++;
	}

	if(sx.size()==0) return -1;
	node->tag[0]=(unsigned int)strtoul(sx.c_str(), NULL, 10);

	if(M==L)
	{
		node->tag[1]=node->tag[0];
	}
	else
	{
		i=M+1;
		while(i<L && isspace(p[i]))++i;

		while(i<L && !isspace(p[i]))
		{
			if(!isdigit(p[i])) return -1;
			sy+=p[i];
			i++;
		}

		if(sy.size()==0)
		{
			node->tag[1]=UINT_MAX;
		}
		else
		{
			node->tag[1]=(unsigned int)strtoul(sy.c_str(), NULL, 10);
		}

		if(node->tag[1]<node->tag[0]) return -1;
	}

	return L+1;
}
