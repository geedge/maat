#include "..\\ParseTree.h"

int id=0;

int test(const char * rule_file)
{
	FILE * stream=fopen(rule_file, "r");
	if(stream==NULL) return 0;

	char result_file[256];

	while(!feof(stream))
	{
		char line[1024]={0};

		fgets(line, sizeof(line), stream);
		for(char * ps=line; *ps; ++ps) if(*ps=='\n') *ps=0;

		if(strlen(line)==0) continue;

		sprintf(result_file, "result\\parse_tree_%d.txt", id++); 
		
		parse_tree pt;
		int ret;

		if(line[0]=='^')
		{
			ret=pt.parse(line+1, (int)strlen(line+1), result_file);
		}
		else
		{
			ret=pt.parse(line, (int)strlen(line), result_file);
		}

		if(ret<0) system("pause");

		printf("\n");
	}

	fclose(stream);
	return 1;
}

int main()
{
	parse_tree pt;
	const char * s="((ab|c*[a-z-0-9]*d{1,7}))";
	pt.parse(s, (int)strlen(s));

	test("rules\\l7_all_rules (104).txt");
	test("rules\\relib.txt");
	test("rules\\boost_re.txt");
	test("rules\\snort24.txt");
	test("rules\\snort31.txt");
	test("rules\\snort34.txt");
	test("rules\\bro217.txt");
	test("rules\\http_rules.txt");
	test("rules\\payload_rules.txt");

	return 1;
}
