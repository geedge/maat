#ifndef	H_THOMPSON_CPP_H
#define H_THOMPSON_CPP_H

//#define DEBUG_THOMPSON_NFA

#include "regex_def.h"
#include "parse_tree/ParseTree.h"
#include "DFA.h"

typedef struct _nfa_state_t{
	int state_id;
	int pat_id;
	set<int> eps_closure;
}nfa_state_t;

typedef struct _nfa_trans_t{
	int	fr;
	int	to;
	int	ch;
}nfa_trans_t;

bool operator<(const nfa_state_t& lhs, const nfa_state_t& rhs);

bool operator<(const nfa_trans_t& lhs, const nfa_trans_t& rhs);

class CThompsonNFA
{
public:
	CThompsonNFA();
	~CThompsonNFA();

	int BuildNFA(regex_pattern_t * pat, bool case_sensitive, bool anchored);

	/*��ȡNFA�ĳ�ʼ״̬*/
	vector<int> get_start_states();

	/*��ȡNFA����һ��״̬*/
	vector<int> get_next_states(const vector<int>& states, int c);

	/*��ȡNFA��ǰ״̬ƥ���ģʽ��*/
	vector<int> get_matched_patterns(const vector<int>& states);

	void ClearNFA();

	void ShowNFA(FILE * stream);

private:
	int BuildEpsClosure();
	int BuildEpsClosure_Warshall();
	int BuildEpsClosure_Graphsearch();

	void CopyNFA(const CThompsonNFA& rhs);

	int BuildAutomata(parse_tree_node_t * root, int start_id, int pat_id, bool reverse);

	int optmize_storage();

private:
	vector<nfa_state_t>	m_state;
	vector<nfa_trans_t>	m_trans;
	vector<nfa_trans_t>	m_eps_trans;

	int m_state_num;
	int m_trans_num;
	int m_eps_trans_num;
	int * m_pat_id;
	int * m_eps_closure_ptr;
	int * m_eps_closure_buff;
	int * m_next_state_ptr;
	int * m_next_state_buff;
};

#endif
