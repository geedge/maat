#include "regex_def.h"

int printf_regex_log(const char * format, ...)
{

#ifdef OPEN_REGEX_LOG

#define LOG_FILE_MAX_SIZE  10000000

	//�жϣ������־�ļ��Ĵ�С����10M�������¿�ʼд
	FILE * flog;
	flog=fopen(LOG_FILE_PATH,"rb");	
	int now_size=0;
	if(flog!=NULL)
	{
		fseek(flog,0,SEEK_END);
		now_size=ftell(flog);
		fclose(flog);
	}
	FILE * fp;
	if(now_size > LOG_FILE_MAX_SIZE)
	{
		//��Ҫ���¿�ʼ
		fp = fopen(LOG_FILE_PATH, "w+");
	}
	else
	{
		//����Ҫ���¿�ʼ
		fp = fopen(LOG_FILE_PATH, "a");
	}
	if(fp==NULL) 
	{
		return  -1;
	}

#define MAX_LOG_LINES 65536
	va_list ap;
	char * buf=new char[MAX_LOG_LINES];
	va_start(ap, format);
	vsprintf(buf, format, ap);
	va_end(ap);

	time_t cur;
	char buf2[128];
	memset(buf2, 0, 128);
	time(&cur);
	sprintf(buf2, "%s", ctime(&cur));
	buf2[strlen(buf2) - 1] = '\0';
	fprintf(fp, "[%s]: %s", buf2, buf);
	fclose(fp);

	delete [] buf;

#endif

	return 1;
}

int clear_regex_log()
{
	FILE * fp = fopen(LOG_FILE_PATH, "wb");
	if(fp!=NULL) fclose(fp);
	return 1;
}
