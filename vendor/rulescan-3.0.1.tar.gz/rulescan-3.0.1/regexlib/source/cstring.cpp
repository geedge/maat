#include "cstring.h"
#include <string.h>
#include <stdlib.h>

char * copy_str(const char * str)
{
	char * s=new char[strlen(str)+1];
	strcpy(s, str);
	return s;
}

cstring::cstring()
{
	m_str=copy_str("");
}

cstring::cstring(const char * str)
{
   	m_str=copy_str( (str!=NULL) ? str : "" );
}

cstring::cstring(const char * s, const char * e)
{
	if(e<s) e=s;
	m_str=new char[e-s+1];
	memcpy(m_str, s, e-s);
	m_str[e-s]='\0';
}

cstring::cstring(char c)
{
   	m_str=new char[2];
	m_str[0]=c;
	m_str[1]='\0';
}

cstring::cstring(const cstring& rhs)
{
	if(&rhs!=this)
	{
		m_str=copy_str(rhs.m_str);
	}
}

cstring::~cstring()
{
	delete [] m_str;
}

cstring& cstring::operator=(const cstring& rhs)
{
	if(&rhs!=this)
	{
		delete [] m_str;
		m_str=copy_str(rhs.m_str);
	}
	return *this;
}

cstring& cstring::operator+=(const cstring& rhs)
{
	if(&rhs!=this)
	{
		unsigned int len1=strlen(m_str);
		unsigned int len2=strlen(rhs.m_str);
		char * s=new char[len1+len2+1];
		memcpy(s, m_str, len1);
		memcpy(s+len1, rhs.m_str, len2);
		s[len1+len2]='\0';
		delete [] m_str;
		m_str=s;
	}
	return *this;
}

char& cstring::operator[](int i)
{
	return m_str[i];
}

const char * cstring::c_str()
{
	return m_str;
}

unsigned int cstring::length()
{
	return strlen(m_str);
}

unsigned int cstring::size()
{
	return strlen(m_str);
}

cstring operator+(const cstring& lhs, const cstring& rhs)
{
	cstring s=lhs;
	s+=rhs;
	return s;
}
