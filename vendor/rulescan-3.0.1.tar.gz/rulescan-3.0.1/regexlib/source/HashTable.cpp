#include "HashTable.h"

unsigned int __primes[]={2, 2, 5, 11, 17, 37, 67, 131, 257, 521, 
												1031, 2053, 4201, 8209, 16411, 32771, 65537, 131101, 262147, 524289, 
												1048583, 2097169, 4194319, 8388617, 16777259, 33554467, 67108879,
												134217757, 268435459, 536870923, 1073741827};

hash_table::hash_table(unsigned int N)
{
	if(N>30) N=30;
	m_hash_table_size=__primes[N];
	m_hash_table=new hash_node_t*[m_hash_table_size];
	FOR(i, m_hash_table_size) m_hash_table[i]=NULL;
	m_F=m_L=NULL;
}

hash_table::~hash_table()
{
	FOR(i, m_hash_table_size)
	{
		hash_node_t * nodeptr=m_hash_table[i];
		while(nodeptr!=NULL)
		{
			hash_node_t * next=nodeptr->next;
			delete nodeptr;
			nodeptr=next;
		}
	}
	delete [] m_hash_table;
}

unsigned int hash_table::hashing(const vector<int>& state)
{
	unsigned int h=0;

	//#pragma omp parallel for reduction(+:h)
	for(int i=0; i<(int)state.size(); i++)
	{
		h+=(unsigned int)state[i]*state[i];
	}

	if(h>=m_hash_table_size)
	{
		h=h%m_hash_table_size;
	}

	return h;
}

int hash_table::get(unsigned int key, const vector<int>& state)
{
	assert(key<m_hash_table_size);

	for(hash_node_t * nodeptr=m_hash_table[key]; nodeptr!=NULL; nodeptr=nodeptr->next)
	{
		if(nodeptr->state==state)
		{
			return nodeptr->value;
		}
	}
	return -1;
}

int hash_table::put(unsigned int key, const vector<int>& state, int value)
{
	assert(key<m_hash_table_size);

	hash_node_t * nodeptr=new hash_node_t;

	nodeptr->link=NULL;
	if(m_L!=NULL)
	{
		m_L->link=nodeptr;
		m_L=nodeptr;
		if(m_F==NULL) m_F=m_L;
	}
	else
	{
		m_F=m_L=nodeptr;
	}

	nodeptr->state=state;
	nodeptr->value=value;
	nodeptr->next=m_hash_table[key];
	m_hash_table[key]=nodeptr;
	return 1;
}

const hash_node_t * hash_table::get_next()
{
	if(m_F==NULL) return NULL;
	hash_node_t * p=m_F;
	m_F=m_F->link;
	return p;	
}


