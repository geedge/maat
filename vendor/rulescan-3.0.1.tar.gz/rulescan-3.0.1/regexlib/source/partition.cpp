#include "partition.h"
#include "regex_def.h"
#include "regex_matching.h"
#include "DFA.h"

int compute_interaction(vector<regex_pattern_t>& unsplit_pats, vector<int>& a, vector< vector<int> >& b, bool case_sensitive)
{	
	int N=(int)unsplit_pats.size();

	a.resize(N, 0);
	b.resize(N, vector<int>(N, 0));
	vector<CDFA *> DFAs(N, (CDFA *)NULL);

#ifdef USE_OMP
#pragma omp parallel for
#endif
	for(int i=0; i<N; i++)
	{
		DFAs[i]=new CDFA;
		if(DFAs[i]->BuildDFAFromNFA(&(unsplit_pats[i]), case_sensitive, false)<0)
		{
			printf_regex_log("[%s: %d]: build DFA for rule_id=%u failed!\n", __FILE__, __LINE__, unsplit_pats[i].pattern_id);
			delete DFAs[i];
			DFAs[i]=NULL;
		}
		else
		{
			a[i]=DFAs[i]->m_state_num;
		}
	}

	for(int i=0; i<N; i++)
	{
#ifdef USE_OMP
#pragma omp parallel for
#endif
		for(int j=i+1; j<N; j++)
		{
			if(DFAs[i]!=NULL && DFAs[j]!=NULL)
			{
				CDFA *dfa=new CDFA;
				vector<CDFA *>  sub_groups;
				sub_groups.push_back(DFAs[i]);
				sub_groups.push_back(DFAs[j]);
				if(CDFA::merge_DFA(-1, sub_groups, dfa, (1<<17))<0)
				{
					printf_regex_log("[%s: %d]: merge_DFA() failed: i=%d, j=%d.\n", __FILE__, __LINE__, i, j);
					b[j][i]=b[i][j]=(1<<17);
				}
				else
				{
					b[j][i]=b[i][j]=dfa->m_state_num-a[i]-a[j];
					if(b[i][j]<0) b[j][i]=b[i][j]=0;
				}
				delete dfa;
				dfa=NULL;
			}
		}
	}

	FOR(i, DFAs.size())
	{
		if(DFAs[i]!=NULL) 	delete DFAs[i];
	}

	return N;
}

int is_file_constructable(const char * rule_file, bool case_sensitive, int max_state_num)
{
	CDFA dfa;
	if(dfa.preprocessing(rule_file, case_sensitive, NULL, 0, max_state_num, true)<0) return -1;
#ifdef USE_DFA_PTR
	return dfa.m_state_num_address;
#else
	return dfa.m_TOPK.m_state_num;
#endif
}

int is_constructable(vector<cstring>& part_files, bool case_sensitive, int max_state_num)
{
	int left_state_num=max_state_num;
	for(int k=0; k<(int)part_files.size(); k++)
	{
		CDFA dfa;
		if(dfa.preprocessing(part_files[k].c_str(), case_sensitive, NULL, 0, left_state_num, true)<0) return -1;
#ifdef USE_DFA_PTR
		left_state_num-=dfa.m_state_num_address;
#else
		left_state_num-=dfa.m_TOPK.m_state_num;
#endif
	}
	return max_state_num-left_state_num;
}

int rule_partition(const char * rule_file, bool case_sensitive, int max_state_num, vector<cstring>& part_files)
{
	part_files.clear();

	//printf("try to build a whole DFA for %s...\n", rule_file);
	int ret=is_file_constructable(rule_file, case_sensitive, max_state_num);
	if(ret>=0)
	{
		part_files.push_back(cstring(rule_file));
		//printf("constructing a whole DFA succeeds: total_state_num=%d\n", ret);
		return 1;
	}
	else
	{
		printf("fails to to build a whole DFA for %s, start rule_partition()...\n", rule_file);
	}

	cstring split_file=cstring(rule_file)+cstring(".split");
	ret=is_file_constructable(split_file.c_str(), case_sensitive, max_state_num);
	if(ret<0)
	{
		printf("constructing a whole DFA for %s fails.\n", split_file.c_str());
		return -1;
	}
	else
	{
		max_state_num-=ret;
	}

	vector<regex_pattern_t> unsplit_res;
	string unsplit_file=string(rule_file)+string(".unsplit");
	ret=CDFA::load_patterns_from_file(unsplit_file.c_str(), unsplit_res, case_sensitive, NULL, NULL, 0);
	if(ret<0 || unsplit_res.size()==0)
	{
		part_files.clear();
		part_files.push_back(split_file);
		return 1;
	}

	int N=(int)unsplit_res.size();
	vector<int> a;
	vector< vector<int> > b;

	printf("start compute_interaction()...\n");
	compute_interaction(unsplit_res, a, b, case_sensitive);
	printf("compute_interaction() succeed!\n");

	for(int G=1; G<=8 && G<=N; G++)
	{
		vector<int> rule2group(N, 0);
		srand((unsigned int)time(NULL));
		for(int i=0;i<N;i++) rule2group[i]=rand()%G;

		for(int loop=0; loop<100; ++loop)
		{
			bool nochange = true;
			for(int i=0;i<N;i++)
			{
				vector<int> gsn(G, 0);
				for(int j=0;j<N;j++)
				{
					if(i!=j) gsn[rule2group[j]] += b[i][j];
				}

				int min_gsn = gsn[0], index_gsn = 0;
				for(int j=1;j<G;j++)
				{
					if(min_gsn>gsn[j])
					{
						min_gsn = gsn[j];
						index_gsn=j;
					}
				}

				if(gsn[rule2group[i]]>gsn[index_gsn])
				{
					rule2group[i] = index_gsn;
					nochange = false;
				}
			}
			if(nochange) break;
		}

		vector< set<int> > S(G);
		for(int i=0;i<N;i++)
		{
			S[rule2group[i]].insert(i);
		}

		part_files.clear();
		FOR(k, G)
		{
			char file_name[512]={0};
			sprintf(file_name, "%s_part_%d_%d.txt", unsplit_file.c_str(), G, k);

			FILE * stream=fopen(file_name, "w");
			if(stream==NULL) return -1;

			for(set<int>::const_iterator p=S[k].begin(); p!=S[k].end(); ++p)
			{
				fprintf(stream, "%u\t%s\n", unsplit_res[*p].pattern_id, unsplit_res[*p].pattern.c_str());
				fflush(stream);
			}

			fclose(stream);

			part_files.push_back(cstring(file_name));
		}

		ret=is_constructable(part_files, case_sensitive, max_state_num);
		if(ret>=0)
		{
			part_files.push_back(split_file);
			printf("try G=%d ok: total_state_num=%d\n", G, ret);
			printf("rule_partition() finishes!\n");
			return G;
		}
		else
		{
			printf("try G=%d failed.\n", G);
			FOR(k, G)
			{
				remove(part_files[k].c_str());

				cstring ext_file=part_files[k]+".ext";
				remove(ext_file.c_str());

				cstring dfa_file=part_files[k]+".ext.dfa";
				remove(dfa_file.c_str());

				cstring split_file=part_files[k]+".split";
				remove(split_file.c_str());

				cstring unsplit_file=part_files[k]+".unsplit";
				remove(unsplit_file.c_str());
			}
			part_files.clear();
		}
	}

	printf("rule_partition() failes!\n");
	return -1;
}

int simple_partition(const char * rule_file, bool case_sensitive, int max_state_num, vector<cstring>& part_files)
{
	printf("start simple_partition()...\n");

	vector<regex_pattern_t> pats;
	if(CDFA::load_patterns_from_file(rule_file, pats, case_sensitive, NULL, NULL, 0)<0 || pats.size()==0)
	{
		return -1;
	}

	for(int G=2; G<=32 && G<=(int)pats.size(); G<<=1)
	{
		part_files.clear();

		FOR(k, G)
		{
			char a_part_file[512]={0};
			sprintf(a_part_file, "%s_part_%d_%d", rule_file, G, k);

			FILE * stream=fopen(a_part_file, "wb");
			if(stream!=NULL)
			{
				FOR(i, (int)pats.size())
				{
					if(i%G==k)
					{
						fprintf(stream, "%u\t%s\n", pats[i].pattern_id, pats[i].pattern.c_str());
						fflush(stream);
					}
				}
				fclose(stream);
				part_files.push_back(cstring(a_part_file));
			}
		}

		if((int)part_files.size()!=G) return -1;

		int ret=is_constructable(part_files, case_sensitive, max_state_num);
		if(ret>=0)
		{
			printf("try G=%d ok: total_state_num=%d\n",(int)part_files.size(), ret);
			printf("simple_partition() finishes!\n");
			return (int)part_files.size();
		}
		else
		{
			printf("try G=%d failed.\n",(int)part_files.size());
			FOR(k, (int)part_files.size())
			{
				remove(part_files[k].c_str());

				cstring ext_file=part_files[k]+".ext";
				remove(ext_file.c_str());

				cstring dfa_file=part_files[k]+".ext.dfa";
				remove(dfa_file.c_str());

				cstring split_file=part_files[k]+".split";
				remove(split_file.c_str());

				cstring unsplit_file=part_files[k]+".unsplit";
				remove(unsplit_file.c_str());
			}
			part_files.clear();
		}
	}

	printf("simple_partition() fails!\n");
	return -1;
}
