#ifndef H_PARTITION_H
#define H_PARTITION_H

#include "regex_def.h"
#include "cstring.h"

int rule_partition  (const char * rule_file, bool case_sensitive, int max_state_num, vector<cstring>& part_files);

int simple_partition(const char * rule_file, bool case_sensitive, int max_state_num, vector<cstring>& part_files);

#endif
