del /S /Q *.dfa
del /S /Q *.ext
del /S /Q *.split
del /S /Q *.unsplit
