import os
import platform

sysstr=platform.system()
if(sysstr=='Linux'):
    program='./regexmatching'
else:
    program='Release\\regexmatching.exe'

if os.path.isfile(program)==False:
    print "the program %s does not exist!\n" % program
    os.system('pause')
    exit()
    
test_cases=[]

test_cases.append(('-c', '1_rule.txt',  '1_text.txt',    '1_result.txt'))
test_cases.append(('-c', '2_rule.txt',  '2_text.txt',    '2_result.txt'))
test_cases.append(('-c', '3_rule.txt',  '3_text.txt',    '3_result.txt'))
test_cases.append(('-c', '4_rule.txt',  '4_text.txt',    '4_result.txt'))
test_cases.append(('-c', '5_rule.txt',  '5_text.txt',    '5_result.txt'))
test_cases.append(('-c', '6_rule.txt',  '6_text.txt',    '6_result.txt'))
test_cases.append(('-c', '7_rule.txt',  '7_text.txt',    '7_result.txt'))
test_cases.append(('-u', '8_rule.txt',  '8_text.txt',    '8_result.txt'))
test_cases.append(('-c', '9_rule.txt',  '9_text.txt',    '9_result.txt'))
test_cases.append(('-c', '10_rule.txt', '10_text.txt',   '10_result.txt'))
test_cases.append(('-c', '11_rule.txt', '11_text.txt',   '11_result.txt'))
test_cases.append(('-c', '12_rule.txt', '12_text.txt',   '12_result.txt'))
test_cases.append(('-c', '13_rule.txt', '13_text.txt',   '13_result.txt'))
test_cases.append(('-c', '14_rule.txt', '14_text_a.txt', '14_result_a.txt'))
test_cases.append(('-c', '14_rule.txt', '14_text_b.txt', '14_result_b.txt'))
test_cases.append(('-c', '14_rule.txt', '14_text_c.txt', '14_result_c.txt'))
test_cases.append(('-c', '15_rule.txt', '15_text.txt', '15_result.txt'))
test_cases.append(('-c', '16_rule.txt', '16_text_a.txt', '16_result_a.txt'))
test_cases.append(('-c', '16_rule.txt', '16_text_b.txt', '16_result_b.txt'))
test_cases.append(('-c', '17_rule.txt', '17_text_a.txt', '17_result_a.txt'))
test_cases.append(('-c', '17_rule.txt', '17_text_b.txt', '17_result_b.txt'))
test_cases.append(('-c', '18_rule.txt', '18_text.txt', '18_result.txt'))
test_cases.append(('-c', '19_rule.txt', '19_text.txt', '19_result.txt'))
test_cases.append(('-c', '20_rule.txt', '20_text.txt', '20_result.txt'))
test_cases.append(('-c', '21_rule.txt', '21_text.txt', '21_result.txt'))
test_cases.append(('-c', '22_rule.txt', '22_text.txt', '22_result.txt'))
test_cases.append(('-c', '23_rule.txt', '23_text.txt', '23_result.txt'))
test_cases.append(('-c', '24_rule.txt', '24_text.txt', '24_result.txt'))
test_cases.append(('-c', '25_rule.txt', '25_text.txt', '25_result.txt'))
test_cases.append(('-c', '26_rule.txt', '26_text.txt', '26_result.txt'))
test_cases.append(('-c', '27_rule.txt', '27_text.txt', '27_result.txt'))
test_cases.append(('-c', '28_rule.txt', '28_text.txt', '28_result.txt'))
test_cases.append(('-c', '29_rule.txt', '29_text.txt', '29_result.txt'))
test_cases.append(('-c', '30_rule.txt', '30_text.txt', '30_result.txt'))

test_cases.append(('-c', '100_rule.txt', '100_text_16.txt', '100_result_16.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_17.txt', '100_result_17.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_18.txt', '100_result_18.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_19.txt', '100_result_19.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_20_a.txt', '100_result_20_a.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_20_b.txt', '100_result_20_b.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_21.txt', '100_result_21.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_23.txt', '100_result_23.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_28_a.txt', '100_result_28_a.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_28_b.txt', '100_result_28_b.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_29.txt', '100_result_29.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_30_a.txt', '100_result_30_a.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_30_b.txt', '100_result_30_b.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_30_c.txt', '100_result_30_c.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_30_d.txt', '100_result_30_d.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_31.txt', '100_result_31.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_32.txt', '100_result_32.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_33.txt', '100_result_33.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_34.txt', '100_result_34.txt'))
test_cases.append(('-c', '100_rule.txt', '100_text_35.txt', '100_result_35.txt'))

test_cases.append(('-c', 'IPCJ_rule.txt', 'traffic.data', ''))

#test_cases.append(('-c', '200_rule.txt', '', ''))


for test_case in test_cases:
    cmd='%s %s test_cases%s%s test_cases%s%s test_cases%s%s' % (program, test_case[0], os.sep, test_case[1], os.sep, test_case[2], os.sep, test_case[3])
    print cmd
    os.system(cmd)
    print

os.system('pause')
