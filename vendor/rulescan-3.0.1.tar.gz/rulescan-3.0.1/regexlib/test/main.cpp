#include "../include/regex_matching.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <algorithm>
using namespace std;

// text_t read_text_from_file(const char *text_file)
// {
// 	text_t text;
// 	text.buff=NULL;
// 	text.buff_len=0;

// 	FILE * stream=fopen(text_file, "rb");
// 	if(stream==NULL) return text;

// 	fseek(stream, 0, SEEK_END);
// 	text.buff_len=(unsigned int)ftell(stream);
// 	fseek(stream, 0, SEEK_SET);
// 	text.buff=new char[text.buff_len];
// 	fread(text.buff, sizeof(char), text.buff_len, stream);
// 	fclose(stream);

// 	return text;
// }

// bool operator<(const struct one_regex_match_result& lhs, const struct one_regex_match_result& rhs)
// {
// 	if(lhs.pattern_id!=rhs.pattern_id) return lhs.pattern_id<rhs.pattern_id;
// 	if(lhs.group_id!=rhs.group_id) return lhs.group_id<rhs.group_id;
// 	if(lhs.position!=rhs.position) return lhs.position<rhs.position;
// 	return lhs.length<rhs.length;
// }

// bool verify_results(const struct regex_match_result& match_results, const char * result_file)
// {
// 	if(result_file==NULL) return false;

// 	FILE * stream=fopen(result_file, "rb");
// 	if(stream==NULL) return false;

// 	struct regex_match_result std_results;
// 	std_results.max_num=match_results.max_num;
// 	std_results.result_array=new struct one_regex_match_result[match_results.max_num];
// 	unsigned int r=0;

// 	while(!feof(stream))
// 	{
// 		char line[1024]={0};
// 		fgets(line, sizeof(line), stream);
// 		for(char * p=line; *p; ++p)
// 		{
// 			if(*p=='\r' || *p=='\n')
// 			{
// 				*p='\0';
// 				break;
// 			}
// 		}
// 		if(strlen(line)==0) continue;

// 		char * pb=strtok(line, "\t");
// 		if(pb==NULL) continue;
// 		unsigned int pattern_id=atoi(pb);

// 		pb=strtok(NULL, "\t");
// 		if(pb==NULL) continue;
// 		unsigned int group_id=atoi(pb);

// 		pb=strtok(NULL, "\t");
// 		if(pb==NULL) continue;
// 		unsigned int position=atoi(pb);

// 		pb=strtok(NULL, "\t");
// 		if(pb==NULL) continue;
// 		unsigned int length=atoi(pb);

// 		std_results.result_array[r].pattern_id=pattern_id;
// 		std_results.result_array[r].group_id  =group_id;
// 		std_results.result_array[r].position  =position;
// 		std_results.result_array[r].length    =length;
// 		r++;
// 	}
// 	std_results.match_num=r;
// 	sort(std_results.result_array, std_results.result_array+std_results.match_num);

// 	bool ret_code=true;

// 	ret_code=ret_code && (match_results.match_num==std_results.match_num);
// 	for(unsigned int i=0; i<std_results.match_num; i++)
// 	{
// 		ret_code = ret_code && (std_results.result_array[i].pattern_id==match_results.result_array[i].pattern_id);
// 		ret_code = ret_code && (std_results.result_array[i].group_id  ==match_results.result_array[i].group_id);
// 		ret_code = ret_code && (std_results.result_array[i].position  ==match_results.result_array[i].position);
// 		ret_code = ret_code && (std_results.result_array[i].length    ==match_results.result_array[i].length);
// 	}

// 	delete [] std_results.result_array;
// 	fclose(stream);
// 	return ret_code;
// }

// int main(int argc, char* argv[])
// {
// 	if(argc<4)
// 	{
// 		printf("usage: %s -c rule_file text_file result_file\n", argv[0]);
// 		printf("usage: %s -u rule_file text_file result_file\n", argv[0]);
// 		return 0;
// 	}

// 	bool case_sensitive=true;

// 	if(strcmp(argv[1], "-u")==0)
// 	{
// 		case_sensitive=false;
// 		printf("case_insensitive match...\n");
// 	}

// 	clock_t clk=clock();
// 	struct dfa_matcher *matcher = regex_preprocessing(argv[2], 16, case_sensitive, (1<<22),NULL,0);
// 	if(matcher==NULL)
// 	{
// 		printf("regex_preprocessing() failed!\n");
// 		return -1;
// 	}
// 	clk=clock()-clk;
// 	printf("preprocessing time=%5.3lf (s)\n", (double)clk/CLOCKS_PER_SEC);

// 	int thread_id=0;
// 	text_t text=read_text_from_file(argv[3]);

// 	struct regex_match_result match_results;
// 	match_results.max_num=10000;
// 	match_results.match_num=0;
// 	match_results.result_array=new struct one_regex_match_result[match_results.max_num];

// 	clk=clock();
// 	int ret=regex_searching(matcher, thread_id, &text, &match_results);
// 	if(ret<0)
// 	{
// 		printf("regex_searching() failed!\n");
// 		return -1;
// 	}
// 	clk=clock()-clk;
// 	double t=(double)clk/CLOCKS_PER_SEC;
// 	printf("searching time=%5.3lf (s), searching speed=%5.3lf (MB/s)\n", t, text.buff_len/t/(1U<<20));

// 	for(unsigned int i=0; i<match_results.match_num; i++)
// 	{
// 		printf("rule_id=%u, group_id=%u, position=%u, length=%u\n", match_results.result_array[i].pattern_id, match_results.result_array[i].group_id, match_results.result_array[i].position, match_results.result_array[i].length);
// 	}

// 	sort(match_results.result_array, match_results.result_array+match_results.match_num);

// 	if(argc>=5)
// 	{
// 		if(verify_results(match_results, argv[4]))
// 		{
// 			printf("status: passed the test!\n");
// 		}
// 		else
// 		{
// 			printf("status: failed the test!\n");
// 		}
// 	}

// 	delete [] text.buff;
// 	delete [] match_results.result_array;
// 	regex_destroy(instance);

// 	return 1;
// }
