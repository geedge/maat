/*
 *
 * Copyright (c) 2008-2014
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2014-11-13
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#ifndef H_REGEX_MATCHING_H
#define H_REGEX_MATCHING_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <stddef.h>
#include "../../rulescan.h"

struct dfa_matcher;
/**
 * @brief preprocessing the regex rule file to generate the DFA instance
 * 
 * @param rule_file: the regex rule file
 * @param max_thread_num: the max thread number
 * @param case_sensitive: case sensitive or not
 * @param max_state_num: the max state number of the DFA
 * @param failed_ids: the illegal rule ids
 * @param num: the number of the illegal rule ids
*/
struct dfa_matcher *regex_preprocessing(const char *rule_file, size_t thread_num,
						  				bool case_sensitive, int max_state_num,
						  				unsigned int *failed_ids, unsigned int num);

/**
 * @brief search the text by using the DFA instance
 * 
 * @param instance: the DFA instance
 * @param thread_id: the thread id
 * @param data: the data to be matched
 * @param data_len: the length of the data
 * @param match_results: the match results
*/
int regex_searching(struct dfa_matcher *matcher, long long *pattern_ids,
					size_t n_pattern_ids, int thread_id, const char *data,
					size_t data_len, int pos_offset, match_event_handler onEvent,
					void *context);

/**
 * @brief destroy the DFA instance
*/
void regex_destroy(struct dfa_matcher *matcher);

#ifdef __cplusplus
}
#endif

#endif /* H_REGEX_MATCHING_H */
