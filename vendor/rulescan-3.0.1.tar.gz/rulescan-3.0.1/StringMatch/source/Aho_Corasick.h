/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-03-26
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#ifndef H_AHO_CORASICK_CPP_H
#define H_AHO_CORASICK_CPP_H 

#include "Match.h"
#include "../../rulescan.h"

class CAhoCorasick :public CBaseStringMatch
{
private:
	typedef struct _stTrieNode
	{
		struct _stTrieNode* pstNext[MAX_CHAR_SETS];
		struct _stTrieNode* pstFailure;
		int * MatchedPattern;
	}stTrieNode;

public:
	CAhoCorasick();
	virtual ~CAhoCorasick();

	virtual int SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();

private:
	stTrieNode * m_state_table;
	unsigned int m_state_num;
};


#endif  // H_AHO_CORASICK_CPP_H 
