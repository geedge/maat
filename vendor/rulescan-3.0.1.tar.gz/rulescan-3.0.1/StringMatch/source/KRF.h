#ifndef H_KRF_CPP_H
#define H_KRF_CPP_H

#define USE_HASH_THREE

#include "Match.h"
#include "../../rulescan.h"

class CKRF : public CBaseStringMatch  
{
public:
	CKRF(unsigned int scale_bits=0);
	virtual ~CKRF();

	//ɨ�躯�������溯����Ҫ����ʵ��
	virtual int SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	//���溯����Ҫ����ʵ�֣��û����ܵ��ô˺���
	virtual long long Init();

	unsigned long long Hash(const unsigned char * s, unsigned int n);

	unsigned int rank(unsigned int h);

private:
	unsigned int    m_hash_table_size;

	unsigned int    m_bits;
	unsigned int    m_msk;
	unsigned char * m_hash_one;
	unsigned char * m_hash_two;
#ifdef USE_HASH_THREE
	unsigned char * m_hash_thr;
#endif

	unsigned long long m_B[256];

	packedRT_t *       m_RT; 
	pattern_t **       m_pat_array;
};

#endif // !defined(H_KRF_CPP_H)
