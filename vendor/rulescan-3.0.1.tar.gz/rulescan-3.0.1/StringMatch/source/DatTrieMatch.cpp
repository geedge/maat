/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2010-01-12
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

#include "DatTrieMatch.h"

//#define DEBUG_DTM

CDatTrieMatch::CDatTrieMatch()
{
}

CDatTrieMatch::~CDatTrieMatch()
{
}

int CDatTrieMatch::SearchMem(const char *data, size_t data_len, int pos_offset,
							 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
							 match_event_handler onEvent, void *context)
{
	if (NULL == data || 0 == data_len || 0 == m_pat_num) {
		return 0;
	}

	CDatTrie::stDatTrieNode * pDat = &(this->m_DatTrie.m_astDatTrie[0]);
	int root=this->m_DatTrie.GetRoot();

	const unsigned char *F = (const unsigned char *)data;
	const unsigned char *L = F + data_len;
	const unsigned char *pb = F;
	const unsigned char *pe = L - m_min_pat_len;

	while (pb <= pe) {
		int s=root;
		const unsigned char *pTxt = pb + m_min_pat_len -  1;
		while (pTxt >= pb) {
			int t = pDat[s].base + m_case_tab[*pTxt];
			if (pDat[t].check != s) break;
			s = t;
			--pTxt;
		}

		if (pTxt >= pb) {
			pb = pTxt + 1;
		} else {
			for (const pattern_t *pt = m_patterns+pDat[s].base; pt!=NULL; pt=pt->next) {	
				if(pb>=F+pt->tag && pb-F-pt->tag+pt->pattern_len<= data_len) {
					const unsigned char * txt=pb-pt->tag;
					unsigned int k=0;
					while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

					if (k == pt->pattern_len) {
						int from = (int)(txt - F);
						std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
						if (it != pat_cs.end()) {
							if (1 == it->second.case_sensitive &&
					    		memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
								continue;
							}
						}

						int to = from + pt->pattern_len;
						int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
						if(ret<0) return -1;
					}
				}
			}
			pb++;
		}
	}

	return 0;
}

long long CDatTrieMatch::Init()
{
#ifdef DEBUG_DTM
	clock_t clk=clock();
#endif

	this->optimal_window();
	//构造剪枝的suffix trie
	stTrieNode * pstRoot=this->BuildBlockTrie();
	if(pstRoot==NULL) return -1;

#ifdef DEBUG_DTM
	clk=clock()-clk;
	cout << "build trie time (s): " << (double)clk/CLOCKS_PER_SEC << endl;

	//打印结点个数
	cout << "DatTrieMatch node count: " << this->m_iNodeCount << endl;
#endif

#ifdef DEBUG_DTM
	clk=clock();
#endif

	//从剪枝的suffix trie构造双数组trie
	if(this->BuildDatTrie(pstRoot)<0) return -1;

#ifdef DEBUG_DTM
	clk=clock()-clk;
	cout << "build dat time (s): " << (double)clk/CLOCKS_PER_SEC << endl;

	//ResizeCount
	cout << "Resize Count: " << this->m_DatTrie.m_iResizeCount << endl;

	//打印双数组的信息
	cout << "Dat Array Size: " << this->m_DatTrie.m_iSize 
		<< ", Density: " << (double)this->m_iNodeCount / this->m_DatTrie.m_iSize << endl;

#endif

	//统计耗用的内存空�?
	long long space_used = (long long)this->m_DatTrie.m_iSize*sizeof(int)*2;

	//打印耗用的内�?
#ifdef DEBUG_DTM
	cout << "DatTrieMatch Space Used (MB): " << (double)space_used/(1<<20) << endl; 
#endif

	return space_used;
}

CDatTrieMatch::stTrieNode * CDatTrieMatch::BuildBlockTrie()
{
	//限制最短关键词的长�?
//	if(this->m_min_pat_len>10) this->m_min_pat_len=10;

	//生成根节�?
	this->m_iNodeCount=0;
	stTrieNode * pstRoot=this->NewTrieNode();

	// 构造剪枝的suffix trie
	FOR(i, m_pat_num)
	{
		stTrieNode * pstCurrNode=NULL;

		FOR(k, this->m_min_pat_len)
		{			
			pstCurrNode=pstRoot;

			const unsigned char * pb=(const unsigned char *)m_patterns[i].pattern+m_patterns[i].tag+k;
			const unsigned char * pe=(const unsigned char *)m_patterns[i].pattern+m_patterns[i].tag-1;

			for( ; pb>pe; --pb)
			{
				if(pstCurrNode->pstChilds.find(*pb)==pstCurrNode->pstChilds.end()) break;
				pstCurrNode=pstCurrNode->pstChilds[*pb];
			}

			for( ; pb>pe; --pb)
			{
				pstCurrNode->pstChilds[*pb]=this->NewTrieNode();
				pstCurrNode=pstCurrNode->pstChilds[*pb];
			}
		}

		//将该关键词添加到当前结点的队列中�?
		if(pstCurrNode->pt>=0)
		{
			this->m_patterns[i].next=&(m_patterns[pstCurrNode->pt]);
			pstCurrNode->pt=i;
		}
		pstCurrNode->pt=i;
	}

	return pstRoot;
}

CDatTrieMatch::stTrieNode * CDatTrieMatch::NewTrieNode()
{
	stTrieNode * pstNode=new stTrieNode;
	pstNode->pt=-1;
	this->m_iNodeCount++;
	return pstNode;
}

int CDatTrieMatch::BuildDatTrie(stTrieNode * pstRoot)
{
	//构造双数组
	this->m_DatTrie.InitDatTrie((int)(this->m_iNodeCount*1.5));

	queue< pair<int, stTrieNode*> > Q;

	int r = this->m_DatTrie.GetRoot();

	for(Q.push(make_pair(r, pstRoot)); !Q.empty(); 	Q.pop())
	{
		int s = Q.front().first;
		stTrieNode * stWorkNode = Q.front().second;

		if( stWorkNode->pstChilds.size()>0 )
		{
			int base = this->FindBase(stWorkNode);
			this->m_DatTrie.SetBase(s, base);

			for(TMapIter pIter=stWorkNode->pstChilds.begin(), pEnd=stWorkNode->pstChilds.end();
				pIter!=pEnd;
				++pIter)  
			{
				unsigned char c = pIter->first;
				stTrieNode * pstChild = pIter->second;
				int t = base + c;
				this->m_DatTrie.SetCheck(t, s);
				Q.push(make_pair(t, pstChild));
			}
		}
		else
		{
			if(stWorkNode->pt>=0)
			{
				this->m_DatTrie.SetBase(s, stWorkNode->pt);
			}
		}

		delete stWorkNode;
	}

	//去除多余的结�?
	this->m_DatTrie.RemoveFreeNodes();

	return 1;
}

int CDatTrieMatch::FindBase(stTrieNode * pstWorkNode)
{
	vector<int> Childs;

	for(TMapIter pIter=pstWorkNode->pstChilds.begin(), pEnd=pstWorkNode->pstChilds.end();
		pIter!=pEnd;
		++pIter)
	{
		Childs.push_back(pIter->first);
	}

	return this->m_DatTrie.FindBase(Childs);
}
