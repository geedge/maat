/*
 *
 * Copyright (c) 2006
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:		Tan Jian-long	(tan@software.ict.ac.cn)
 *				Liu Ping		(liuping@software.ict.ac.cn)
 *				Liu Yan-bing	(liuyanbing@software.ict.ac.cn)
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written 
 * permission from the authors.
 *
 */

#include "DatTrie.h"

const CDatTrie::stDatTrieNode stDefNode = {0, 0}; //���н���check��ʼ��Ϊ0

#define DAT_R 1.2 //ÿ������ռ�����ı���

#define MAX_FREE_LIST_SIZE	1000

CDatTrie::CDatTrie()
{

}

CDatTrie::~CDatTrie()
{

}

int CDatTrie::InitDatTrie(int iInitSize)
{
	if(iInitSize<DAT_INIT_SIZE) iInitSize=DAT_INIT_SIZE;

    assert(iInitSize*(DAT_R-1)>MAX_CHAR_SETS);

    //����˫����ĳ�ʼ��С
    this->m_iSize=iInitSize;
    this->m_astDatTrie.resize(this->m_iSize+MAX_CHAR_SETS, stDefNode);

    //���0�ǿ��н���ͷ���
	this->SetCheck(0, 0);
    this->SetBase(0, 0);

	//���ø����Ϊ1,�丸���Ϊ0
	this->SetCheck(1, 0);

    //�ɿ��������ʼλ��
	this->m_iBlkBeg=MAX_CHAR_SETS+1;

	//���������Ĵ�С
	this->m_iFreeListSize=0;

    this->m_iResizeCount=0;

	return 1;
}

int CDatTrie::GetRoot()
{
    // 1Ϊ�����
	return 1;
}

int CDatTrie::FindBase(const vector<int>& Childs)
{
	while(this->m_iFreeListSize>MAX_FREE_LIST_SIZE)
	{
		this->FreeList_PopFront();
	}

    int iChildCount=(int)Childs.size();

    if(iChildCount==0) return 1;

    vector<int> Offsets(iChildCount);

    for(int i=0; i<iChildCount; i++)
    {
        Offsets[i] = Childs[i]-Childs[0];
    }

	//������ʼλ��
    int iBegPos = this->GetNextFreeNode(0);

    for(int i=1; i<iChildCount; i++)
    {
        int iCurPos=iBegPos+Offsets[i];
		if(iCurPos>=this->m_iBlkBeg) break;

        if(this->m_astDatTrie[iCurPos].check>0)
        {
            iBegPos=this->GetNextFreeNode(iBegPos);
            i=0;
        }
    }

	int iEndPos=iBegPos+Offsets[iChildCount-1];
    if(iEndPos>=this->m_iSize)
    {
        this->Resize((int)(DAT_R*this->m_iSize));
    }

	int j=0;
    for( ; j<iChildCount; j++)
    {
		int iCurPos=iBegPos+Offsets[j];
		if(iCurPos>=this->m_iBlkBeg) break;
		assert(this->m_astDatTrie[iCurPos].check<=0);
        this->FreeList_Delete(iCurPos);
    }

	int idx=this->m_iBlkBeg;
    for( ; j<iChildCount; j++)
    {
		for(int iCurPos=iBegPos+Offsets[j]; idx<iCurPos; idx++)
		{
			this->FreeList_PushBack(idx);
		}
		idx++;
    }
	this->m_iBlkBeg=idx;

	return iBegPos-Childs[0];
}

//�� iFreePos ֮������һ�����н��
int CDatTrie::GetNextFreeNode(int iFreePos)
{
	assert(iFreePos>=0 && iFreePos<m_iSize);

	int iBegPos=-m_astDatTrie[iFreePos].base;
	if(iBegPos==0) iBegPos=this->m_iBlkBeg;

	return iBegPos;
}

//Ϊ��ʡ�洢�ռ䣬ȥ��˫����β���Ŀ��н��
int CDatTrie::RemoveFreeNodes()
{
    for(int i=m_iSize-1; i>MAX_CHAR_SETS; i--)
	{
		if(this->m_astDatTrie[i].check>0)
        {
            this->Resize(i+1);
            break;
        }
	}	

	//ʹ��swapʹ��vector���������಻�٣�ǡ���ô�
	vector<stDatTrieNode>(m_astDatTrie).swap(m_astDatTrie);

	return 1;
}

int CDatTrie::Resize(int iNewSize)
{
     this->m_iSize=iNewSize;

    //������MAX_CHAR_SETS������ֹԽ��
	this->m_astDatTrie.resize(iNewSize+MAX_CHAR_SETS, stDefNode);

    this->m_iResizeCount++;

	return 1;
}

int CDatTrie::SetBase(int iPos, int iBaseVal)
{
	assert(iPos>=0 && iPos<this->m_iSize);
	this->m_astDatTrie[iPos].base = iBaseVal;
	return 1;
}

int CDatTrie::SetCheck(int iPos, int iCheckVal)
{
    assert(iPos>=0 && iPos<this->m_iSize);
	this->m_astDatTrie[iPos].check = iCheckVal;
	return 1;
}

// add free node idx to free node list
int CDatTrie::FreeList_PushBack(int idx)
{
    assert( (idx>MAX_CHAR_SETS) && (idx<m_iSize) );

    int iOldLast = -this->m_astDatTrie[0].check; // the last node in free list
    this->m_astDatTrie[iOldLast].base = -idx;
    this->m_astDatTrie[idx].base = 0;
    this->m_astDatTrie[idx].check = -iOldLast;
    this->m_astDatTrie[0].check = -idx;

	this->m_iFreeListSize++;

    return 1;
}

int CDatTrie::FreeList_Delete(int idx)
{
    assert( (idx>MAX_CHAR_SETS) && (idx<m_iSize) );

    int next = -this->m_astDatTrie[idx].base;
    int prev = -this->m_astDatTrie[idx].check;

    assert( next>=0 && next<m_iSize );
    assert( prev>=0 && prev<m_iSize );

    this->m_astDatTrie[prev].base  = -next;
    this->m_astDatTrie[next].check = -prev;

    this->m_astDatTrie[idx] = stDefNode;

	this->m_iFreeListSize--;

    return 1;
}

int CDatTrie::FreeList_PopFront()
{
	int idx=-this->m_astDatTrie[0].base;
	if(idx==0) return 0;

	this->FreeList_Delete(idx);	
	return 1;
}

