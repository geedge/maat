#include "DatAC.h"

#include <algorithm>
#include <numeric>
#include <map>
using namespace std;

CDatAC::CDatAC()
{
	m_supply=NULL;
	m_matched_ptr=NULL;
	m_matched_ids=NULL;
	m_bitmap=NULL;
}

CDatAC::~CDatAC()
{
	if(m_supply!=NULL)      delete [] m_supply;
	if(m_matched_ptr!=NULL) delete [] m_matched_ptr;
	if(m_matched_ids!=NULL) delete [] m_matched_ids;
	if(m_bitmap!=NULL)      delete [] m_bitmap;
}

long long CDatAC::Init()
{
	long long mem_bytes=0;

	//����Trie��
	int iStateNum=0;
	stTrieNode * pstRoot=new stTrieNode;
	pstRoot->iIndex=-1;
	iStateNum++;
	vector< vector<int> > MPL;

	FOR(i, m_pat_num)
    {
		const unsigned char * pb=(const unsigned char *)m_patterns[i].pattern;
		const unsigned char * pe=pb+m_patterns[i].pattern_len;
		stTrieNode * pstCurrState=pstRoot;

		for( ; pb!=pe; pb++)
		{
			if(pstCurrState->pstChilds.find(*pb)==pstCurrState->pstChilds.end()) break;
			pstCurrState=pstCurrState->pstChilds[*pb];
		}

		for( ; pb!=pe; pb++)
		{
			stTrieNode * pstNewNode=new stTrieNode;
			pstNewNode->iIndex=-1;
			iStateNum++;
			pstCurrState->pstChilds[*pb]=pstNewNode;
			pstCurrState=pstNewNode;
		}

		if(pstCurrState->iIndex==-1)
		{
			pstCurrState->iIndex=(int)MPL.size();
			MPL.push_back(vector<int>());
		}

		MPL[pstCurrState->iIndex].push_back(i);
    }

	//����˫����
    this->m_DatTrie.InitDatTrie((int)(iStateNum*1.5));
	queue< pair<int, stTrieNode*> > Q;
	int r = this->m_DatTrie.GetRoot();
	int max_state_id=0;
	map<int, int> M;

	for(Q.push(make_pair(r, pstRoot)); !Q.empty(); Q.pop())
	{
		int s                   = Q.front().first;
		stTrieNode * stWorkNode = Q.front().second;
		
		if(stWorkNode->iIndex>=0) M[s]=stWorkNode->iIndex;
		if(s>max_state_id) max_state_id=s;

		if(stWorkNode->pstChilds.size()>0)
		{
			int base = this->FindBase(stWorkNode);
			this->m_DatTrie.SetBase(s, base);

			for(TMapIter pIter=stWorkNode->pstChilds.begin(), pEnd=stWorkNode->pstChilds.end();
				pIter!=pEnd;
				++pIter)  
			{
				unsigned char c       = pIter->first;
				stTrieNode * pstChild = pIter->second;
				int t = base + c;
				this->m_DatTrie.SetCheck(t, s);
				Q.push(make_pair(t, pstChild));
			}
		}

		delete stWorkNode;
		--iStateNum;
	}

	this->m_DatTrie.RemoveFreeNodes(); //ȥ������Ľ��

	mem_bytes+=(long long)sizeof(int)*m_DatTrie.m_iSize*2;
	
	//���� supply link
	queue<int> Qu;
	CDatTrie::stDatTrieNode * pDatTrie=&(m_DatTrie.m_astDatTrie[0]);
	m_supply=new int[max_state_id+1];
	FOR(i, max_state_id+1) m_supply[i]=-1;

	mem_bytes+=sizeof(int)*(max_state_id+1);

	for(Qu.push(r); !Qu.empty(); Qu.pop())
	{
		int parent = Qu.front();

		FOR(i, MAX_CHAR_SETS)
		{
			int current=pDatTrie[parent].base+i;
			if(pDatTrie[current].check!=parent) continue;
			Qu.push(current);

			int down=m_supply[parent];

			while(down>=0)
			{
				int next=pDatTrie[down].base+i;
				if(pDatTrie[next].check==down) break;
				down=m_supply[down];
			}

			if(down>=0)
			{
				m_supply[current]=pDatTrie[down].base+i;
			}
			else
			{
				m_supply[current]=r;
			}

			if(M.find(m_supply[current])!=M.end())
			{
				int i1=M[m_supply[current]];
				if(M.find(current)==M.end())
				{
					M[current]=(int)MPL.size();
					MPL.push_back(vector<int>());
				}
				int i2=M[current];
				copy(MPL[i1].begin(), MPL[i1].end(), back_inserter(MPL[i2]));
			}	
		}
	}

	unsigned int size=0;
	FOR(i, (int)MPL.size())
	{
		size+=(unsigned int)MPL[i].size();
	}

	m_matched_ids=new int[size];
	m_matched_ptr=new int[max_state_id+2];
	m_bitmap=new unsigned int[(max_state_id>>5)+1];
	memset(m_bitmap, 0, sizeof(unsigned int)*((max_state_id>>5)+1));

	mem_bytes+=sizeof(int)*(size+max_state_id+2+(max_state_id>>5)+1);

	int j=0;
	FOR(i, max_state_id+1)
	{
		m_matched_ptr[i]=j;
		if(M.find(i)!=M.end())
		{
			m_bitmap[i>>5]|=(1U<<(i&31));
			int k=M[i];
			copy(MPL[k].begin(), MPL[k].end(), m_matched_ids+j);
			j+=(int)MPL[k].size();			
		}
	}
	m_matched_ptr[max_state_id+1]=j;

	return mem_bytes;
}

int CDatAC::FindBase(stTrieNode * pstWorkNode)
{
	vector<int> Childs;

    for (TMapIter pIter = pstWorkNode->pstChilds.begin(),
                    pEnd = pstWorkNode->pstChilds.end();
        pIter != pEnd; ++pIter) {
        Childs.push_back(pIter->first);
    }

    return this->m_DatTrie.FindBase(Childs);
}

int CDatAC::SearchMem(const char *data, unsigned int data_len, int pos_offset,
                      const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
					  match_event_handler onEvent, void *context) 
{
    if (NULL == data || 0 == data_len || 0 == this->m_pat_num) {
                return 0;
    }

    unsigned char *pb = (unsigned char *)data;
    unsigned char *pe = pb + data_len;
    CDatTrie::stDatTrieNode *pDatTrie = &(m_DatTrie.m_astDatTrie[0]);
    int r = m_DatTrie.GetRoot();
    int iCurrState = r;

    for (; pb != pe; pb++) {
        unsigned char c = m_case_tab[*pb];
        int iNextState = pDatTrie[iCurrState].base + c;  // һ�ηô棬һ�μӷ�
        while (pDatTrie[iNextState].check != iCurrState &&
                (iCurrState = m_supply[iCurrState]) != -1) {
                iNextState = pDatTrie[iCurrState].base + c;
        }
        iCurrState = (iCurrState < 0) ? r : iNextState;

        if (m_bitmap[iCurrState >> 5] & (1U << (iCurrState & 31))) {
                for (int j = m_matched_ptr[iCurrState]; j < m_matched_ptr[iCurrState + 1]; j++) {
                        unsigned int h = m_matched_ids[j];
                        unsigned int pat_id = m_patterns[h].pattern_id;
						int from = (int)(pb + 1 - m_patterns[h].pattern_len -(unsigned char *)data);
						
						std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pat_id);
						if (it != pat_cs.end()) {
							if (1 == it->second.case_sensitive &&
					    		memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
								continue;
							}
						}
						
						int to = from + m_patterns[h].pattern_len;
                        int ret = onEvent(pat_id, pos_offset, from, to, data_len, context);
                        if (ret < 0) return -1;
                }
        }
    }

    return 0;
}
