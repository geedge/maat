/*
 *
 * Copyright (c) 2006
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:		Tan Jian-long	(tan@software.ict.ac.cn)
 *				Liu Ping		(liuping@software.ict.ac.cn)
 *				Liu Yan-bing	(liuyanbing@software.ict.ac.cn)
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written 
 * permission from the authors.
 *
 */


#ifndef DOUBLE_ARRAY_TRIE_CPP_H
#define DOUBLE_ARRAY_TRIE_CPP_H

/*********************************************************************
*		Double-Array Trie
*		Liu Yanbing  2005.6.10
*
*       optimized version: 2006.06.24
*
**********************************************************************/

#include "Match.h"

#define DAT_INIT_SIZE   2048 //����ĳ�ʼ����С

class CDatTrie
{
public:
	struct stDatTrieNode
	{
		int base;
		int check;
	};

public:
	CDatTrie();
	~CDatTrie();

	int InitDatTrie(int iInitSize=DAT_INIT_SIZE);
	int GetRoot();
    int FindBase(const vector<int>& Childs);
	int SetBase(int iPos, int iBaseVal);
	int SetCheck(int iPos, int iCheckVal);
	int RemoveFreeNodes();

private:
	int Resize(int iNewSize);
    int FreeList_PushBack(int idx);
	int FreeList_PopFront();
    int FreeList_Delete(int idx);
    int GetNextFreeNode(int iFreePos);

public:
	vector<stDatTrieNode>	m_astDatTrie;
    int                     m_iSize;
	// [m_iBlkBeg, m_iSize) �ǳɿ�Ŀ������򣬲��������������ȥ
	int                     m_iBlkBeg;
	int                     m_iFreeListSize;

    int                     m_iResizeCount;
};

#endif
