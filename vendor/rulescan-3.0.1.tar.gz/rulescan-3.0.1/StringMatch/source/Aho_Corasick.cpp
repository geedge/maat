/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-03-26
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

//#define DEBUG_AHO_CORASICK

#include "Aho_Corasick.h"

#define ULLONG(x) ((unsigned long long)(x))
#define MSB_MASK  (ULLONG(1)<<(8*sizeof(int *)-1))

CAhoCorasick::CAhoCorasick()
{
	m_state_table=NULL;
	m_state_num=0;
}

CAhoCorasick::~CAhoCorasick()
{
	if(m_state_num>0 && m_state_table!=NULL)
	{
		FOR(i, m_state_num)
		{
			if(m_state_table[i].MatchedPattern!=NULL)
			{
				delete [] m_state_table[i].MatchedPattern;
			}
		}
		delete [] m_state_table;
	}
}

long long CAhoCorasick::Init()
{
	m_state_num=count_ac_nodes()+1; //����һ��������

	m_state_table=new stTrieNode[m_state_num];
	FOR(i, m_state_num)
	{
		FOR(c, MAX_CHAR_SETS) m_state_table[i].pstNext[c]=NULL;
		m_state_table[i].MatchedPattern=NULL;
		m_state_table[i].pstFailure=NULL;
	}

	//��������NULL���͸����
	FOR(c, MAX_CHAR_SETS)
	{
		m_state_table[0].pstNext[c]=m_state_table+1;
	}

	//����Trie��
	unsigned int J=2;
	FOR(k, m_pat_num)
	{
		stTrieNode * pstNode=m_state_table+1;
		const unsigned char * pb=(const unsigned char *)m_patterns[k].pattern;
		const unsigned char * pe=pb+m_patterns[k].pattern_len;

		for( ; pb<pe; ++pb)
		{
			if(pstNode->pstNext[*pb]==NULL)
			{
				pstNode->pstNext[*pb]=m_state_table+J;
				J++;
			}
			pstNode=pstNode->pstNext[*pb];
		}

		if(pstNode->MatchedPattern==NULL)
		{
			pstNode->MatchedPattern=new int[2];
			pstNode->MatchedPattern[0]=1;
			pstNode->MatchedPattern[1]=k;
		}
		else
		{
			int N=pstNode->MatchedPattern[0];
			int * p=new int[2+N];
			p[0]=N+1;
			for(int h=1; h<=N; h++) p[h]=pstNode->MatchedPattern[h];
			p[N+1]=k;
			delete [] pstNode->MatchedPattern;
			pstNode->MatchedPattern=p;
		}
	}

	//������ȫ���Զ���
	queue<stTrieNode *> Queue;

	m_state_table[1].pstFailure=m_state_table;

	for(Queue.push(m_state_table+1); !Queue.empty(); Queue.pop())
	{
		stTrieNode * parent=Queue.front();

		FOR(c, MAX_CHAR_SETS)
		{
			stTrieNode * current=parent->pstNext[c];

			if(current==NULL)
			{
				parent->pstNext[c]=parent->pstFailure->pstNext[c];
			}
			else
			{
				Queue.push(current);

				stTrieNode * down=parent->pstFailure;
				while(down->pstNext[c]==NULL)
				{
					down=down->pstFailure;
				}
				down=down->pstNext[c];
				current->pstFailure=down;

				if(down->MatchedPattern!=NULL)
				{
					int N2=down->MatchedPattern[0];
					if(current->MatchedPattern==NULL)
					{
						current->MatchedPattern=new int[1+N2];
						current->MatchedPattern[0]=N2;
						for(int h=1; h<=N2; h++) current->MatchedPattern[h]=down->MatchedPattern[h];
					}
					else
					{
						int N1=current->MatchedPattern[0];
						int * p=new int[1+N1+N2];
						p[0]=N1+N2;
						for(int h=1; h<=N1; h++) p[h]=current->MatchedPattern[h];
						for(int h=1; h<=N2; h++) p[h+N1]=down->MatchedPattern[h];
						delete [] current->MatchedPattern;
						current->MatchedPattern=p;
					}
				}
			}
		}
	}

	for(unsigned int i=0; i<m_state_num; ++i)
	{
		FOR(c, MAX_CHAR_SETS)
		{
			stTrieNode * current=m_state_table[i].pstNext[c];
			if(current->MatchedPattern!=NULL)
			{
				m_state_table[i].pstNext[c]=(stTrieNode *)(ULLONG(current)|MSB_MASK);
			}
		}
	}

#ifdef DEBUG_AHO_CORASICK
	cout << "Aho_Corasick state num (including the virtual NULL state)=" << m_state_num << endl;
#endif

	long long mem_bytes=(long long)m_state_num*sizeof(stTrieNode);
	for(unsigned int i=0; i<m_state_num; ++i)
	{
		if(m_state_table[i].MatchedPattern!=NULL)
		{
			mem_bytes+=(int)(m_state_table[i].MatchedPattern[0]+1)*sizeof(int);
		}
	}

	return mem_bytes;
}

int CAhoCorasick::SearchMem(const char *data, size_t data_len, int pos_offset,
							const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
							match_event_handler onEvent, void *context)
{
	if(m_pat_num==0 || m_state_table==NULL) return 0;

	const unsigned char *pb = (const unsigned char *)data;
	const unsigned char *pe = pb + data_len;
	stTrieNode *pCurrState = m_state_table + 1;

	for( ; pb < pe; ++pb) {
		unsigned char c = m_case_tab[*pb];
		pCurrState = pCurrState->pstNext[c];

		if (ULLONG(pCurrState) & MSB_MASK) {
			pCurrState = (stTrieNode *)(ULLONG(pCurrState) ^ MSB_MASK);
			FOR(k, pCurrState->MatchedPattern[0]) {
				int h = pCurrState->MatchedPattern[1+k];
				unsigned int pat_id = this->m_patterns[h].pattern_id;
				int from = (int)((const char *)pb + 1 - m_patterns[h].pattern_len - data);

				std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pat_id);
				if (it != pat_cs.end()) {
					if (1 == it->second.case_sensitive &&
					    memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
						continue;
					}
				}
				
				int to = from + m_patterns[h].pattern_len;
				int ret = onEvent(pat_id, pos_offset, from, to, data_len, context);
	
				if (ret < 0) return -1;	// return immediately on hit
			}
		}
	}

	return 0;
}
