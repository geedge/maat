/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-04-01
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#include "WuManber.h"

//#define DEBUG_WU_MANBER

static const unsigned long long ONE=1;

unsigned int roundup_power2(unsigned long long x)
{
	unsigned int bits=1;
	while((ONE<<bits)<x) bits++;
	return bits;
}

CWuManber::CWuManber(unsigned int block_size, unsigned int scale_bits)
{
	m_block_size=block_size;
	m_hash_bits=scale_bits;
	m_shift_table=NULL;
	m_bitmap=NULL;
	m_pat_array=NULL;
	m_RT=NULL;
}

CWuManber::~CWuManber()
{
	if(m_shift_table!=NULL) delete [] m_shift_table;
	if(m_bitmap!=NULL)      delete [] m_bitmap;
	if(m_pat_array!=NULL)   delete [] m_pat_array;
	if(m_RT!=NULL)          aligned_free(m_RT);
}

long long CWuManber::Init()
{
	long long mem_bytes=0;

	if(m_block_size==0) m_block_size=6; /*���δ���ÿ��С��������Զ�������*/
	if(m_block_size>m_min_pat_len) m_block_size=m_min_pat_len;

	m_max_shift_distance=m_min_pat_len-m_block_size+1;

	this->optimal_window();

	if(m_hash_bits==0) m_hash_bits=2; /*���δ���ù�ϣ�������ű�����������Զ�������*/
	m_hash_bits+=roundup_power2((m_min_pat_len-m_block_size+1)*(unsigned long long)m_pat_num);
	if(m_hash_bits<8) m_hash_bits=8;
	//{
	//	printf("m_hash_bits<8\n");
	//	exit(0);
	//}

	m_RT=(packedRT_t *)aligned_malloc(sizeof(packedRT_t)*((1U<<(m_hash_bits-8))+1), 64);
	FOR(i, (1U<<(m_hash_bits-8)))
	{
		FOR(j, 4) m_RT[i].bitmap[j]=0;
	}
	mem_bytes+=sizeof(packedRT_t)*((ONE<<(m_hash_bits-8))+1);

	m_shift_table=new unsigned char[(ONE<<m_hash_bits)];
	FOR(i, (1U<<m_hash_bits))
	{
		m_shift_table[i]=(unsigned char)m_max_shift_distance;
	}
	mem_bytes+=(ONE<<m_hash_bits)*sizeof(char);

	FOR(i, m_pat_num)
	{
		const unsigned char * F=(unsigned char *)m_patterns[i].pattern+m_patterns[i].tag;

		for(unsigned int j=0; j<=m_min_pat_len-m_block_size; j++)
		{
			unsigned int h=poly_hash(F+j, m_block_size);
			h&=((ONE<<m_hash_bits)-1);

			if(m_shift_table[h]>m_min_pat_len-m_block_size-j)
			{
				m_shift_table[h]=m_min_pat_len-m_block_size-j;
			}

			if(j==m_min_pat_len-m_block_size)
			{
				int q=h&255;
				m_RT[h>>8].bitmap[q>>6]|=(ONE<<(q&63));
			}
		}
	}

	unsigned int N=(((ONE<<m_hash_bits)+7)>>3);
	m_bitmap=new unsigned char[N];
	memset(m_bitmap, 0, N);
	FOR(i, (ONE<<m_hash_bits))
	{
		if(m_shift_table[i]==m_max_shift_distance)
		{
			m_bitmap[i>>3]|=(1U<<(i&7));
		}
	}
	mem_bytes+=N*sizeof(char);

	m_RT[0].A=0;
	FOR(i, (ONE<<(m_hash_bits-8)))
	{
		m_RT[i].B[0]=0;
		m_RT[i].B[1]=                      (unsigned char)popcnt_u64(m_RT[i].bitmap[0]);
		m_RT[i].B[2]=         m_RT[i].B[1]+(unsigned char)popcnt_u64(m_RT[i].bitmap[1]);
		m_RT[i].B[3]=         m_RT[i].B[2]+(unsigned char)popcnt_u64(m_RT[i].bitmap[2]);
		m_RT[i+1].A=m_RT[i].A+m_RT[i].B[3]+(unsigned int )popcnt_u64(m_RT[i].bitmap[3]);
	}

	int tn=m_RT[(ONE<<(m_hash_bits-8))].A;

	m_pat_array=new pattern_t *[tn];
	FOR(i, tn) m_pat_array[i]=NULL;
	mem_bytes+=sizeof(pattern_t *)*tn;

	FOR(k, m_pat_num)
	{
		const unsigned char * F=(const unsigned char *)m_patterns[k].pattern+m_patterns[k].tag;

		unsigned int h=poly_hash(F+m_min_pat_len-m_block_size, m_block_size);
		h&=((ONE<<m_hash_bits)-1);
		unsigned idx=rank(h);
		m_patterns[k].next=m_pat_array[idx];
		m_pat_array[idx]=&(m_patterns[k]);
	}

	return mem_bytes;
}

unsigned int CWuManber::rank(unsigned int h)
{
	int p=(h>>8);
	int r=((h&255)>>6);
	int s=(h&63);
	unsigned long long e=m_RT[p].bitmap[r]&((ONE<<s)-1);

	return m_RT[p].A+m_RT[p].B[r]+(unsigned int)popcnt_u64(e);
}

int CWuManber::SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context)
{
	if (NULL == data || 0 == data_len || 0 == m_pat_num) {
		return 0;
	}

	const unsigned char *F = (const unsigned char*)data;
	const unsigned char *L = F + data_len;
	const unsigned char *pb = F;
	const unsigned char *pe = L - m_min_pat_len;

	while (pb <= pe) {
		unsigned int h = poly_hash(pb + m_min_pat_len - m_block_size, m_block_size);
		h&=((ONE<<m_hash_bits)-1);

		if (m_bitmap[h>>3] & (1U<<(h&7))) {
			pb+=m_max_shift_distance;
		} else {
			unsigned int d=m_shift_table[h];
			if (d > 0) {
				pb += d;
			} else {
				int q = h & 255;
				if(m_RT[h>>8].bitmap[q>>6] & (ONE<<(q&63))) {
					unsigned idx=rank(h);
					for(pattern_t * pt=m_pat_array[idx]; pt!=NULL; pt=pt->next) {
						if (pb>=F+pt->tag && pb-pt->tag+pt->pattern_len <= L) {
							const unsigned char * txt=pb-pt->tag;
							unsigned int k=0;
							while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

							if (k == pt->pattern_len) {
								int from = (int)(pb - F - pt->tag);
								std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
								if (it != pat_cs.end()) {
									if (1 == it->second.case_sensitive &&
					    				memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
										continue;
									}
								}
								
								int to = from + pt->pattern_len;
								int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
								if(ret<0) return -1;
							}
						}
					}
				}
				pb++;
			}
		}
	}

	return 0;
}
