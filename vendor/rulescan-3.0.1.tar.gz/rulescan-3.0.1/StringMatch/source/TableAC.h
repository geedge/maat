/*
 *
 * Copyright (c) 2014
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-03-26
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#ifndef H_ADVANCED_TABLE_AC_CPP_H
#define H_ADVANCED_TABLE_AC_CPP_H

#include "Match.h"
#include "../../rulescan.h"

#define ENABLE_ADVANCE_AC

class CTableAC : public CBaseStringMatch
{
public:
	CTableAC();
    ~CTableAC();	

	virtual int SearchMem(const char *data, unsigned int data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();

private:
	int	*        m_state_table;  
	unsigned int m_state_num;
	int **       m_matched_pats;
	int *        m_supply;
	int          m_no_match_state;
	int          m_initial_state;
};

#endif
