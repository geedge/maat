#include "KRF.h"

#define is_bit_set(tbl, off)    (tbl[off>>3]&(1U<<(off&7)))
#define set_bit(tbl, off)       (tbl[off>>3]|=(1U<<(off&7)))

static const unsigned long long ONE=1;

CKRF::CKRF(unsigned int scale_bits)
{
	m_bits=scale_bits;
	m_hash_table_size=0;
	m_hash_one=NULL;
	m_hash_two=NULL;
#ifdef USE_HASH_THREE
	m_hash_thr=NULL;
#endif
	m_pat_array=NULL;
	m_RT=NULL;
}

CKRF::~CKRF()
{
	if(m_hash_one!=NULL) delete [] m_hash_one;
	if(m_hash_two!=NULL) delete [] m_hash_two;
#ifdef USE_HASH_THREE	
	if(m_hash_thr!=NULL) delete [] m_hash_thr;
#endif
	if(m_pat_array!=NULL) delete [] m_pat_array;
	if(m_RT!=NULL)        aligned_free(m_RT);
}

const unsigned long long B=6364136223846793005LL;

unsigned long long CKRF::Hash(const unsigned char * s, unsigned int n)
{
	unsigned long long h=0;

	for(unsigned int i=0; i<n; i++)
	{
		h=h*B+s[i];
	}

	return h;
}

long long CKRF::Init()
{
	if(m_bits==0) 	/*���û�����ò�������ִ���Զ���Ĳ�������*/
	{
		if     (m_pat_num< 750000) m_bits=23;
		else if(m_pat_num<1500000) m_bits=23;
		else if(m_pat_num<3500000) m_bits=25;
		else if(m_pat_num<7500000) m_bits=26;
		else                       m_bits=28;
	}
	else
	{
		unsigned int bits=1;
		while(m_pat_num>(1U<<bits)) ++bits;
		m_bits+=bits;
	}

	m_msk=((1U<<m_bits)-1);

	long long mem_bytes=0;

	m_hash_table_size=(1U<<24);
	m_RT=(packedRT_t *)aligned_malloc(sizeof(packedRT_t)*((m_hash_table_size>>8)+1), 64);
	FOR(i, (m_hash_table_size>>8))
	{
		FOR(j, 4) m_RT[i].bitmap[j]=0;
	}
	mem_bytes+=sizeof(packedRT_t)*((m_hash_table_size>>8)+1);

	m_hash_one=new unsigned char[1U<<(m_bits-3)];
	memset(m_hash_one, 0, (1U<<(m_bits-3)));
	mem_bytes+=sizeof(char)*(1U<<(m_bits-3));

	m_hash_two=new unsigned char[1U<<(m_bits-3)];
	memset(m_hash_two, 0, (1U<<(m_bits-3)));
	mem_bytes+=sizeof(char)*(1U<<(m_bits-3));

#ifdef USE_HASH_THREE
	m_hash_thr=new unsigned char[1U<<(m_bits-3)];
	memset(m_hash_thr, 0, (1U<<(m_bits-3)));
	mem_bytes+=sizeof(char)*(1U<<(m_bits-3));
#endif

	this->optimal_window();

	unsigned long long Bm=1; // (-B^m) mod p
	FOR(i, m_min_pat_len) Bm*=B;
	Bm=-Bm;
	FOR(c, 256) m_B[c]=m_case_tab[c]*Bm;
	mem_bytes+=sizeof(m_B);

	FOR(i, m_pat_num)
	{
		const unsigned char * F=(const unsigned char *)m_patterns[i].pattern+m_patterns[i].tag;

		unsigned long long h=this->Hash(F, m_min_pat_len);

		unsigned int h1=(unsigned int)(h&m_msk);
		set_bit(m_hash_one, h1);

		unsigned int h2=(unsigned int)((h>>m_bits)&m_msk);
		set_bit(m_hash_two, h2);

#ifdef USE_HASH_THREE
		unsigned int h3=(unsigned int)(h>>(64-m_bits));
		set_bit(m_hash_thr, h3);
#endif

		unsigned int _h=(unsigned int)(h&(m_hash_table_size-1));
		int q=_h&255;
		m_RT[_h>>8].bitmap[q>>6]|=(ONE<<(q&63));
	}

	m_RT[0].A=0;
	FOR(i, (m_hash_table_size>>8))
	{
		m_RT[i].B[0]=0;
		m_RT[i].B[1]=                      (unsigned char)popcnt_u64(m_RT[i].bitmap[0]);
		m_RT[i].B[2]=         m_RT[i].B[1]+(unsigned char)popcnt_u64(m_RT[i].bitmap[1]);
		m_RT[i].B[3]=         m_RT[i].B[2]+(unsigned char)popcnt_u64(m_RT[i].bitmap[2]);
		m_RT[i+1].A=m_RT[i].A+m_RT[i].B[3]+(unsigned int )popcnt_u64(m_RT[i].bitmap[3]);
	}

	int tn=m_RT[(m_hash_table_size>>8)].A;

	m_pat_array=new pattern_t *[tn];
	FOR(i, tn) m_pat_array[i]=NULL;
	mem_bytes+=sizeof(pattern_t *)*tn;

	FOR(k, m_pat_num)
	{
		const unsigned char * F=(const unsigned char *)m_patterns[k].pattern+m_patterns[k].tag;
		unsigned long long h=this->Hash(F, m_min_pat_len);
		unsigned int _h=(unsigned int)(h&(m_hash_table_size-1));
		unsigned idx=rank(_h);
		m_patterns[k].next=m_pat_array[idx];
		m_pat_array[idx]=&(m_patterns[k]);
	}

	return mem_bytes;
}

unsigned int CKRF::rank(unsigned int h)
{
	int p=(h>>8);
	int r=((h&255)>>6);
	int s=(h&63);
	unsigned long long e=m_RT[p].bitmap[r]&((ONE<<s)-1);

	return m_RT[p].A+m_RT[p].B[r]+(unsigned int)popcnt_u64(e);
}

int CKRF::SearchMem(const char *data, size_t data_len, int pos_offset,
					const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
					match_event_handler onEvent, void *context)
{
	if(NULL == data || 0 == data_len || 0 == this->m_pat_num || 
	   data_len < m_min_pat_len) {
		return 0;
	}

	const unsigned char *F = (const unsigned char *)data;
	unsigned int i=0;

	unsigned long long h=0;
	FOR(k, m_min_pat_len) {
		h=h*B+m_case_tab[F[k]];
	}

	while (1) {	
		unsigned int h1=(unsigned int)(h&m_msk);
		if(is_bit_set(m_hash_one, h1)) {
			unsigned int h2=(unsigned int)((h>>m_bits)&m_msk);
			if(is_bit_set(m_hash_two, h2)) {
#ifdef USE_HASH_THREE				
				unsigned int h3=(unsigned int)(h>>(64-m_bits));
				if(is_bit_set(m_hash_thr, h3)) {
#endif
					unsigned int _h=(unsigned int)(h&(m_hash_table_size-1));
					int q=_h&255;
					if (m_RT[_h>>8].bitmap[q>>6] & (ONE<<(q&63))) {
						unsigned idx=rank(_h);

						for(pattern_t *pt = m_pat_array[idx]; pt!=NULL; pt=pt->next) {
							if (i>=pt->tag && i-pt->tag+pt->pattern_len <= data_len) {
								const unsigned char * txt=F+i-pt->tag;
								unsigned int k=0;
								while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

								if (k == pt->pattern_len) {
									int from = (int)(i - pt->tag);
									std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
									if (it != pat_cs.end()) {
										if (1 == it->second.case_sensitive &&
					    					memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
											continue;
										}
									}

									int to = from + pt->pattern_len;
									int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
									if(ret<0) return -1;
								}
							}
						}
					}
#ifdef USE_HASH_THREE
				}
#endif
			}
		}

		if (i + m_min_pat_len >= data_len) break;

		h = h * B + m_case_tab[F[i+m_min_pat_len]] + m_B[F[i]];
		i++;
	}

	return 0;
}
