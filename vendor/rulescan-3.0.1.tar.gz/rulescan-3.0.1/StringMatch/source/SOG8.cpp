/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2010-04-09
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

#include "SOG8.h"

SOG8::SOG8()
{
	m_B=NULL;
	m_hash_table=NULL;
	m_bitmap=NULL;
}

SOG8::~SOG8()
{
	if(m_B!=NULL)
	{
		delete [] m_B;
	}

	if(m_hash_table!=NULL)
	{
		delete [] m_hash_table;
	}

	if(m_bitmap!=NULL)
	{
		delete [] m_bitmap;
	}
}

#define SOG_HASH_CHAR(c)  ((c^(c>>1))&63)

const unsigned char ONE=1;

long long SOG8::Init()
{
	long long mem_bytes=0;

	m_q=4;
	if(m_min_pat_len<m_q)
	{
		m_q=m_min_pat_len;
	}
	if(m_min_pat_len>7+m_q)
	{
		m_min_pat_len=7+m_q;
	}

	m_bits=6;
	m_N=(1u<<(m_bits*m_q));

	m_B=new unsigned char[m_N];
	FOR(k, m_N) m_B[k]=(unsigned char)(-1);
	m_hash_bits=24;

	m_hash_table_size=(1u<<m_hash_bits);
	m_hash_table=new pattern_t *[m_hash_table_size];
	FOR(i, m_hash_table_size) m_hash_table[i]=NULL;

	unsigned int BN=(1u<<18);
	m_bitmap=new unsigned char[BN];
	FOR(i, BN) m_bitmap[i]=0;

	mem_bytes+=(long long)m_N*sizeof(unsigned char)+m_hash_table_size*sizeof(pattern_t *)+BN;

	this->optimal_window();

	unsigned int GSIZE=8*sizeof(unsigned char)/(m_min_pat_len-m_q+1);
	unsigned int BC=(m_pat_num+GSIZE-1)/GSIZE;

	FOR(t, GSIZE)
	{
		int i1=BC*t;
		int i2=min(i1+BC, m_pat_num);

		for(int i=i1; i<i2; i++)
		{
			const unsigned char * F=(const unsigned char *)m_patterns[i].pattern+m_patterns[i].tag;

			FOR(k, m_min_pat_len-m_q+1)
			{
				unsigned int g=0;

				FOR(j, m_q)
				{
					g<<=m_bits;
					g|=SOG_HASH_CHAR(m_case_tab[F[k+j]]);
				}

				m_B[g] &= ~(ONE<<(k+(m_min_pat_len-m_q+1)*t));
			}

			unsigned int h=crc_string(F, m_min_pat_len, m_hash_bits);
			m_patterns[i].next=m_hash_table[h];
			m_hash_table[h]=&(m_patterns[i]);

			unsigned int b=(h^(h>>11))&0x1FFFFF;
			m_bitmap[b>>3]|=(1u<<(b&7));
		}
	}

	m_M=0;
	m_CL=0;
	FOR(t, GSIZE)
	{
		m_M <<=(m_min_pat_len-m_q+1);
		m_M |= (ONE<<(m_min_pat_len-m_q));
		m_CL <<=(m_min_pat_len-m_q+1);
		m_CL |= ((ONE<<(m_min_pat_len-m_q+1))-2);
	}

	return mem_bytes;
}



int SOG8::SearchMem(const char *data, size_t data_len, int pos_offset,
					const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
					match_event_handler onEvent, void *context)
{
	if(NULL == data || 0 == data_len || data_len < m_min_pat_len) {
		return 0;
	}

	const unsigned char * F=(unsigned char *)data;
	unsigned char D=(unsigned char)(-1);
	unsigned int g=0;

	FOR(j, m_q) {
		g <<= m_bits;
		g |= SOG_HASH_CHAR(m_case_tab[F[j]]);
	}

	unsigned int i = m_q;
	while (1) {
		D <<= 1;
		D &= m_CL;
		D |= m_B[g];

		if ((D&m_M) != m_M) {
			unsigned int h=this->crc_string(F+i-m_min_pat_len, m_min_pat_len, m_hash_bits);
			unsigned int b=(h^(h>>11))&0x1FFFFF;

			if (m_bitmap[b>>3] & (1u<<(b&7))) {
				for (const pattern_t * pt=m_hash_table[h]; pt!=NULL; pt=pt->next) {
					if(i>=m_min_pat_len+pt->tag && i-m_min_pat_len-pt->tag+pt->pattern_len <= data_len) {
						const unsigned char * txt=F+i-m_min_pat_len-pt->tag;
						unsigned int k=0;
						while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

						if (k==pt->pattern_len) {
							int from = (int)(i - m_min_pat_len - pt->tag);
							std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
							if (it != pat_cs.end()) {
								if (1 == it->second.case_sensitive &&
					    			memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
									continue;
								}
							}
							
							int to = from + pt->pattern_len;
							int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
							if(ret<0) return -1;
						}
					}
				}
			}
		}

		if (i>= data_len) return 0;

		g <<= m_bits;
		g |= SOG_HASH_CHAR(m_case_tab[F[i]]);
		g &= (m_N-1);
		i++;
	}

	return 0;
}
