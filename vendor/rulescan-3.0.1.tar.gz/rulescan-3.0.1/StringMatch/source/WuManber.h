/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-04-01
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#ifndef H_WU_MANBER_CPP_H
#define H_WU_MANBER_CPP_H

#include "Match.h"
#include "../../rulescan.h"

class CWuManber : public CBaseStringMatch  
{
public:
	CWuManber(unsigned int block_size=0, unsigned int scale_bits=0);
	virtual ~CWuManber();

	virtual int SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();

	unsigned int rank(unsigned int h);

private:
	unsigned int       m_block_size;
	unsigned int       m_max_shift_distance;
	unsigned int       m_hash_bits;

	unsigned char *    m_shift_table;
	unsigned char *    m_bitmap;

	packedRT_t *       m_RT; 
	pattern_t **       m_pat_array;
};

#endif // !defined(H_WU_MANBER_CPP_H)
