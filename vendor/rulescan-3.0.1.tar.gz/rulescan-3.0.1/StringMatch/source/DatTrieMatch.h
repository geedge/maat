/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2010-01-12
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

#ifndef DOUBLE_ARRAY_TRIE_MATCH_WITH_CUT_OFF_BRANCH_CPP_H
#define DOUBLE_ARRAY_TRIE_MATCH_WITH_CUT_OFF_BRANCH_CPP_H

/*********************************************************************
*		String Matching with Double-Array Trie
**********************************************************************/

#include "Match.h"
#include "DatTrie.h"
#include "../../rulescan.h"

#include <map>
using namespace std;

class CDatTrieMatch : public CBaseStringMatch
{
private:
	struct stTrieNode
	{
		map<unsigned char, stTrieNode *> pstChilds;
		int pt;
	};

	typedef map<unsigned char, stTrieNode *>::iterator TMapIter;

	stTrieNode * BuildBlockTrie();	
	int BuildDatTrie(stTrieNode * pstRoot);
	stTrieNode * NewTrieNode();
	int FindBase(stTrieNode * pstWorkNode);

public:
	CDatTrieMatch();
	virtual ~CDatTrieMatch();

	virtual int SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();

private:
	int					m_iNodeCount;
	CDatTrie			m_DatTrie;
};

#endif
