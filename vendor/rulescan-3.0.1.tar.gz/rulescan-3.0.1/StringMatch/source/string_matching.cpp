/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-04-18
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#include "../include/string_matching.h"
#include "Match.h"
#include "Aho_Corasick.h"
#include "TableAC.h"
#include "DatAC.h"
#include "HashTrie.h"
#include "BOM.h"
#include "BDM.h"
#include "HashBOM.h"
#include "DatTrieMatch.h"
#include "WuManber.h"
#include "KRF.h"
#include "SOG8.h"
#include "SOG16.h"
#include "SOG32.h"
#include "SOG64.h"
#include <stdlib.h>

struct group_string_matcher {
	unsigned int m_matcher_num;
	CBaseStringMatch *m_matcher[16];
};

int sort_by_length(const void * a, const void * b)
{
	const pattern_t *lhs = (const pattern_t *)a;
	const pattern_t *rhs = (const pattern_t *)b;

	return (int)lhs->pattern_len - (int)rhs->pattern_len;
}

CBaseStringMatch *new_string_matcher(SMType algo, const algo_param_t *para)
{
	CBaseStringMatch * matcher=NULL;

	switch(algo)
	{
	case SM_AC:
		matcher = new CAhoCorasick;
		break;
	case SM_TAC:
		matcher = new CTableAC;
		break;
	case SM_DAC:
		matcher = new CDatAC;
		break;
	case SM_HashTRIE:
		matcher = new CHashTrie;
		break;
	case SM_BOM:
		matcher = new CBOM;
		break;
	case SM_HashBOM:
		matcher = new CHashBOM;
		break;
	case SM_WM:
		if(para!=NULL) matcher = new CWuManber(para->wm_block_size, para->wm_scale_bits);
		else           matcher = new CWuManber;
		break;
	case SM_DTM:
		matcher = new CDatTrieMatch;
		break;
	case SM_KRF:
		matcher = new CKRF(para!=NULL ? para->krf_scale_bits : 0);
		break;
	case SM_SOG8:
		matcher = new SOG8;
		break;
	case SM_SOG16:
		matcher = new SOG16;
		break;
	case SM_SOG32:
		matcher = new SOG32;
		break;
	case SM_SOG64:
		matcher = new SOG64;
		break;
		case SM_BDM:
		matcher = new CBDM;
		break;
		default :
		matcher = NULL;
		break;
	}

	return matcher;
}

unsigned int grouping_policy(const pattern_t *patterns, unsigned int pat_num, unsigned int *group_len,
							 SMType *group_algo, algo_param_t *group_param)
{
	unsigned int min_pat_len=UINT_MAX;
	FOR(i, pat_num)
	{
		if(patterns[i].pattern_len<min_pat_len)
		{
			min_pat_len=patterns[i].pattern_len;
		}
	}

	unsigned int group_num=0;

	if(min_pat_len>=20) /*���ģʽ�����ܳ���ʹ��WM�㷨*/
	{
		group_num=1;
		group_algo[0]=SM_WM;
		group_param[0].wm_block_size=0;
		group_param[0].wm_scale_bits=0;
	}
	else if(min_pat_len>=6)
	{
		group_num=1;
		group_algo[0]=SM_DTM;
	}
	else
	{
		if(pat_num<5000)
		{
			group_num=1;
			group_algo[0]=SM_DAC;
		}
		else
		{
			group_num=2;
			group_len[0]=6;
			group_algo[0]=SM_DAC;
			group_algo[1]=SM_DTM;
		}
	}

	return group_num;
}

#define MAX_AC_MEM_SIZE 1610612736//ac�㷨����������ڴ棬��ʱ��Ϊ1.5GB
typedef struct _ac_node_t
{
	_ac_node_t* pstNext[MAX_CHAR_SETS];
	_ac_node_t* pstFailure;
	int * MatchedPattern;
}ac_node_t;

//���ݹ���Ԥ������ac�㷨���ڴ�����
long long calc_ac_memsize(const pattern_t * patterns, unsigned int pat_num)
{
	unsigned int N=1;
	for(unsigned int j=1; true; j++)
	{
		set<string_buffer_t> S;

		for(unsigned int k = 0; k < pat_num; k++)
		{
			if(j<=patterns[k].pattern_len)
			{
				string_buffer_t sb;
				sb.str=patterns[k].pattern;
				sb.len=j;
				S.insert(sb);
			}
		}

		if(S.size()==0) break;
		N+=(unsigned int)S.size();
	}

	long long mem_bytes=(long long)N*sizeof(ac_node_t);

	return mem_bytes;
}


/*
���ڵ�ǰ�ķ������������㷨�������ac�㷨����Ԥ��������ac�㷨���ڴ�ռ�ã�����ڴ�ռ�ù��ߣ����С���鳤�ȵ�ֵ�Խ���ac�㷨�ڴ�ռ��
patterns�Ǹ��ݹ��򳤶��������е�
*/
unsigned int change_group_len(const pattern_t *patterns, unsigned int pat_num, unsigned int *group_len, 
							  SMType *group_algo, unsigned int group_num)
{
	if (patterns == NULL || pat_num <= 0) {
		return -1;
	}

	//ֻ��һ��������һ�������㷨����AC��ֱ�ӷ��أ�����Ҫ�޸ķ��鳤�Ȳ���
	if (group_num <= 1 || group_algo[0] != SM_AC) {
		return 1;
	}

	long long ac_mem_size = 9223372036854775807;
	while (1) {
		unsigned int J = 0;
		const pattern_t *group_pat_ptr = patterns;
		unsigned int group_pat_num = 0;					
		while (J < pat_num && patterns[J].pattern_len < group_len[0]) {
			group_pat_num++;
			J++;
		}

		ac_mem_size = calc_ac_memsize(group_pat_ptr, group_pat_num);
		if (ac_mem_size <= MAX_AC_MEM_SIZE) {
			break;
		} else {
			group_len[0] -= 2;//���ac�㷨�ڴ����Ĺ�����ÿ�ΰ�����Ϊ2���𲽼�С���鳤�ȣ��Լ�С�����ac�㷨�Ĺ�������
		}
	}
	
	return 1;
}

struct group_string_matcher *
string_preproc(unsigned int group_num, const unsigned int *group_len,
			   const SMType *group_algo, const algo_param_t *group_param,
			   const pattern_t *patterns, unsigned int n_patterns, 
			   bool case_sensitive, unsigned long long *mem_size)
{
	if(group_num>16 || patterns==NULL || n_patterns==0) return NULL;
	if(group_num>1 && group_len==NULL)   return NULL;
	if(group_num>0 && group_algo==NULL) return NULL;
	if(group_num>0 && group_param==NULL)  return NULL;

	unsigned int  _group_len[15];
	SMType        _group_algo[16];
	algo_param_t _group_param[16];

	if (0 == group_num) {
		group_num = grouping_policy(patterns, n_patterns, _group_len, _group_algo, _group_param);
		if(group_num == 0) return NULL;
	} else {
		if(group_num > 1) copy(group_len, group_len+group_num-1, _group_len);
		copy(group_algo, group_algo+group_num, _group_algo);
		copy(group_param,  group_param+ group_num, _group_param);
	}

	pattern_t *pats = new pattern_t[n_patterns];
	copy(patterns, patterns + n_patterns, pats);
	qsort((void *)pats, n_patterns, sizeof(pattern_t), sort_by_length);

	if (change_group_len(pats, n_patterns, _group_len, _group_algo, group_num) < 0) {
		printf("[%s: %d]: string_preproc() failed!\n",__FILE__,__LINE__);
		return NULL;
	}

	unsigned int J = 0;
	long long mem_bytes = 0;

	struct group_string_matcher *matcher = new struct group_string_matcher;
	matcher->m_matcher_num=0;

	FOR(i, group_num) {
		const pattern_t *group_pat_ptr = pats + J;
		unsigned int group_pat_num = 0;

		if (i == (int)group_num-1) {
			group_pat_num = n_patterns - J;
		} else {			
			while (J < n_patterns && pats[J].pattern_len < _group_len[i]) {
				group_pat_num++;
				J++;
			}
		}

		if(group_pat_num==0) continue;
		
		CBaseStringMatch *pm = new_string_matcher(_group_algo[i], _group_param+i);
		long long ret = pm->InitPatterns(group_pat_ptr, group_pat_num, case_sensitive);
		if (ret < 0) {
			delete pm;
			FOR(k, (int)matcher->m_matcher_num) delete matcher->m_matcher[k];
			delete matcher;
			delete [] pats;
			return NULL;
		}

		matcher->m_matcher[matcher->m_matcher_num++] = pm;
		mem_bytes += ret;
	}

	if (mem_size != NULL) *mem_size = mem_bytes;

	delete [] pats;

	return matcher;
}

int string_search(struct group_string_matcher *matcher, const char *data, size_t data_len,
				  int pos_offset, const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
				  match_event_handler onEvent, void *context)
{
	if (NULL == matcher || NULL == data || 0 == data_len) {
		return -1;
	}
	
	FOR(k, (int)matcher->m_matcher_num) {
		int ret = matcher->m_matcher[k]->SearchMem(data, data_len, pos_offset, pat_cs, onEvent, context);
		if (ret < -1) {
			//error
			return -1;
		}

		if(ret == -1) {
			//first hit
			return 1;
		}
	}

	return 0; /* all hit num */
}

void string_destroy(void *matcher)
{
	if (NULL == matcher) {
		return;
	}

	struct group_string_matcher *gsm = (struct group_string_matcher *)matcher;
	FOR(k, (int)gsm->m_matcher_num) {
		delete gsm->m_matcher[k];
	}
	delete gsm;
}