// ---------------------------------------------------------------------
// This is an implementation of basic Aho_Corasick algorithm using Double Array Trie structure.
//                 by liuyanbing @ 2008.02.28
// ---------------------------------------------------------------------

#ifndef AC_DAT_H
#define AC_DAT_H

#include <map>
using namespace std;

#include "Match.h"
#include "DatTrie.h"
#include "../../rulescan.h"

class CDatAC : public CBaseStringMatch
{
	struct stTrieNode
	{
		map<unsigned char, stTrieNode *> pstChilds;
		int iIndex;
	};

	typedef map<unsigned char, stTrieNode *>::iterator TMapIter;

protected:
	CDatTrie       m_DatTrie;
	int *          m_supply;
	int *          m_matched_ptr;
	int *          m_matched_ids;
	unsigned int * m_bitmap;

public:
	CDatAC();
	~CDatAC();	

	virtual int SearchMem(const char *data, unsigned int data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	//���溯����Ҫ����ʵ�֣��û����ܵ��ô˺���
	virtual long long Init();

	int FindBase(stTrieNode * pstWorkNode);
};

#endif
