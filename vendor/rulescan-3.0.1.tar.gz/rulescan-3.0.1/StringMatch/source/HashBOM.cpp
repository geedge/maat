/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2011-04-21
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

#include "HashBOM.h"

static const unsigned long long ONE=1;

#define is_bit_set(tbl, off)    ( tbl[off>>6] & ( ONE<<(off&63) ) )
#define set_bit(tbl, off)       ( tbl[off>>6] |= ( ONE<<(off&63) ) )

const unsigned int B=22695477;

unsigned int CHashBOM::Hash(const unsigned char * s, unsigned int n)
{
	unsigned int h=0;

	for(int i=n-1; i>=0; --i)
	{	
		h=h*B+s[i];
	}

	return h;
}

CHashBOM::CHashBOM()
{
	m_bitmap=NULL;
	m_RT=NULL;
	m_pat_array=NULL;
}

CHashBOM::~CHashBOM()
{
	if(m_bitmap!=NULL)
	{
		delete [] m_bitmap;
	}

	if(m_RT!=NULL)
	{
		aligned_free(m_RT);
	}

	if(m_pat_array!=NULL)
	{
		delete [] m_pat_array;
	}
}

long long CHashBOM::Init()
{
	if(m_min_pat_len<3) return -1;

	unsigned int num_of_factor=m_min_pat_len*(m_min_pat_len+1)/2*m_pat_num;
	m_bits=(int)(log10((double)num_of_factor)/log10(2.0))+4;

	if(m_bits<6) m_bits=6;

	m_bitmap=new unsigned long long[1U<<(m_bits-6)];
	FOR(i, (1U<<(m_bits-6)))
	{
		m_bitmap[i]=0;
	}

	m_hash_bits=(int)(log10((double)m_pat_num)/log10(2.0))+4;
	if(m_hash_bits<8)
	{
		printf("m_hash_bits<8\n");
		exit(0);
	}

	m_RT=(packedRT_t *)aligned_malloc(sizeof(packedRT_t)*((1U<<(m_hash_bits-8))+1), 64);

	FOR(i, (1U<<(m_hash_bits-8)))
	{
		FOR(j, 4) m_RT[i].bitmap[j]=0;
	}

	this->optimal_window();

	FOR(k, m_pat_num)
	{
		const unsigned char * pb=(const unsigned char *)m_patterns[k].pattern+m_patterns[k].tag;

		for(unsigned int i=0; i<m_min_pat_len; i++)
		{
			for(unsigned int j=i+1; j<=m_min_pat_len; j++)
			{
				unsigned int h=this->Hash(pb+i, j-i);

				unsigned int h1=h&((1U<<m_bits)-1);
				set_bit(m_bitmap, h1);

				if(i==0 && j==m_min_pat_len)
				{
					unsigned int h2=h&((1U<<m_hash_bits)-1);
					int q=h2&255;
					m_RT[h2>>8].bitmap[q>>6]|=(ONE<<(q&63));
				}
			}
		}
	}

	m_RT[0].A=0;
	FOR(i, (1U<<(m_hash_bits-8)))
	{
		m_RT[i].B[0]=0;
		m_RT[i].B[1]=                      popcnt_u64(m_RT[i].bitmap[0]);
		m_RT[i].B[2]=         m_RT[i].B[1]+popcnt_u64(m_RT[i].bitmap[1]);
		m_RT[i].B[3]=         m_RT[i].B[2]+popcnt_u64(m_RT[i].bitmap[2]);
		m_RT[i+1].A=m_RT[i].A+m_RT[i].B[3]+popcnt_u64(m_RT[i].bitmap[3]);
	}

	int tn=m_RT[(1U<<(m_hash_bits-8))].A;

	m_pat_array=new pattern_t *[tn];
	FOR(i, tn) m_pat_array[i]=NULL;

	FOR(k, m_pat_num)
	{
		const unsigned char * pb=(const unsigned char *)m_patterns[k].pattern+m_patterns[k].tag;

		unsigned int h=this->Hash(pb, m_min_pat_len);

		h=h&((1U<<m_hash_bits)-1);

		unsigned idx=rank(h);
		m_patterns[k].next=m_pat_array[idx];
		m_pat_array[idx]=&(m_patterns[k]);
	}

	long long mem_bytes=(1U<<(m_bits-6))*sizeof(char)+(1U<<(m_hash_bits-3))*sizeof(char)*5/4+tn*sizeof(pattern_t *);
	return mem_bytes;
}

unsigned int CHashBOM::rank(unsigned int h)
{
	int p=(h>>8);
	int r=((h&255)>>6);
	int s=(h&63);
	unsigned long long e=m_RT[p].bitmap[r]&((ONE<<s)-1);

	return m_RT[p].A+m_RT[p].B[r]+popcnt_u64(e);
}

int CHashBOM::SearchMem(const char *data, unsigned int data_len, int pos_offset,
						const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						match_event_handler onEvent, void *context)
{
	if (NULL == data || 0 == data_len || 0 == m_pat_num) {
		return 0;
	}

	int avg_reads=0;

	const unsigned char *F = (const unsigned char *)data;
	const unsigned char *L = F + data_len;

	const unsigned char * pb=F;
	const unsigned char * pe=L-this->m_min_pat_len;

	while(pb<=pe) {
		const unsigned char * pTxt=pb+m_min_pat_len-1;

		unsigned int h=0;
		int i=0;
		for( ; i<avg_reads; i++) {
			unsigned char c=m_case_tab[*pTxt];
			h=h*B+c;
			--pTxt;
		}

		while(pTxt>=pb) {
			unsigned char c=m_case_tab[*pTxt];
			h=h*B+c;

			unsigned int h1=h&((1U<<m_bits)-1);
			if((is_bit_set(m_bitmap, h1))==0) break;
			--pTxt;
		}

		if (pTxt>=pb) {
			pb=pTxt+1;
		} else {
			unsigned int h2=h&((1U<<m_hash_bits)-1);
			int q=h2&255;

			if(m_RT[h2>>8].bitmap[q>>6] & (ONE<<(q&63))) {
				unsigned idx=rank(h2);

				for (const pattern_t * pt=m_pat_array[idx]; pt!=NULL; pt=pt->next) {
					if(pb>=F+pt->tag && pb-F-pt->tag+pt->pattern_len <= data_len) {
						const unsigned char * txt=pb-pt->tag;

						unsigned int k=0;
						while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

						if (k == pt->pattern_len) {
							int from = (int)(txt - F);
							std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
							if (it != pat_cs.end()) {
								if (1 == it->second.case_sensitive &&
					    			memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
									continue;
								}
							}

							int to = from + pt->pattern_len;
							int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
							if(ret<0) return -1;
						}
					}
				}
			}
			pb++;
		}
	}

	return 0;
}
