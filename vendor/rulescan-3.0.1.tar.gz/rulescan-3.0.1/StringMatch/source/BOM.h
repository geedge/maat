/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2010-01-12
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

/*********************************************************************
*   Backward Oracle Matching Algorithm (CBOM)
*     - Exact  pattern matching algorithm
*	  - Factor approach
**********************************************************************/
#ifndef H_CBOM_ZX_CPP_H
#define H_CBOM_ZX_CPP_H

#include "Match.h"
#include "../../rulescan.h"

class CBOM : public CBaseStringMatch
{
private:
	typedef struct _stTrieNode{
		struct _stTrieNode* pstNext[MAX_CHAR_SETS];
		struct _stTrieNode* pstFailure;
		pattern_t * pt;
	} stTrieNode;

public:
	CBOM();
	virtual ~CBOM();

	virtual int SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();

	stTrieNode * NewTrieNode();

protected:
	stTrieNode * m_pstRoot;
	vector<stTrieNode *> m_NodeCollector;
};

#endif // H_CBOM_ZX_CPP_H
