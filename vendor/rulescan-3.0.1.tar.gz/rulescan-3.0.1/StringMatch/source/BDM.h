/*
 *
 * Copyright (c) 2006
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:		Tan Jian-long	(tan@software.ict.ac.cn)
 *				Liu Ping		(liuping@software.ict.ac.cn)
 *				Liu Yan-bing	(liuyanbing@software.ict.ac.cn)
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for
 * direct or indirect commercial advantage is not allowed without written
 * permission from the authors.
 *
 */

#ifndef SET_BACKWARD_DAWG_MATCHING_CPP_H
#define SET_BACKWARD_DAWG_MATCHING_CPP_H

/*********************************************************************
 *		Set Backward DAWG Matching Algorithm (SBDM)
 *		Liu Yanbing  2005.6.10
 **********************************************************************/

#include "Match.h"
#include "../../rulescan.h"

class CBDM : public CBaseStringMatch
{
public:
	struct stSuffAutoNode
	{
		pattern_t *pstMatchedPatternList;
		stSuffAutoNode *pstNext[MAX_CHAR_SETS];
		stSuffAutoNode *pstLink;
		int iLen;
		bool bIsTerm;
	};

public:
	CBDM();
	~CBDM();

	virtual int SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);
	virtual long long Init();

	int BuildDAWG();
	int AddLetter(stSuffAutoNode *pstCurrNode, unsigned char ch);

	int NewNode(stSuffAutoNode *pstFath, unsigned char c, stSuffAutoNode **ppstChild);

public:
	stSuffAutoNode *m_pstRoot;
	vector<stSuffAutoNode *> m_astNodeCollector;
};

#endif