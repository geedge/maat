/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2011-04-21
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

#ifndef H_HASH_BOM_CPP_H
#define H_HASH_BOM_CPP_H

#include "Match.h"
#include "../../rulescan.h"

class CHashBOM : public CBaseStringMatch
{
public:
	CHashBOM();
	virtual ~CHashBOM();

	virtual int SearchMem(const char *data, unsigned int data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();
	unsigned int Hash(const unsigned char * s, unsigned int n);
	unsigned int rank(unsigned int h);

protected:
	unsigned int m_bits;
	unsigned long long * m_bitmap;

	unsigned int m_hash_bits;
	packedRT_t * m_RT; 

	pattern_t ** m_pat_array;
};

#endif // H_HASH_BOM_CPP_H
