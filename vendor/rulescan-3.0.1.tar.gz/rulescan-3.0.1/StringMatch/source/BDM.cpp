/*
 *
 * Copyright (c) 2006
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:		Tan Jian-long	(tan@software.ict.ac.cn)
 *				Liu Ping		(liuping@software.ict.ac.cn)
 *				Liu Yan-bing	(liuyanbing@software.ict.ac.cn)
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written 
 * permission from the authors.
 *
 */



#include "BDM.h"

//#define DEBUG_FOR_BDM

CBDM::CBDM()
{
	this->m_pstRoot = NULL;
}

CBDM::~CBDM()
{
	for(int i = 0; i < (int)this->m_astNodeCollector.size(); i++)
	{
		delete this->m_astNodeCollector[i];
	}
	this->m_astNodeCollector.clear();
}

long long CBDM::Init()
{
	if(this->m_pat_num < 1) return -1;

	this->optimal_window();

	//构造逆向的后缀自动机
	this->BuildDAWG();

	long long mem_bytes=0;

	mem_bytes+=(int)this->m_astNodeCollector.size()*sizeof(stSuffAutoNode);

	return mem_bytes;

	return 0;
}

int CBDM::BuildDAWG()
{
	// constrcut pattern trie
	stSuffAutoNode * pstHead;

	this->NewNode(NULL, 0, &pstHead);
	if(pstHead == NULL) return -1;
	pstHead->iLen = -1;

	this->NewNode(pstHead, 0, &m_pstRoot);
	if(this->m_pstRoot == NULL) return -1;
	this->m_pstRoot->bIsTerm = true;
	this->m_pstRoot->iLen = pstHead->iLen+1;
	this->m_pstRoot->pstLink = pstHead;

	for(int c = 0; c < MAX_CHAR_SETS; c++)
	{
		pstHead->pstNext[c] = m_pstRoot;
	}

	vector<stSuffAutoNode *> astTerms;

	for(unsigned int i = 0; i < m_pat_num; i++)
	{
		stSuffAutoNode * pstCurrNode, * pstNextNode;
		const unsigned char * iter, * last;

		pstCurrNode = this->m_pstRoot;
		iter = (unsigned char *)m_patterns[i].pattern+m_patterns[i].tag+this->m_min_pat_len-1;
		last = iter-m_min_pat_len;

		for( ; iter != last; --iter)
		{
			pstNextNode=pstCurrNode->pstNext[*iter];

			if(pstNextNode == NULL)
				break;
			pstCurrNode = pstNextNode;
		}

		for( ; iter != last; --iter)
		{
			this->AddLetter(pstCurrNode, *iter);
			pstCurrNode = pstCurrNode->pstNext[*iter];	
		}

		//insert the ith pattern in the current node's matched pattern list
		this->m_patterns[i].next = pstCurrNode->pstMatchedPatternList;
		pstCurrNode->pstMatchedPatternList = &(this->m_patterns[i]);

		astTerms.push_back(pstCurrNode);

	}

	for(unsigned int i = 0; i<astTerms.size(); i++)
	{
		stSuffAutoNode * pstIter;

		pstIter = astTerms[i];

		while(!pstIter->bIsTerm)
		{
			pstIter->bIsTerm = true;
			pstIter = pstIter->pstLink;
		}
	}
	
#ifdef DEBUG_FOR_BDM
	cout << "suffix automaton nodes: " << (int)this->m_astNodeCollector.size() << endl;
#endif

	return 1;
}

int CBDM::NewNode(stSuffAutoNode * pstFath, unsigned char c, stSuffAutoNode ** ppstChild)
{
	stSuffAutoNode * pstNode;

	pstNode = new stSuffAutoNode;
	*ppstChild = pstNode;
	if(pstNode == NULL) return -1;

	memset(pstNode, 0x00, sizeof(stSuffAutoNode));
	pstNode->bIsTerm = false;
	if(pstFath != NULL)
	{
		pstFath->pstNext[c] = pstNode;
	}
	this->m_astNodeCollector.push_back(pstNode);
	return 1;
}

int CBDM::SearchMem(const char *data, unsigned int data_len, int pos_offset, 
					const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
					match_event_handler onEvent, void *context)
{
	int match_num=0;
	const unsigned char *F = (const unsigned char *)data;

	const unsigned char *curr = F - 1;
	const unsigned char *last = F + data_len - this->m_min_pat_len;

NextGo:	
	if (curr < last) {
		const stSuffAutoNode * pstCurrNode = this->m_pstRoot;
		const unsigned char * iter = curr + this->m_min_pat_len;
		const unsigned char * pcTerm=iter;

		do {	
			if(pstCurrNode->bIsTerm)
				pcTerm = iter;

			unsigned char c = m_case_tab[*iter];
			const stSuffAutoNode *pstNextNode = pstCurrNode->pstNext[c];
			if (pstNextNode == NULL) {
				curr = pcTerm;
				goto NextGo;
			}
			pstCurrNode = pstNextNode;
			--iter;
		}
		while(iter != curr);

		for(const pattern_t * pt=pstCurrNode->pstMatchedPatternList; pt!=NULL; pt=pt->next) {
			const unsigned char * pb=curr+1;

			if(pb>=F+pt->tag && pb-F-pt->tag+pt->pattern_len <= data_len) {
				const unsigned char *txt=pb-pt->tag;
				unsigned int k=0;
				while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

				if (k == pt->pattern_len) {
					int from = int(pb - F);
					std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
					if (it != pat_cs.end()) {
						if (1 == it->second.case_sensitive &&
					    	memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
							continue;
						}
					}
					
					int to = from + (int)pt->pattern_len;
					int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
					match_num++;
					if(ret<0) return -1;
				}
			}
		}

		curr = pcTerm;
		goto NextGo;
	}

	return match_num;
}

int CBDM::AddLetter(stSuffAutoNode * pstCurrNode, unsigned char ch)
{
	stSuffAutoNode * pstChildNode, * pstDown;

	this->NewNode(pstCurrNode, ch, &pstChildNode);
	if(pstChildNode == NULL) return -1;
	pstChildNode->iLen = pstCurrNode->iLen+1;

	pstDown = pstCurrNode->pstLink;

	while(pstDown->pstNext[ch]==NULL)
	{
		pstDown->pstNext[ch] = pstChildNode;
		pstDown = pstDown->pstLink;
	}	

	if(pstDown->pstNext[ch]->iLen != pstDown->iLen+1)
	{
		stSuffAutoNode * pstOldNode, * pstNewNode, * pstIter;

		pstOldNode = pstDown->pstNext[ch];
		
		this->NewNode(pstDown, ch, &pstNewNode);
		if(pstNewNode == NULL) return -1;
		pstNewNode->iLen = pstDown->iLen+1;
		
		pstNewNode->pstLink = pstOldNode->pstLink;
		pstOldNode->pstLink = pstNewNode;

		memcpy(pstNewNode->pstNext, pstOldNode->pstNext, sizeof(pstOldNode->pstNext));

		pstIter = pstDown->pstLink;

		while(pstIter->pstNext[ch] == pstOldNode)
		{
			pstIter->pstNext[ch] = pstNewNode;
			pstIter = pstIter->pstLink;
		}
	}

	pstChildNode->pstLink = pstDown->pstNext[ch];

	return 1;
}
