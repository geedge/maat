/*
 *
 * Copyright (c) 2014
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-03-26
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#include "TableAC.h"

#define COMBI(s, c)   (((unsigned long long)(s)<<8)+(c))  /* 256*s+c */

CTableAC::CTableAC()
{
	m_state_table=NULL;
	m_matched_pats=NULL;
	m_state_num=0;
	m_supply=NULL;
}

CTableAC::~CTableAC()
{
	if(m_state_table!=NULL)
	{
		delete [] m_state_table;
	}

	if(m_matched_pats!=NULL)
	{
		FOR(i, m_no_match_state) delete [] m_matched_pats[i];
		delete [] m_matched_pats;
	}

	if(m_supply!=NULL)
	{
		delete [] m_supply;
	}
}

long long CTableAC::Init()
{
	//Ԥ�����ڴ漰���ʼ��
	m_state_num=count_ac_nodes()+1;
	m_state_table=new int[(unsigned long long)256*m_state_num]; 
	memset(m_state_table, 0xFF, (unsigned long long)256*m_state_num*sizeof(int));
	vector< vector<int> > MatchedPatterns(m_state_num);

	//����Trie��
	FOR(c, MAX_CHAR_SETS) m_state_table[c]=1;

	unsigned int J=2;
	FOR(i, m_pat_num)
	{
		const unsigned char * pb=(const unsigned char *)m_patterns[i].pattern;
		const unsigned char * pe=pb+m_patterns[i].pattern_len;
		int iCurrState=1;

		for( ; pb!=pe; pb++)
		{
			int iNextState=m_state_table[COMBI(iCurrState, *pb)];
			if(iNextState<0) break;
			iCurrState=iNextState;
		}

		for( ; pb!=pe; pb++)
		{
			int iNewState=J++;
			m_state_table[COMBI(iCurrState, *pb)]=iNewState;
			iCurrState=iNewState;
		}

		MatchedPatterns[iCurrState].push_back(i);
	}

	//������ȫ���Զ���
	queue<int> Q;

	m_supply=new int[m_state_num];
	memset(m_supply, 0, m_state_num*sizeof(int));

	for(Q.push(1); !Q.empty(); Q.pop())
	{
		int parent = Q.front();

		FOR(c, MAX_CHAR_SETS)
		{
			int current=m_state_table[COMBI(parent, c)];
			if(current<0) 
			{
#ifdef ENABLE_ADVANCE_AC
				m_state_table[COMBI(parent, c)]=m_state_table[COMBI(m_supply[parent], c)];
#endif
			}
			else
			{
				Q.push(current);

				int down=m_supply[parent];
				while(m_state_table[COMBI(down, c)]<0)
				{
					down=m_supply[down];
				}
				down=m_state_table[COMBI(down, c)];

				m_supply[current]=down;
				copy(MatchedPatterns[down].begin(), MatchedPatterns[down].end(), back_inserter(MatchedPatterns[current]));
			}
		}
	}

	//���н��״̬�ر�ţ��ս��������ǰ��
	vector<unsigned int> id_map(m_state_num);
	unsigned int I=0, F=m_state_num-1;
	FOR(i, m_state_num)
	{
		if(MatchedPatterns[i].size()==0)
		{
			id_map[i]=F--;
		}
		else
		{
			id_map[i]=I++;
		}
	}
	m_no_match_state=I;
	m_initial_state=id_map[1];

	int * _state_table=new int[(unsigned long long)256*m_state_num];
	FOR(i, m_state_num)
	{
		int s=id_map[i];
		FOR(c, MAX_CHAR_SETS)
		{
			int t=m_state_table[COMBI(i, c)];
			if(t!=-1)
			{
				_state_table[COMBI(s, c)]=id_map[t];
			}
			else
			{
				_state_table[COMBI(s, c)]=-1;
			}
		}
	}
	delete [] m_state_table;
	m_state_table=_state_table;

	int * _supply=new int[m_state_num];
	FOR(i, m_state_num)
	{
		_supply[id_map[i]]=id_map[m_supply[i]];
	}
	delete [] m_supply;
	m_supply=_supply;

	m_matched_pats=new int *[m_no_match_state];
	FOR(i, m_state_num)
	{
		unsigned int N=(unsigned int)MatchedPatterns[i].size();
		if(N>0)
		{
			unsigned int j=id_map[i];
			m_matched_pats[j]=new int[1+N];
			m_matched_pats[j][0]=N;
			copy(MatchedPatterns[i].begin(), MatchedPatterns[i].end(), m_matched_pats[j]+1);
		}
	}

	long long mem_bytes=(long long)m_state_num*257*sizeof(int);
	for(int i=0; i<m_no_match_state; ++i)
	{
		mem_bytes+=(int)(m_matched_pats[i][0]+1)*sizeof(int);
	}

	return mem_bytes;
}

int CTableAC::SearchMem(const char *data, size_t data_len, int pos_offset,
						const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						match_event_handler onEvent, void *context)
{
	if (NULL == data || 0 == data_len || 0 == m_state_num) {
		return 0;
	}

	const unsigned char * pb = (const unsigned char*)data;
	const unsigned char * pe = pb + data_len;
	int iCurrState=m_initial_state;

	for ( ; pb!=pe; pb++) {
		unsigned char c = m_case_tab[*pb];

#ifdef ENABLE_ADVANCE_AC
		iCurrState=m_state_table[COMBI(iCurrState, c)];
#else
		int iNextState=m_state_table[COMBI(iCurrState, c)];
		while(iNextState<0)
		{
			iCurrState=m_supply[iCurrState];
			iNextState=m_state_table[COMBI(iCurrState, c)];
		}
		iCurrState=iNextState;
#endif

		if (iCurrState < m_no_match_state) {
			int * p=m_matched_pats[iCurrState];
			FOR(k, p[0]) {
				int h=p[1+k];
				unsigned int pat_id = m_patterns[h].pattern_id;
				int from = (int)((const char *)pb + 1 - this->m_patterns[h].pattern_len - data);
				std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pat_id);
				if (it != pat_cs.end()) {
					if (1 == it->second.case_sensitive &&
					    memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
						continue;
					}
				}
				
				int to = from + m_patterns[h].pattern_len;
				int ret = onEvent(pat_id, pos_offset, from, to, data_len, context);
				if (ret<0) return -1;	// return immediately on hit
			}
		}
	}

	return 0;
}

