/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2010-01-12
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

//#define DEBUG_BOM

#include "BOM.h"

CBOM::CBOM()
{
	m_pstRoot=NULL;
}

CBOM::~CBOM()
{
	FOR(k, (int)m_NodeCollector.size())
	{
		delete m_NodeCollector[k];
	}
}

long long CBOM::Init()
{
	this->optimal_window();

	int iEdgeCount = 0;

	stTrieNode * pstHead=this->NewTrieNode();
	m_pstRoot=this->NewTrieNode();
	FOR(c, MAX_CHAR_SETS) pstHead->pstNext[c]=m_pstRoot;

	//����Trie��
	FOR(k, m_pat_num)
	{
		const unsigned char * pb=(const unsigned char *)m_patterns[k].pattern+m_patterns[k].tag;
		stTrieNode * pstNode=m_pstRoot;

		int i=this->m_min_pat_len-1;

		for( ; i>=0; i--)
		{
			unsigned char c=pb[i];
			stTrieNode * pstNextNode=pstNode->pstNext[c];
			if(pstNextNode==NULL) break;
			pstNode=pstNextNode;
		}

		for( ; i>=0; i--)
		{
			unsigned char c=pb[i];
			pstNode->pstNext[c]=this->NewTrieNode();
			iEdgeCount++;
			pstNode= pstNode->pstNext[c];
		}

		this->m_patterns[k].next=pstNode->pt;
		pstNode->pt=&(m_patterns[k]);
	}

	//����Factor Oracle�Զ���
	queue<stTrieNode *> Queue;

	m_pstRoot->pstFailure=pstHead;

	for(Queue.push(m_pstRoot); !Queue.empty(); Queue.pop())
	{
		const stTrieNode * parent=Queue.front();

		FOR(c, MAX_CHAR_SETS)
		{
			stTrieNode * current=parent->pstNext[c];

			if(current==NULL) continue;

			Queue.push(current);

			stTrieNode * down=parent->pstFailure;
			while(down->pstNext[c]==NULL)
			{
				down->pstNext[c]=current;
				iEdgeCount++;
				down=down->pstFailure;
			}
			current->pstFailure=down->pstNext[c];
		}
	}

#ifdef DEBUG_BOM
	cout << "BOM Oracle Node Count=" << (int)m_NodeCollector.size() << endl;
	cout << "BOM Oracle Edge Count=" << iEdgeCount << endl;
#endif

	long long iMemBytes=(long long)this->m_NodeCollector.size()*sizeof(stTrieNode);
	return iMemBytes;
}

CBOM::stTrieNode * CBOM::NewTrieNode()
{
	stTrieNode * pstNewNode=new stTrieNode;
	this->m_NodeCollector.push_back(pstNewNode);

	FOR(c, MAX_CHAR_SETS)
	{
		pstNewNode->pstNext[c]=NULL;
	}
	pstNewNode->pstFailure=NULL;
	pstNewNode->pt=NULL;

	return pstNewNode;
}

int CBOM::SearchMem(const char *data, size_t data_len, int pos_offset,
					const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
					match_event_handler onEvent, void *context)
{
	if(NULL == data || 0 == data_len || 0 == m_pat_num || NULL == m_pstRoot) {
		return 0;
	}

	const unsigned char *F = (const unsigned char *)data;
	const unsigned char *L = F + data_len;

	const unsigned char *pb = F;
	const unsigned char *pe = L-this->m_min_pat_len;

	while (pb <= pe) {
		const unsigned char *pTxt = pb + m_min_pat_len - 1;
		const stTrieNode *pCurrState=m_pstRoot;

		while (pTxt >= pb) {
			unsigned char c = m_case_tab[*pTxt];
			pCurrState = pCurrState->pstNext[c];
			if (pCurrState == NULL) break;
			--pTxt;
		}

		if (pTxt >= pb) {
			pb = pTxt + 1;
		} else {	
			for (const pattern_t *pt = pCurrState->pt; pt!=NULL; pt=pt->next) {
				if (pb >= F+pt->tag && pb-F-pt->tag+pt->pattern_len <= data_len) {
					const unsigned char *txt=pb-pt->tag;
					unsigned int k=0;
					while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

					if (k == pt->pattern_len) {
						int from = int(pb - F);
						std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
						if (it != pat_cs.end()) {
							if (1 == it->second.case_sensitive &&
					    		memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
								continue;
							}
						}

						int to = from + (int)pt->pattern_len;
						int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
						if(ret<0) return -1;
					}
				}
			}

			pb++;
		}
	}

	return 0;
}
