/*
 *
 * Copyright (c) 2014
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2014-4-19
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#ifndef H_HASH_TRIE_CPP_H
#define H_HASH_TRIE_CPP_H

#include "Match.h"
#include "../../rulescan.h"

class CHashTrie : public CBaseStringMatch
{
public:
	CHashTrie();
	virtual ~CHashTrie();

	virtual int SearchMem(const char *data, unsigned int data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();
	unsigned int rank(unsigned int h);

protected:
	unsigned int         m_H;
	unsigned int         m_max_pat_len;
	unsigned long long * m_B;
	packedRT_t *         m_RT;
	pattern_t **         m_pat_array;
};

#endif // H_HASH_TRIE_CPP_H
