/*
 *
 * Copyright (c) 2014
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2014-4-19
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#include "HashTrie.h"

const unsigned long long ONE=1;

#define is_bit_set(tbl, off)    ( tbl[off>>6] & ( ONE<<(off&63) ) )
#define set_bit(tbl, off)       ( tbl[off>>6] |= ( ONE<<(off&63) ) )

const unsigned int a=22695477;

CHashTrie::CHashTrie()
{
	m_B=NULL;
	m_RT=NULL;
	m_pat_array=NULL;
}

CHashTrie::~CHashTrie()
{
	if(m_B!=NULL)
	{
		delete [] m_B;
	}

	if(m_RT!=NULL)
	{
		aligned_free(m_RT);
	}

	if(m_pat_array!=NULL)
	{
		delete [] m_pat_array;
	}
}

long long CHashTrie::Init()
{
	unsigned int N=1;
	m_max_pat_len=0;

	FOR(i, m_pat_num)
	{
		N+=m_patterns[i].pattern_len;
		if(m_max_pat_len<m_patterns[i].pattern_len)
		{
			m_max_pat_len=m_patterns[i].pattern_len;
		}
	}

	unsigned int w=(int)(log10((double)N)/log10(2.0)+0.5)+4;
	if(w<8) w=8;
	m_H=(1U<<w);

	m_B=new unsigned long long[m_H>>6];
	FOR(i, (m_H>>6)) m_B[i]=0;

	m_RT=(packedRT_t *)aligned_malloc(sizeof(packedRT_t)*((m_H>>8)+1), 64);

	FOR(i, (m_H>>8))
	{
		FOR(j, 4) m_RT[i].bitmap[j]=0;
	}

	FOR(k, m_pat_num)
	{
		const unsigned char * pb=(const unsigned char *)m_patterns[k].pattern;
		unsigned int h=0;

		for(unsigned int j=0; j<m_patterns[k].pattern_len; j++)
		{
			h=a*h+pb[j];
			h&=(m_H-1);

			set_bit(m_B, h);

			if(j==m_patterns[k].pattern_len-1)
			{
				int q=h&255;
				m_RT[h>>8].bitmap[q>>6]|=(ONE<<(q&63));
			}
		}
	}

	m_RT[0].A=0;
	FOR(i, (m_H>>8))
	{
		m_RT[i].B[0]=0;
		m_RT[i].B[1]=                      popcnt_u64(m_RT[i].bitmap[0]);
		m_RT[i].B[2]=         m_RT[i].B[1]+popcnt_u64(m_RT[i].bitmap[1]);
		m_RT[i].B[3]=         m_RT[i].B[2]+popcnt_u64(m_RT[i].bitmap[2]);
		m_RT[i+1].A=m_RT[i].A+m_RT[i].B[3]+popcnt_u64(m_RT[i].bitmap[3]);
	}

	int tn=m_RT[m_H>>8].A;

	m_pat_array=new pattern_t *[tn];
	FOR(i, tn) m_pat_array[i]=NULL;

	FOR(k, m_pat_num)
	{
		const unsigned char * pb=(const unsigned char *)m_patterns[k].pattern;
		unsigned int h=0;

		for(unsigned int j=0; j<m_patterns[k].pattern_len; j++)
		{
			h=a*h+pb[j];
			h&=(m_H-1);
		}

		unsigned idx=rank(h);
		m_patterns[k].next=m_pat_array[idx];
		m_pat_array[idx]=&(m_patterns[k]);
	}

	long long mem_bytes=(m_H>>3)*9/4+tn*sizeof(pattern_t *);
	return mem_bytes;
}

unsigned int CHashTrie::rank(unsigned int h)
{
	int p=(h>>8);
	int r=((h&255)>>6);
	int s=(h&63);
	unsigned long long e=m_RT[p].bitmap[r]&((ONE<<s)-1);

	return m_RT[p].A+m_RT[p].B[r]+popcnt_u64(e);
}

int CHashTrie::SearchMem(const char *data, size_t data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context)
{
	if(NULL == data || 0 == data_len || 0 == m_pat_num) {
		return 0;
	}

	for (unsigned int i=0; i< data_len; i++) {
		unsigned int h=0;
		unsigned int j=0;

		while (j<m_max_pat_len && i+j < data_len) {
			unsigned char c = (unsigned char)data[i+j];
			c = m_case_tab[c];
			h = a * h + c;
			h &= (m_H - 1);

			if(is_bit_set(m_B, h) == 0) break;

			int q = h & 255;
			if (m_RT[h>>8].bitmap[q>>6] & (ONE<<(q&63))) {
				unsigned idx = rank(h);
				for(const pattern_t *pt=m_pat_array[idx]; pt!=NULL; pt=pt->next) {
					if(pt->pattern_len==j+1 && i+pt->pattern_len <= data_len) {
						const unsigned char *txt = (const unsigned char *)data + i;
						unsigned int k = 0;
						while(k<pt->pattern_len && m_case_tab[txt[k]]==(unsigned char)pt->pattern[k]) ++k;

						if (k == pt->pattern_len) {
							int from = (int)i;
							std::tr1::unordered_map<unsigned int, pattern_cs_t>::const_iterator it = pat_cs.find(pt->pattern_id);
							if (it != pat_cs.end()) {
								if (1 == it->second.case_sensitive &&
					    			memcmp(data + from, it->second.pat, it->second.pat_len) != 0) {
									continue;
								}
							}

							int to = from + pt->pattern_len;
							int ret = onEvent(pt->pattern_id, pos_offset, from, to, data_len, context);
							if (ret<0) return -1;
						}
					}
				}
			}
			j++;
		}
	}

	return 0;
}
