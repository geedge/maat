/*
*
* Copyright (c) 2008--2010
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2010-04-09
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/


#ifndef _SOG64_CPP_H_
#define _SOG64_CPP_H_

/*
* reference:
*
@ARTICLE{KST2003,
AUTHOR =       "J. Kytojoki, L. Salmela, J. Tarhio",
TITLE =        "Tuning string matching for huge pattern sets",
JOURNAL =      "Combinatorial Pattern Matching",
PAGES =        "211-224",
VOLUME =       "",
YEAR =         "2003",
}
*/

#include "Match.h"
#include "../../rulescan.h"

class SOG64 : public CBaseStringMatch
{
public:
	SOG64();
	virtual ~SOG64();

	virtual int SearchMem(const char *data, unsigned int data_len, int pos_offset,
						 const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
						 match_event_handler onEvent, void *context);

protected:
	virtual long long Init();

private:
	unsigned int m_q;   // q-gram
	unsigned int m_bits;    // extract m_bits bits from each char

	unsigned long long * m_B; // 32-bit vector
	unsigned int m_N;

	unsigned long long m_CL;
	unsigned long long m_M;

	unsigned int m_hash_bits;
	unsigned int m_hash_table_size;
	pattern_t **	m_hash_table;
	unsigned char * m_bitmap;

};

#endif
