/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-04-18
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST.
 * Usage for direct or indirect commercial advantage is not allowed without
 * written permission from the authors.
 *
 */

#ifndef H_STRING_MATCHING_H
#define H_STRING_MATCHING_H

#include <tr1/unordered_map>

#ifdef __cplusplus
extern "C"
{
#endif

#include "../../rulescan.h"

/* string matching algorithms */
enum SMType {
	SM_AC,		 /* pointer implementation of AC algorithm */
	SM_TAC,		 /* table implementation of AC algorithm */
	SM_DAC,		 /* dual-array implementation of AC algorithm */
	SM_HashTRIE, /* HashTrie algorithm */
	SM_BDM,		 /* BDM algorithm */
	SM_BOM,		 /* BOM algorithm */
	SM_DTM,		 /* DatTrieMatch algorithm */
	SM_HashBOM,	 /* HashBOM algorithm */
	SM_WM,		 /* WM algorithm */
	SM_KRF,		 /* Karp-Rabin-Filter algorithm */
	SM_SOG8,	 /* SOG algorithm(8-bit implementation) */
	SM_SOG16,	 /* SOG algorithm(16-bit implementation) */
	SM_SOG32,	 /* SOG algorithm(32-bit implementation) */
	SM_SOG64,	 /* SOG algorithm(64-bit implementation) */
	SM_COM,		 /* match by length grouping */
	SM_MAX		 /* sum of algorithms */
};

/* pattern string */
typedef struct _pattern_t {
	unsigned int pattern_id;
	unsigned int pattern_len;
	unsigned int tag;		  /* reserved */
	char *pattern;			  /* pattern string pointer */
	struct _pattern_t *next;
} pattern_t;

//cs is short for case_sensitive
typedef struct pattern_cs {
    char case_sensitive;
    char *pat;
    size_t pat_len;
} pattern_cs_t;

typedef struct _algo_param_t {
	unsigned int krf_scale_bits; /* In KRF algo, the size of hash-table is 2^krf of the number of pattern strings; 0 means not set */
	unsigned int wm_block_size;	 /* In WM algo, the character block size; 0 means not set */
	unsigned int wm_scale_bits;	 /* In WM algo, the size of hash-table is 2^wm_scale_bits of the number of character blocks; 0 means not set */
} algo_param_t;

/**
 * @brief pre-process the pattern strings
 * @param group_num[in]: the pattern stirngs are divided into group_num(<= 16) groups, 
 * 				  		 each group has a string matching algorithm; 0 means groups are divided automatically
 * @param group_len[in]: the length of each group
 * @param group_algo[in]: the string matching algorithm of each group 
 * @param group_para[in]: the algorithm parameters of each group 
 * @param patterns[in]: the pattern strings
 * @param pat_num[in]: the number of pattern strings
 * @param case_sensitive[in]: case sensitive or not 
 * @param mem_size[out]: the memory size of the string matching algorithm
 * 
 * @retval: the pointer of automata instance
*/
struct group_string_matcher *
string_preproc(unsigned int group_num, const unsigned int *group_len,
			   const SMType *group_algo, const algo_param_t *group_para,
			   const pattern_t *patterns, unsigned int pat_num, 
			   bool case_sensitive, unsigned long long *mem_size);

/**
 * @brief search the text
 * 
 * @param instance[in]: the pointer of automata instance
 * @param text[in]: the text to be matched
 * @param pCallBackReportFound[in]: the callback function
 * @param pTag[in]: the paramter of the callback function
 * 
 * @retval >= 0: returns the number of hit results
 * 		   < 0:  error
*/
int string_search(struct group_string_matcher *matcher, const char *data, size_t data_len,
				  int pos_offset, const std::tr1::unordered_map<unsigned int, pattern_cs_t> &pat_cs,
				  match_event_handler onEvent, void *context);

/**
 * @brief destroy the automata instance
*/
void string_destroy(void *matcher);

#ifdef __cplusplus
}
#endif

#endif // !defined(H_STRING_MATCHING_H)