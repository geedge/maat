/*
 *
 * Copyright (c) 2008--2010
 * Information Security Research Center (IS), 
 * Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
 * Last modification: 2010-01-12
 *
 * This code is the exclusive and proprietary property of IS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written permission 
 * from the authors.
 *
 */


#ifndef TEST_BASE_CPP_H
#define TEST_BASE_CPP_H

#include "../include/string_matching.h"
#include "SetAlgorithm.h"

#include <vector>
using namespace std;

//一个算法的信息
struct TAlgor
{
	SMType		eAlgorType;		//算法类型
	struct group_string_matcher *pMatcher;		//算法自动�?
	string		sAlgorName;		//算法的名�?
	int			iPattNum;		//关键词的规模
	double		fProcessTime;	//预处理时间，单位：秒(s)
	long long	iMemByte;		//自动机消耗的内存空间，单位：字节(B)
	int			iMatchCnt;		//匹配了多少次
	double		fTextLen;		//缓冲区的总长�?
	double		fHowLong;		//搜索时间，单位：�?s)
};

class CTestBase
{
public:
	//设置字符集大小、保存结果的目录、重复测试的次数和测量的相对误差
	CTestBase(int iSetSize, const char * szResultDir="result", int iReptRunTimes=1);

	//注册一个或一组需要测试的算法
	int AddAlgor(SMType eAlgorType);

	//用关键词文件对算法进行预处理
	int InitSearch(const char * szPattsFile, int pat_type, int iFilterMin, int iFilterMax, algo_param_t para, bool case_sensitive);

	//搜索一段数据文本，可多次调�?
	int SearchMem(const char * pBuff, unsigned int iBuffLen);

	//搜索一个文件，可多次调�?
	int SearchFile(const char * szTextFile);

	//将扫描结果保存到文件
	int WriteResult();

	//将扫描结果显示到终端
	int ShowResult();

	//结束扫描，释放所有的自动�?
	int FinishSearch();

	//关键词匹配回调函�?
	static int fn_CallBack(int iPatternIndex, int iFoundPos,void * pTag);	

	//生成随机的关键词
	static int BuildPatts(int iSetSize, int iPattsNum, int iPattsLen, const char * szPattsFile);

	//生成随机的文�?
	static int BuildText(int iSetSize, int iTextLen, const char * szTextFile);

	//build patterns and text
	int BuildData(int iSetSize, int iPattsNum, int iPattsLen, double hit_rate, int iTextLen, const char * szPattsFile, const char * szTextFile);

	//显示各列的字段名�?
	static void PrintColums();

private:
	int load_patterns_from_file(const char * pat_file, int pat_type, int iFilterMin, int iFilterMax);
	void release_patterns();

	//将算法iAlgor的结果写到文件fp�?
	int WriteResult(FILE* fp, int iAlgor);

private:
	int							m_iSetSize;		//字符集大�?

	vector<pattern_t> m_patterns;
	unsigned int       m_min_pat_len;

	vector<TAlgor>		m_Algor;		//所有已经注册的算法
	string						m_sResultDir;	//保存扫描结果的目�?
	int							m_iReptRunTimes;//重复测试的次�?
	double					m_fHitRate;
};

#endif
