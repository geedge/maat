/*
 *
 * Copyright (c) 2006
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:		Tan Jian-long	(tan@software.ict.ac.cn)
 *				Liu Ping		(liuping@software.ict.ac.cn)
 *				Liu Yan-bing	(liuyanbing@software.ict.ac.cn)
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written 
 * permission from the authors.
 *
 */

// Tool.h: interface for the CTool class.
//

#if !defined(AFX_TOOL_H__12683315_4014_4FBE_BBD7_51438FDD28DA__INCLUDED_)
#define AFX_TOOL_H__12683315_4014_4FBE_BBD7_51438FDD28DA__INCLUDED_

#define LOG_FILE_PATH		"./TestMatch.log"	

#define STOP_CHAR_FILE_NAME  "./stopchar.txt"	//ͣ���ַ���

#include <iterator>
#include <vector>
#include <set>
#include <map>
#include <list>
#include <stack>
#include <queue>
#include <algorithm>
#include <numeric>
#include <string>
#include <iostream>
#include <fstream>
#include <utility>
#include <functional>
using namespace std;
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdarg.h>
#include <limits.h>
#include <assert.h>

#ifndef __linux__
#pragma warning(disable : 4786)
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#include <io.h>
#include <windows.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>
#else	
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/io.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#endif

#ifndef __linux__
#define SNPRINTF	_snprintf
#define VSNPRINTF	_vsnprintf
#else
#define SNPRINTF	snprintf
#define VSNPRINTF	vsnprintf
#endif

#ifndef __linux__
/*************  mutex (use CRITICAL_SECTION in windows) ***************/
#define		THREAD_MUTEX				CRITICAL_SECTION
#define		INITIALIZE_MUTEX(mutex)		InitializeCriticalSection(mutex)
#define		DESTROY_MUTEX				DeleteCriticalSection
#define		LOCK_MUTEX					EnterCriticalSection
#define		UNLOCK_MUTEX				LeaveCriticalSection
/**********************************************************************/
#else
/**************  mutex (use CRITICAL_SECTION in Linux) ***************/
#define		THREAD_MUTEX				pthread_mutex_t
#define		INITIALIZE_MUTEX(mutex)		pthread_mutex_init(mutex, NULL)		
#define		DESTROY_MUTEX				pthread_mutex_destroy
#define     LOCK_MUTEX					pthread_mutex_lock
#define		UNLOCK_MUTEX				pthread_mutex_unlock
/**********************************************************************/
#endif


class CThreadMutex
{
private:
	THREAD_MUTEX m_mutex;
public:
	CThreadMutex()
	{
		INITIALIZE_MUTEX(&m_mutex);
	}
	~CThreadMutex()
	{
		DESTROY_MUTEX(&m_mutex);
	}
	void Lock()
	{
		LOCK_MUTEX(&m_mutex);
	}
	void UnLock()
	{
		UNLOCK_MUTEX(&m_mutex);
	}
};


class CTool  
{
public:
	static void  MilliSecondSleep(int iMilliSeconds);

	static int printf_log(char * format, ...);

	static int Clear_log();

	//����ͣ���ַ�
	static int InitForStopChar();
	static int ClearStopChar(const char *pBuff, int iSize,char * pDest,int * pDestLen);

	//ת��Ϊ0xd0xe0xa0xd0xb0xe0xe0xf����ʽ
	//����ر�֤pCodeStr�Ŀռ�����(4*iSize+1)
	static int FormatBinToEncodeStr(unsigned char * pStr,int iSize,char * pCodeStr);
	static int FormatStr2Normal(char * pStr,unsigned char * pNormal);

	static int BuffRelease(char * buff);
	static int BuffReadAllFile(const char * fn,int * pnum,char * * ppBuff);
	static int LinesRelease(int argc,char * argv[]);
	static int LinesReadFile(const char * fn,int * pReadNumber, char *** pppLines);
	static int LinesWriteFile(const char * fn,int argc, char *argv[]);
	
	//GB2312�ж�
	static bool ischinesechar(char b1, char b2)
	{
		int i1, i2;
		i1 =(unsigned char) b1 ;
		i2 =(unsigned char) b2 ;
		bool ret=false;
		if((i1 >= 0xB0) && (i1 <= 0xF7) && (i2 >= 0xA1) && (i2 <= 0xFE)){
			ret=true;
		};
		return ret;
	}

	static int MakeDir(const char * szDirName);

	typedef int (* FDelegateOfFile)(const char * szFile, void * pParam);

	static int SearchDir(const char * szPath, FDelegateOfFile fn_CallBack, void * pParam);

	static int SplitString(const char * pcBuff, int iBuffLen, char delimiter, vector<string>& sStrings);

	static string CombineString(vector<string>& sStrings, char delimiter);

	static bool IsValidInteger(string& s);

	static bool IsHexLetter(char c);

	//���޷�������IP��ַת��Ϊ���ʮ���Ʊ�ʾ��ʽ
	static string ip_ui2str(unsigned int uiIP);

	//�����ʮ���Ʊ�ʾ��IP��ַת��Ϊ�޷�������
	static unsigned int ip_str2ui(const string & sIP);

	//���޷�������IP��ַת��Ϊ4���ֽ�ucBytes[4]��
	//ucBytes[0..3]����ΪIP��ַ������ֽڡ��θ��ֽڡ��δθ��ֽڡ�����ֽ�
	//��ע�⣺���ܼ򵥵�ȡuiIP���׵�ַ���磺char * patt=(char *)&uiIP
	//��Ϊ�ڲ�ͬ�Ļ����ϴ����ֽ��������
	static int ip_ui2mem(unsigned int uiIP, unsigned char ucBytes[]);

	static char * memdup(const char * buff, int len);

	static long flength(const char * szFile);

	//ת��Ϊ0xdeadbeef����ʽ
	static int hex_encode(const char * in, int n, char * out);
	static int hex_decode(const char * in, int n, char * out);
	static void* aligned_malloc(size_t size, size_t align);
	static void aligned_free(void * aligned_ptr);
};



#endif // !defined(AFX_TOOL_H__12683315_4014_4FBE_BBD7_51438FDD28DA__INCLUDED_)
