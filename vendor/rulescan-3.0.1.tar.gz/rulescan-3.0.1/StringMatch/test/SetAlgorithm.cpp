/*
*
* Copyright (c) 2008--2012
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2011-11-17
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/
#include "SetAlgorithm.h"

static map<SMType, string> g_sAlgorDesc;
static map<string, SMType> g_sAlgorType;

void InitTable()
{
	static bool bIsInit=false;

	if(!bIsInit)
	{
		g_sAlgorDesc.insert(make_pair(SM_AC,                        string("AC")));
		g_sAlgorDesc.insert(make_pair(SM_TAC,                       string("TAC")));
		g_sAlgorDesc.insert(make_pair(SM_DAC,                       string("DAC")));
		g_sAlgorDesc.insert(make_pair(SM_HashTRIE,                  string("HashTRIE")));

		g_sAlgorDesc.insert(make_pair(SM_BDM,                       string("BDM")));
		g_sAlgorDesc.insert(make_pair(SM_BOM,                       string("BOM")));
		g_sAlgorDesc.insert(make_pair(SM_DTM,                       string("DTM")));
		g_sAlgorDesc.insert(make_pair(SM_HashBOM,                   string("HashBOM")));

		g_sAlgorDesc.insert(make_pair(SM_WM,                        string("WM")));

		g_sAlgorDesc.insert(make_pair(SM_SOG8,                      string("SOG8")));
		g_sAlgorDesc.insert(make_pair(SM_SOG16,                     string("SOG16")));
		g_sAlgorDesc.insert(make_pair(SM_SOG32,                     string("SOG32")));
		g_sAlgorDesc.insert(make_pair(SM_SOG64,                     string("SOG64")));

		g_sAlgorDesc.insert(make_pair(SM_KRF,                       string("KRF")));
		g_sAlgorDesc.insert(make_pair(SM_COM,                       string("COM")));
		
		//g_sAlgorDesc.insert(make_pair(SM_BAND_BOM,		string("BandBOM")));
		//g_sAlgorDesc.insert(make_pair(SM_COM_D0,				string("COM_D0")));
		//g_sAlgorDesc.insert(make_pair(SM_COM_D1,				string("COM_D1")));
		//g_sAlgorDesc.insert(make_pair(SM_COM_S0,				string("COM_S0")));
		//g_sAlgorDesc.insert(make_pair(SM_COM_S1,				string("COM_S1")));
		//g_sAlgorDesc.insert(make_pair(SM_GMSM,					string("GMSM")));
		//g_sAlgorDesc.insert(make_pair(SM_IWM,					string("IWM")));
		//g_sAlgorDesc.insert(make_pair(SM_SUFF,					string("SuffTrieMatch")));
		//g_sAlgorDesc.insert(make_pair(SM_KR,						string("KR")));
		//g_sAlgorDesc.insert(make_pair(SM_KRBT,					string("KRBT")));
		//g_sAlgorDesc.insert(make_pair(SM_CKRBT,				string("CKRBT")));

		for(map<SMType, string>::const_iterator pb=g_sAlgorDesc.begin(), pe=g_sAlgorDesc.end();
			pb!=pe;
			++pb)
		{
			g_sAlgorType.insert(make_pair(pb->second, pb->first));
		}

		bIsInit=true;
	}

}

string GetAlgorDesc(SMType eAlgor)
{
	InitTable();
	return (g_sAlgorDesc.find(eAlgor)!=g_sAlgorDesc.end()) ? g_sAlgorDesc[eAlgor] : string("");
}

SMType GetAlgorType(const string& sAlgorName)
{
	InitTable();
	return (g_sAlgorType.find(sAlgorName)!=g_sAlgorType.end()) ? g_sAlgorType[sAlgorName] : SM_MAX;
}
