/*
*
* Copyright (c) 2008--2012
* Information Security Research Center (IS), 
* Institute of Computing Technology, Chinese Academy of Sciences.
* All rights reserved.
*
* Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
* Last modification: 2011-11-17
*
* This code is the exclusive and proprietary property of IS@ICT. Usage for 
* direct or indirect commercial advantage is not allowed without written permission 
* from the authors.
*
*/

#ifndef H_SET_ALGORITHM_CPP_H
#define H_SET_ALGORITHM_CPP_H

#include "../include/string_matching.h"
#include <string>
#include <map>
using namespace std;

//��ȡ�㷨��������Ϣ
string GetAlgorDesc(SMType eAlgor);

//��ȡ�㷨��ö������
SMType GetAlgorType(const string& sAlgorName);

#endif
