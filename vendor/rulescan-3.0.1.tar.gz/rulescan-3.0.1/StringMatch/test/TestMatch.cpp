/*
 *
 * Copyright (c) 2008--2010
 * Information Security Research Center (IS), 
 * Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
 * Last modification: 2010-01-12
 *
 * This code is the exclusive and proprietary property of IS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written permission 
 * from the authors.
 *
 */

#include <iostream>
#include <vector>
#include <set>
#include <string>
#include <fstream>
using namespace std;
#include <stdlib.h>
#include "getopt.h"
#include "TestBase.h"
#include "SetAlgorithm.h"

#define FORN(i, inf, sup, inc)		for(i=inf; i<=sup; i+=inc)

int TestRandom(int iSetSize, int iReptRunTimes, int iTextLen,
int iMinPattLen, int iMaxPattLen, int iPattLenInc, 
int iMinPattNum, int iMaxPattNum, int iPattNumInc, 
double fMinHitRate, double fMaxHitRate, double fHitRateInc, 
const vector<SMType>& Algors, algor_param_t para, bool case_sensitive)
{
	cout << "begin random test--------------------" 	<< endl << endl;

	CTestBase::PrintColums();

	CTestBase RandTest(iSetSize, "result", iReptRunTimes);

	char szTextFile[]="testData.txt";
	char szPattFile[]="keys.txt";
	int iPattLen;
	int iPattNum;
	double fHitRate;
	int ret;

	FORN(iPattLen, iMinPattLen, iMaxPattLen, iPattLenInc)
	{
		FORN(iPattNum, iMinPattNum, iMaxPattNum, iPattNumInc)
		{
			FORN(fHitRate, fMinHitRate, fMaxHitRate, fHitRateInc)
			{
				ret=RandTest.BuildData(iSetSize, iPattNum, iPattLen, fHitRate, iTextLen*1024*1024, szPattFile, szTextFile);
				if(ret<0) continue;

				for(int i = 0; i < (int)Algors.size(); i++)
				{
					RandTest.AddAlgor(Algors[i]);
					int ret=RandTest.InitSearch(szPattFile, 1, iMinPattLen, 1024, para, case_sensitive);
					if(ret<0) continue;
					ret=RandTest.SearchFile(szTextFile);
					if(ret<0) continue;
					RandTest.ShowResult();
					RandTest.WriteResult();
					RandTest.FinishSearch();
				}
			}
			remove(szPattFile);
			remove(szTextFile);
		}	
	}

	cout << "random test finished!" << endl;
	return 1;
}

int TestSearchFile(const char * szPattFile, int pat_type, int iFilterMin, int iFilterMax, const char * szTextFile, const vector<SMType>& Algors, algor_param_t para, bool case_sensitive)
{
	cout << "begin test--------------------"
		<< endl << endl;

	CTestBase::PrintColums();

	CTestBase Test(256, "result");

	for(int i = 0; i < (int)Algors.size(); i++)
	{
		Test.AddAlgor(Algors[i]);
		int ret=Test.InitSearch(szPattFile, pat_type, iFilterMin, iFilterMax, para, case_sensitive);
		if(ret<0) continue;
		ret=Test.SearchFile(szTextFile);
		if(ret<0) continue;
		Test.ShowResult();
		Test.WriteResult();
		Test.FinishSearch();
	}

	cout << "test finished !" << endl;

	return 1;
}

void PrintUsage()
{
	cout << endl << "----------welcome to string matching library!----------" << endl;
	cout << "written by: LIU YANBING (liuyanbing@iie.ac.cn)" << endl;
	cout << "-------------------------------------------------------" << endl << endl;

	cout << "1. usage: " << endl;
	cout << "\t" << "TestMatch -l patt_len -n patt_num -a algorithm_name" << endl;
	cout << "or" << endl;
	cout << "\t" << "TestMatch -p patt_file -t text_file -a algorithm_name" << endl;
	cout << "or" << endl;
	cout << "\t" << "TestMatch -b patt_file -t text_file -a algorithm_name" << endl;
	cout << "or" << endl;
	cout << "\t" << "TestMatch --min-patt-len l1 --max-patt-len l2 --patt-len-inc l3 --min-patt-num n1 --max-patt-num n2 --patt-num-inc n3 --min-hit-rate r1 --max-hit-rate r2 --hit-rate-inc r3 -a algorithm_name" << endl;
	cout << endl;

	cout << "2. options: " << endl;
	cout << "\t" << "-a:                   algorithm to be tested. see reference for supported algorithms." << endl;
	cout << "\t" << "-f:                   ignore patterns whose length are less than filter-len. (default: 3)" << endl;
	cout << "\t" << "-m:                   ignore patterns whose length are greater than filter-len. (default: 1024)" << endl;
	cout << "\t" << "-h:                   help for usage." << endl; 	
	cout << "\t" << "-l:                   pattern length in random test." << endl;
	cout << "\t" << "-n:                   pattern number in random test." << endl;
	cout << "\t" << "-p:                   text-formated pattern file to be searched." << endl;
	cout << "\t" << "-b:                   hex-formated pattern file to be searched." << endl;
	cout << "\t" << "-s:                   character set size in random test. (default: 256)" << endl;
	cout << "\t" << "-t:                   text file to be searched." << endl;
	cout << "\t" << "-r:                   hit rate in random test. (default: 0.1)" << endl;
	cout << "\t" << "-u:                   case insensitive search" << endl;
	cout << "\t" << "--min-patt-len:       lower bound for pattern length in random test." << endl;
	cout << "\t" << "--max-patt-len:       upper bound for pattern length in random test." << endl;
	cout << "\t" << "--patt-len-inc:       increment for pattern length in random test." << endl;
	cout << "\t" << "--min-patt-num:       lower bound for pattern number in random test." << endl;
	cout << "\t" << "--max-patt-num:       upper bound for pattern number in random test." << endl;
	cout << "\t" << "--patt-num-inc:       increment for pattern number in random test." << endl;
	cout << "\t" << "--min-hit-rate:       lower bound for hit rate in random test." << endl;
	cout << "\t" << "--max-hit-rate:       upper bound for hit rate in random test." << endl;
	cout << "\t" << "--hit-rate-inc:       increment for hit rate in random test." << endl;
	cout << "\t" << "--run-times:          repeat run times in random test. (default: 3)" << endl;
	cout << "\t" << "--text-len:           text length in random test. (default: 10MB)" << endl;
	cout << "\t" << "--krf-scale-bits:     scale bits in algorithm KRF" << endl;
	cout << "\t" << "--wm-block-size:      block size in algorithm WM" << endl;
	cout << "\t" << "--wm-scale-bits:      scale bits in algorithm WM" << endl;

	cout << endl;

	cout << "3. supported algorithms: " << endl;
	for(int iAlgor=0; iAlgor<SM_MAX; iAlgor++)
	{
		cout << "\t" << GetAlgorDesc((SMType)iAlgor) << endl;
	}
	cout << endl;
}

int main(int argc, char* argv[])
{
	int ch;
	string sPattFile;
	int pat_type=0;
	string sTextFile;
	int iSetSize=256;
	int iReptRunTimes=3;
	int iMinPattLen=1;
	int iMaxPattLen=1;
	int iPattLenInc=1;
	int iMinPattNum=0;
	int iMaxPattNum=0;
	int iPattNumInc=1000;
	double fMinHitRate=0.1;
	double fMaxHitRate=0.1;
	double fHitRateInc=0.01;
	int iFilterMin=3;
	int iFilterMax=1024;
	int iTextLen=10; //(MB)
	vector<SMType> Algors;
	SMType smAlgor;
	algor_param_t para;
	bool case_sensitive=true;

	para.krf_scale_bits=0;
	para.wm_block_size=0;
	para.wm_scale_bits=0;

#define	LONG_OPT_CHAR	65536
	const struct option LongOptions []={ 
		{"min-patt-len",   1, NULL, LONG_OPT_CHAR+ 0},
		{"max-patt-len",   1, NULL, LONG_OPT_CHAR+ 1},
		{"patt-len-inc",   1, NULL, LONG_OPT_CHAR+ 2},
		{"min-patt-num",   1, NULL, LONG_OPT_CHAR+ 3},
		{"max-patt-num",   1, NULL, LONG_OPT_CHAR+ 4},
		{"patt-num-inc",   1, NULL, LONG_OPT_CHAR+ 5},
		{"min-hit-rate",   1, NULL, LONG_OPT_CHAR+ 6},
		{"max-hit-rate",   1, NULL, LONG_OPT_CHAR+ 7},
		{"hit-rate-inc",   1, NULL, LONG_OPT_CHAR+ 8},
		{"run-times",      1, NULL, LONG_OPT_CHAR+ 9},
		{"text-len",       1, NULL, LONG_OPT_CHAR+10},
		{"krf-scale-bits", 1, NULL, LONG_OPT_CHAR+11},
		{"wm-block-size",  1, NULL, LONG_OPT_CHAR+12},
		{"wm-scale-bits",  1, NULL, LONG_OPT_CHAR+13},
		{NULL, 0, NULL, 0}
	};

	while((ch=getopt_long(argc, argv, "p:b:t:l:n:a:r:s:f:m:uh", LongOptions, NULL))!=-1)
	{
		switch(ch)
		{
		case LONG_OPT_CHAR+0 :
			iMinPattLen=atol(optarg); 
			break;
		case LONG_OPT_CHAR+1 :
			iMaxPattLen=atol(optarg); 
			break;
		case LONG_OPT_CHAR+2 :
			iPattLenInc=atol(optarg); 
			break;
		case LONG_OPT_CHAR+3 :
			iMinPattNum=atol(optarg);
			break;
		case LONG_OPT_CHAR+4 :
			iMaxPattNum=atol(optarg);
			break;
		case LONG_OPT_CHAR+5 :
			iPattNumInc=atol(optarg);
			break;
		case LONG_OPT_CHAR+6 :
			sscanf(optarg, "%lf", &fMinHitRate);
			break;
		case LONG_OPT_CHAR+7 :
			sscanf(optarg, "%lf", &fMaxHitRate);
			break;
		case LONG_OPT_CHAR+8 :
			sscanf(optarg, "%lf", &fHitRateInc);
			break;
		case LONG_OPT_CHAR+9 :
			iReptRunTimes=atol(optarg);
			break;
		case LONG_OPT_CHAR+10 :
			iTextLen=atol(optarg);
			break;
		case LONG_OPT_CHAR+11 :
			para.krf_scale_bits=atoi(optarg);
			break;
		case LONG_OPT_CHAR+12 :
			para.wm_block_size=atoi(optarg);
			break;
		case LONG_OPT_CHAR+13 :
			para.wm_scale_bits=atoi(optarg);
			break;
		case 'p' :
			sPattFile=optarg;
			pat_type=0; //��ͨ�ؼ���
			break;
		case 'b' :
			sPattFile=optarg;
			pat_type=1; //����ؼ���
			break;
		case 't' :
			sTextFile=optarg;
			break;
		case 'l' :
			iMinPattLen=atol(optarg);
			iMaxPattLen=iMinPattLen;
			iPattLenInc=100;
			break;
		case 'n' :
			iMinPattNum=atol(optarg);
			iMaxPattNum=iMinPattNum;
			iPattNumInc=1000;
			break;
		case 'r' :
			sscanf(optarg, "%lf", &fMinHitRate);
			fMaxHitRate=fMinHitRate;
			fHitRateInc=0.1;
			break;
		case 's' :
			iSetSize=atol(optarg);
			break;
		case 'f' :
			iFilterMin=atol(optarg);
			break;
		case 'm' :
			iFilterMax=atol(optarg);
			break;
		case 'a' :
			smAlgor=GetAlgorType(string(optarg));
			if(smAlgor==SM_MAX)
			{
				cout << "invalid algorithm name!" << endl;
				return -1;
			}
			Algors.push_back(smAlgor);
			break;
		case 'u' :
			case_sensitive=false;
			break;
		case 'h' :
		default :
			PrintUsage();
			return -1;
		}
	}


	if(!sPattFile.empty() && !sTextFile.empty() && Algors.size()>0)
	{
		TestSearchFile(sPattFile.c_str(), pat_type, iFilterMin, iFilterMax, sTextFile.c_str(), Algors, para, case_sensitive);
	}
	else if(iSetSize>0 && iMinPattLen>0 && iMinPattNum>0 && Algors.size()>0)
	{
		TestRandom(iSetSize, iReptRunTimes, iTextLen,
			iMinPattLen, iMaxPattLen, iPattLenInc,
			iMinPattNum, iMaxPattNum, iPattNumInc, 
			fMinHitRate, fMaxHitRate, fHitRateInc, 
			Algors, para, case_sensitive);
	}
	else
	{
		PrintUsage();
	}

	return 1;
}
