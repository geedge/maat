/*
 *
 * Copyright (c) 2008--2010
 * Information Security Research Center (IS), 
 * Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Written by: Liu Yanbing    (liuyanbing@software.ict.ac.cn)
 * Last modification: 2010-01-12
 *
 * This code is the exclusive and proprietary property of IS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written permission 
 * from the authors.
 *
 */


#include "TestBase.h"
#include "Tool.h"

//directory delimiter
#ifdef WIN32
#define DIR_DEL "\\"
#else
#define DIR_DEL "/"
#endif

double stdRand()
{
	return rand()/(RAND_MAX+1.0);
}

int Rand(int a, int b)
{
	double r=rand()/(RAND_MAX+1.0);
	return (int)(a+(b-a)*r);
}

int ColWidth[]={16, 12, 16, 16, 16, 16, 16};
const char * ColName[]={"algorithm", "pat_num", "init_time(s)", "memory(MB)", "search_time(s)", "speed(MB/s)", "match_num"};

//设置字符集大小和保存结果的目�?
CTestBase::CTestBase(int iSetSize, const char * szResultDir, int iReptRunTimes)
{
	this->m_iSetSize = iSetSize;

	if(szResultDir!=NULL)
	{
		this->m_sResultDir = szResultDir;
		CTool::MakeDir(szResultDir);
	}
	else
	{
		this->m_sResultDir = ".";
	}

	this->m_iReptRunTimes=iReptRunTimes;
}

//注册一个或一组需要测试的算法
int CTestBase::AddAlgor(SMType eAlgorType)
{
	TAlgor OneAlgor;

	OneAlgor.eAlgorType		= eAlgorType;
	OneAlgor.pMatcher		= NULL;
	OneAlgor.sAlgorName		= GetAlgorDesc(eAlgorType);	
	OneAlgor.iPattNum		= 0;
	OneAlgor.iMemByte		= 0;
	OneAlgor.iMatchCnt		= 0;
	OneAlgor.fTextLen		= 0.0;
	OneAlgor.fHowLong		= 0.0;
	OneAlgor.fProcessTime	= 0.0;

	this->m_Algor.push_back(OneAlgor);

	return 1;
}

//用关键词文件对算法进行预处理
int CTestBase::InitSearch(const char * szPattsFile, int pat_type, int iFilterMin, int iFilterMax, algor_param_t para, bool case_sensitive)
{
	if(szPattsFile==NULL) return -1;

	if(this->load_patterns_from_file(szPattsFile, pat_type, iFilterMin, iFilterMax)<0) return -1;

	//逐个初始化各个自动机
	for(int i = 0; i < (int)this->m_Algor.size(); i++)
	{
		unsigned int  group_num=1;
		unsigned int  group_len[15];
		SMType        group_algor[16];
		algor_param_t group_para[16];

		if(m_Algor[i].eAlgorType==SM_COM) /*ʹ���Զ���ķ������*/
		{
			group_num=0;
		}
		else
		{
			group_algor[0]=m_Algor[i].eAlgorType;
			group_para[0]=para;
		}

		unsigned long long space_used=0;
		clock_t clk = clock();
		m_Algor[i].pMatcher=string_preproc(group_num, group_len, group_algor, group_para, &(m_patterns[0]), (int)m_patterns.size(), case_sensitive, &space_used);
		clk = clock()-clk;

		this->m_Algor[i].fProcessTime = (double)clk/CLOCKS_PER_SEC;
		if(m_Algor[i].pMatcher==NULL)
		{
			printf("%s : %d--InitPatterns error: %s!", __FILE__, __LINE__, m_Algor[i].sAlgorName.c_str());
			return -1;
		}
		this->m_Algor[i].iMemByte = space_used;
		this->m_Algor[i].iPattNum=(int)m_patterns.size();
	}

	this->release_patterns();

	return 1;
}

//搜索一段数据文本，可多次调�?
int CTestBase::SearchMem(const char *pBuff, unsigned int iBuffLen)
{
	for(int i=0, n=(int)this->m_Algor.size(); i<n; i++)
	{
		int iMatchCnt = 0;

		vector<double> fHowLongs;
		double fHowLong;

		int iReptRunTimes=m_iReptRunTimes;

		for(int j=0; j<iReptRunTimes; j++)
		{
			clock_t clk = clock();
			
			string_search(m_Algor[i].pMatcher, pBuff, iBuffLen, &fn_CallBack, &iMatchCnt);

			fHowLong = (clock()-clk)/(double)CLOCKS_PER_SEC;

			fHowLongs.push_back(fHowLong);
		}

		this->m_Algor[i].fHowLong  += accumulate(fHowLongs.begin(), fHowLongs.end(), 0.0)/iReptRunTimes;
		this->m_Algor[i].iMatchCnt += (iMatchCnt/iReptRunTimes);
		this->m_Algor[i].fTextLen  += iBuffLen;
	}

	return 1;
}


//搜索一个文件，可多次调�?
int CTestBase::SearchFile(const char * szTextFile)
{
	if(szTextFile==NULL) return -1;

	FILE * fp=fopen(szTextFile, "rb");
	if(fp==NULL)
	{
		printf("%s : %d--fopen error: %s!", __FILE__, __LINE__, szTextFile);
		return -1;
	}

#define MAX_BLOCK_SIZE 50000000
	char * pBuff = new char[MAX_BLOCK_SIZE];

	while( !feof(fp) )
	{
		unsigned int iBuffLen = (unsigned int)fread(pBuff, 1, MAX_BLOCK_SIZE, fp);
		this->SearchMem(pBuff, iBuffLen);
	}

	delete [] pBuff;
	fclose(fp);

	return 1;
}

//将扫描结果显示到终端
int CTestBase::ShowResult()
{
	for(int i=0, n=(int)this->m_Algor.size(); i<n; i++)
	{
		this->WriteResult(stdout, i);
	}
	return 1;
}

//将扫描结果保存到磁盘
int CTestBase::WriteResult()
{
	for(int i=0, n=(int)this->m_Algor.size(); i<n; i++)
	{
		// 将结果写入文件file_name�?
		char file_name[256];

		string s = this->m_sResultDir + string(DIR_DEL) + this->m_Algor[i].sAlgorName;

		sprintf(file_name, "%s_%d_%d.txt", s.c_str(), m_iSetSize, m_min_pat_len);

		FILE * fp = fopen(file_name, "a");
		this->WriteResult(fp, i);
		fclose(fp);	
	}
	return 1;
}

//结束扫描，释放所有的自动�?
int CTestBase::FinishSearch()
{
	//释放扫描自动�?
	for(int i=0, n=(int)this->m_Algor.size(); i<n; i++)
	{	
		string_destroy(m_Algor[i].pMatcher);
	}
	this->m_Algor.clear();
	return 1;
}

//关键词匹配回调函�?
int CTestBase::fn_CallBack(int iPatternIndex, int iFoundPos, void * pTag)
{
	int * pCnt = (int *)pTag;
	(*pCnt)++;

	//if(*pCnt<5) printf("pid=%d, pos=%d.\n", iPatternIndex, iFoundPos);

	return 1;
}

//将关键词从文件中读到内存
int CTestBase::load_patterns_from_file(const char * pat_file, int pat_type, int iFilterMin, int iFilterMax)
{
	if(pat_file==NULL) return -1;

	FILE * stream=fopen(pat_file, "r");
	if(stream==NULL)
	{
		printf("can't open pattern file : %s!", pat_file);
		return -1;
	}

	m_min_pat_len=INT_MAX;

	while(!feof(stream))
	{
		char line[8092]={0};
		fgets(line, sizeof(line), stream);

		int N=0;
		while(line[N]!='\0')
		{
			if(line[N]=='\r' || line[N]=='\n') break;
			++N;
		}
		line[N]='\0';

		if(N==0) continue;

		pattern_t pt;

		pt.pattern_id=(int)m_patterns.size();

		if(pat_type==0)
		{
			pt.pattern_len=N;
			pt.pattern=CTool::memdup(line, N);
		}
		else
		{
			pt.pattern=new char[N];
			pt.pattern_len=CTool::FormatStr2Normal(line, (unsigned char *)pt.pattern);
		}
		
		if(pt.pattern_len<(unsigned int)iFilterMin || pt.pattern_len>(unsigned int)iFilterMax)
		{
			delete [] pt.pattern;
			continue;
		}

		m_patterns.push_back(pt);

		if(m_min_pat_len>pt.pattern_len)
		{
			m_min_pat_len=pt.pattern_len;
		}
	}

	fclose(stream);

	return 1;
}

void CTestBase::release_patterns()
{
	for(int i=0; i<(int)m_patterns.size(); i++)
	{
		delete [] m_patterns[i].pattern;
	}
	m_patterns.clear();
}

//将算法iAlgor的结果写到文件fp�?
int CTestBase::WriteResult(FILE* fp, int iAlgor)
{
	TAlgor& result = this->m_Algor[iAlgor];

	int j;

	//算法名称
	j=fprintf(fp, "%s", result.sAlgorName.c_str());
	for( ; j<ColWidth[0]; j++) fprintf(fp, " ");

	//关键词规�?
	j=fprintf(fp, "%d", result.iPattNum);
	for( ; j<ColWidth[1]; j++) fprintf(fp, " ");

	//预处理时�?
	j=fprintf(fp, "%5.3f", result.fProcessTime);
	for( ; j<ColWidth[2]; j++) fprintf(fp, " ");

	//内存空间
	j=fprintf(fp, "%5.3f", (double)result.iMemByte/(1<<20));
	for( ; j<ColWidth[3]; j++) fprintf(fp, " ");

	//搜索时间
	j=fprintf(fp, "%5.6f", result.fHowLong);
	for( ; j<ColWidth[4]; j++) fprintf(fp, " ");

	double fSpeed=result.fTextLen / result.fHowLong / (1<<20);
	//搜索速度
	j=fprintf(fp, "%5.3f", fSpeed);
	for( ; j<ColWidth[5]; j++) fprintf(fp, " ");

	//匹配次数
	j=fprintf(fp, "%d", result.iMatchCnt);
	for( ; j<ColWidth[6]; j++) fprintf(fp, " ");

	fprintf(fp, "\n");

	return  1;
}

//显示各列的字段名�?
void CTestBase::PrintColums()
{
	for(int i=0; i<(int)sizeof(ColWidth)/(int)sizeof(int); i++)
	{
		for(int j=printf("%s", ColName[i]); j<ColWidth[i]; j++) printf(" ");
	}
	printf("\n");
}

//生成随机的关键词
int CTestBase::BuildPatts(int iSetSize, int iPattsNum, int iPattsLen, const char * szPattsFile)
{
	assert(szPattsFile!=NULL);

	ofstream fout(szPattsFile);
	vector<string> sPatts(iPattsNum);


	for(int i = 0; i < iPattsNum; i++)
	{
		for(int j = 0; j < iPattsLen; j++)		
		{			
			char c = rand() % iSetSize;
			sPatts[i] += c;
		}
	}

	char pcBuff[4096];

	for(int i = 0; i < iPattsNum; i++)
	{
		CTool::FormatBinToEncodeStr((unsigned char *)sPatts[i].c_str(), (int)sPatts[i].size(), pcBuff);
		fout << pcBuff << "\n";
	}

	return 1;
}

//生成随机的文�?
int CTestBase::BuildText(int iSetSize, int iTextLen, const char * szTextFile)
{
	if(szTextFile==NULL) return -1;

	char * pBuff = new char[iTextLen];

	for(int i = 0; i < iTextLen; i++)
	{
		pBuff[i] = rand() % iSetSize;
	}

	FILE * fp=fopen(szTextFile, "wb");
	if(fp!=NULL) 
	{
		fwrite(pBuff, 1, iTextLen, fp);
		fclose(fp);
	}

	delete [] pBuff;
	return 1;
}

int CTestBase::BuildData(int iSetSize, int iPattsNum, int iPattsLen, double hit_rate, int iTextLen, const char * szPattsFile, const char * szTextFile)
{
	assert(szPattsFile!=NULL);
	assert(szTextFile!=NULL);

	this->m_fHitRate=hit_rate;

	ofstream fout(szPattsFile);
	vector<string> sPatts(iPattsNum);
	int i = 0, j= 0;

	for(i = 0; i < iPattsNum; i++)
	{
		for(j = 0; j < iPattsLen; j++)		
		{			
			char c = rand() % iSetSize;
			sPatts[i] += c;
		}
	}

	char pcBuff[4096];

	for(i = 0; i < iPattsNum; i++)
	{
		CTool::FormatBinToEncodeStr((unsigned char *)sPatts[i].c_str(), (int)sPatts[i].size(), pcBuff);
		fout << pcBuff << "\n";
	}

	char * pBuff = new(nothrow) char[iTextLen];
	if(pBuff==NULL) return -1;

	if(hit_rate>1.0/iPattsLen) hit_rate=1.0/iPattsLen;

	double pr=1/(1/hit_rate+1-iPattsLen);

	i = 0;
	while(i < iTextLen)
	{
		if(stdRand()<pr && i+iPattsLen<=iTextLen)
		{
			int idx=Rand(0, iPattsNum);
			memcpy(pBuff+i, sPatts[idx].c_str(), iPattsLen);
			i+=iPattsLen;
		}
		else
		{
			pBuff[i] = rand() % iSetSize;
			i++;
		}
	}

	FILE * fp=fopen(szTextFile, "wb");
	if(fp!=NULL) 
	{
		fwrite(pBuff, 1, iTextLen, fp);
		fclose(fp);
	}

	delete [] pBuff;

	return 1;
}
