/*
 *
 * Copyright (c) 2006
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:		Tan Jian-long	(tan@software.ict.ac.cn)
 *				Liu Ping		(liuping@software.ict.ac.cn)
 *				Liu Yan-bing	(liuyanbing@software.ict.ac.cn)
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written 
 * permission from the authors.
 *
 */

#include "Tool.h"

int CTool::printf_log(char * format, ...)
{
#define LOG_FILE_MAX_SIZE  10000000

	//判断，如果日值文件的大小大于10M，则重新开始写
	FILE * flog;
	flog=fopen(LOG_FILE_PATH,"rb");	
	int now_size=0;
	if(flog!=NULL) {
		fseek(flog,0,SEEK_END);
		now_size=ftell(flog);
		fclose(flog);
	}
	FILE * fp;
	if(now_size>LOG_FILE_MAX_SIZE){
		//需要重新开始
		fp = fopen(LOG_FILE_PATH, "w+");
	}else{
		//不需要重新开始
		fp = fopen(LOG_FILE_PATH, "a");
	};
	if(fp==NULL) {
		return  -1;
	}

#define MAX_LOG_LINES 1024
	va_list ap;
	char buf[MAX_LOG_LINES];
	va_start(ap, format);
	int ret=VSNPRINTF(buf, MAX_LOG_LINES, format, ap);
	
	if(ret<0 || ret>=MAX_LOG_LINES) {
		return -1;
	}
	va_end(ap);
	time_t cur;
	char buf2[128];
	memset(buf2, 0, 128);
	time(&cur);
	sprintf(buf2, "%s", ctime(&cur));
	buf2[strlen(buf2) - 1] = '\0';
	fprintf(fp, "%s %s\n", buf2, buf);
	fclose(fp);

	return 1;
}

//判断，如果日值文件的大小大于200M，则重新开始写
int CTool::Clear_log()
{	
	FILE * flog;
	flog=fopen(LOG_FILE_PATH,"rb");	
	int now_size=0;
	if(flog!=NULL) {
		fseek(flog,0,SEEK_END);
		now_size=ftell(flog);
		fclose(flog);
	}

	if(now_size>LOG_FILE_MAX_SIZE){
		FILE * fp = fopen(LOG_FILE_PATH, "w+");
		if(fp!=NULL) fclose(fp);
	}
	return 1;
}

int CTool::LinesReadFile(const char *fn, int *pReadNumber, char *** pppLines)
{
	*pReadNumber=0;
	vector<string> mylines;
	FILE * fp;
	fp=fopen(fn,"r");
	if(fp==NULL){
		CTool::printf_log((char *)"\nError:Can not open %s file CTool::LinesReadFile", fn);
		return -1;
	}
	
	while(!feof(fp)){
#define MAX_CHARS_ONE_LINE 2048
		char pcBuf[MAX_CHARS_ONE_LINE];
		memset(pcBuf,0,MAX_CHARS_ONE_LINE);
		fgets(pcBuf,MAX_CHARS_ONE_LINE,fp);
		for(char * p=pcBuf; *p!='\0'; ++p)
		{
			if(*p==0x0A || *p==0x0D) *p='\0';
		}
		if(strlen(pcBuf)>0){
			mylines.push_back(pcBuf);
		};
	}
	fclose(fp);
	
	int  num=0;
	num=(int)mylines.size();
	*pReadNumber=num;
	int i;
	*pppLines=new char *[num+1];
	for(i=0;i<*pReadNumber;i++){
		int ll=(int)mylines[i].size()+1;
		(*pppLines)[i] = new char[ll];
		memset((*pppLines)[i],0,ll);
		strcpy((*pppLines)[i],mylines[i].c_str());
	}
	return 0;
}

int CTool::LinesRelease(int argc, char *argv[])
{
	if(argv==NULL) return -1;
	int i;
	for(i=0;i<argc;i++){
		if(argv[i]!=NULL){
			delete [] argv[i];
		};
	}
	delete [] argv;
	return 1;
	
}
int CTool::LinesWriteFile(const char * fn,int argc, char *argv[])
{
	FILE * fp;
	fp=fopen(fn,"w+");
	if(fp==NULL) return -1;
	int i;
	for(i=0;i<argc;i++){
		fprintf(fp,"%s\n",argv[i]);
	}
	fclose(fp);
	return 1;
}


int CTool::BuffReadAllFile(const char *fn, int *pnum, char **ppBuff)
{
	*pnum=0;
	FILE * fp;
	fp=fopen(fn,"rb");
	if(fp==NULL){
		CTool::printf_log((char *)"\n Error:Can not open %s file CTool::BuffReadAllFile", fn);
		return -1;
	}
	int fl;
	fseek(fp,0,SEEK_END);
	fl=ftell(fp);
	fseek(fp,0,SEEK_SET);
	*ppBuff = new char[fl+1];
	memset(*ppBuff, 0,fl+1);
	fread(*ppBuff,sizeof(char),fl,fp);
	*pnum=fl;
	fclose(fp);
	return *pnum;
}

int CTool::BuffRelease(char *buff)
{
	if(buff==NULL){
		return -1;
	};
	delete [] buff;
	return 1;
}

int CTool::FormatStr2Normal(char *pStr,unsigned  char * pNormal)
{
	if (pNormal == NULL)
		return -1;

	 static unsigned char  mm_code[256];
	 static int  is_init=0;
	 if(is_init==0){
		 int i;
		 for(i=0;i<256;i++){
			 mm_code[i]=0x00;
		 }
		 mm_code[32]=0;
		 for(i='0';i<='9';i++){
			 mm_code[i]=i - '0';
		 };
		 for(i='a';i<='f';i++){
			 mm_code[i]=i - 'a'+10;
		 };
		 for(i='A';i<='F';i++){
			 mm_code[i]=i - 'A'+10;
		 }

		  is_init=1;
	 }
	 unsigned char * pBuff=pNormal;
	 int ll;
	 ll=(int)strlen(pStr);
	 //memset(pBuff,0,ll+1);
	 int i;
	 int j=0;
	 for(i=0;i<ll;i++){
		 if(pStr[i]=='0' && (pStr[i+1]=='X' || pStr[i+1]=='x')){
			i=i+2;
			unsigned char c1,c2;
			c1=(unsigned char)pStr[i];
			c2=(unsigned char)pStr[i+1];
			unsigned char c3;
			c3=mm_code[c1]*16 +mm_code[c2];
			pBuff[j]=c3;
			j++;
			i=i+1;
		 }else{
			pBuff[j]=(unsigned char)pStr[i];
			j++;
		 }
	 }
	 return j;
}

//停用字符标识
bool g_IsStopchar_1[256];  //标识单字节是否为停用字符
bool g_IsStopchar_2[65536];//标识双字节是否为停用字符

int CTool::InitForStopChar()
{
	fill_n(g_IsStopchar_1, 256,   false);
	fill_n(g_IsStopchar_2, 65536, false);

	int num;
	char ** ppLines;

	if(CTool::LinesReadFile(STOP_CHAR_FILE_NAME,&num,&ppLines)<0) return -1;

	for(int i=0; i<num; i++)
	{
		unsigned char * pDest=new unsigned char[256];
		int ll=CTool::FormatStr2Normal(ppLines[i],pDest);
		if(ll==1)
		{
			g_IsStopchar_1[*pDest]=true;
		}
		else if(ll==2)
		{
			g_IsStopchar_2[*(unsigned short *)pDest]=true;
		}
		delete [] pDest;
	}

	CTool::LinesRelease(num,ppLines);
	return 1;
}

int CTool::ClearStopChar(const char *pBuff, int iSize,char * pDest,int * pDestLen)
{
	const char * pTxt=pBuff;
	const char * pEnd=pBuff +iSize;
	char * pOutTxt=pDest;

	while(pTxt<pEnd)
	{
		if(g_IsStopchar_2[*(unsigned short*)pTxt])
		{
			pTxt+=2;
		}
		else if(g_IsStopchar_1[*(unsigned char *)pTxt])
		{
			pTxt++;
		}
		else
		{
			*pOutTxt++=*pTxt++;
		}
	}

	*pDestLen=(int)(pOutTxt-pDest);
	return 1;
}

int CTool::FormatBinToEncodeStr(unsigned char *pStr, int iSize, char *pCodeStr)
{
	char * pb=pCodeStr;
	for(int i=0; i<iSize; i++)
	{
		unsigned char k1=*pStr;
		if(k1<16)
		{
			sprintf(pCodeStr, "0x0%x", k1);
		}
		else
		{
			sprintf(pCodeStr, "0x%x", k1);
		}
		pStr++;
		pCodeStr+=4;
	}
	*pCodeStr=0;

	return (int)(pCodeStr-pb);
}


void CTool::MilliSecondSleep(int iMilliSeconds)
{
#ifdef WIN32
	    Sleep(iMilliSeconds);
#else
		usleep(iMilliSeconds*1000);
#endif
}

int CTool::MakeDir(const char * szDirName)
{
	char szCommand[256];

#ifdef _WIN32
	sprintf(szCommand, "del /Q %s", szDirName);
#else
	sprintf(szCommand, "rm -rf %s", szDirName);
#endif
	system(szCommand);

	sprintf(szCommand, "mkdir %s", szDirName);
	system(szCommand);
	return 1;
}

#ifdef WIN32
#include <io.h>
#include <direct.h>
#else
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string>
#endif

int CTool::SearchDir(const char * szPath, FDelegateOfFile fn_CallBack, void * pParam) 
#ifdef WIN32
{
	struct _finddata_t fAttr;
	long hFile;

	string s = string(szPath) + "\\*.*";

	hFile = _findfirst(s.c_str(), &fAttr);
	if(hFile != -1)
	{
		do
		{
			if(strcmp(fAttr.name, ".") != 0 && strcmp(fAttr.name, "..") != 0)
			{
				string sFile = string(szPath) + "\\" + fAttr.name;

				if( fAttr.attrib & _A_SUBDIR )
				{
					
					SearchDir(sFile.c_str(), fn_CallBack, pParam);
				}
				else
				{
					if(fn_CallBack != NULL)
					{
						(*fn_CallBack)(sFile.c_str(), pParam);
					}
				}
			}
		}
		while(_findnext(hFile, &fAttr) != -1);

		_findclose(hFile);
	}
	return 1;
}

#else

{
	DIR *dir;
	struct dirent *s_dir;
	struct stat file_stat;

	dir=opendir(szPath);
	if(dir==NULL)
	{
		return -1;
	}

	while ((s_dir=readdir(dir))!=NULL) 
	{
		if((strcmp(s_dir->d_name,".")==0)||(strcmp(s_dir->d_name,"..")==0)) continue;

		std::string sCurrFile = string(szPath) + "/" + s_dir->d_name;

		stat(sCurrFile.c_str(), &file_stat);

		if(S_ISDIR(file_stat.st_mode))
		{
            		SearchDir(sCurrFile.c_str(), fn_CallBack, pParam);
		}
		else
		{
           		if(fn_CallBack != NULL)
			{
                    		fn_CallBack(sCurrFile.c_str(), pParam);
			}
		}
	}

	if( closedir(dir) < 0)
	{
		return -1;
	}

	return 1;
}

#endif

int CTool::SplitString(const char * pcBuff, int iBuffLen, char delimiter, vector<string>& sStrings)
{
	const char * pcFirst, * pcLast, * pcIter;
	string s;

	pcFirst = pcBuff;
	pcLast  = pcBuff + iBuffLen;
	sStrings.clear();
	s = "";

	for(pcIter = pcFirst; pcIter != pcLast+1; pcIter++)
	{
		if(pcIter==pcLast || *pcIter==delimiter)
		{
			sStrings.push_back(s);
			s = "";
		}
		else
		{
			s += *pcIter;
		}
	}
	return 1;
}

string CTool::CombineString(vector<string>& sStrings, char delimiter)
{
	string sOut = "";
	if(sStrings.size()>=1)
	{
		sOut = sStrings[0];
		for(int z=1; z < (int)sStrings.size(); z++)
		{
			sOut += "\t";
			sOut += sStrings[z];
		}
	}
	return sOut;
}

bool CTool::IsValidInteger(string& s)
{
	basic_string<char>::iterator sIter, sBegin, sEnd;

	sBegin = s.begin();
	sEnd = s.end();

	for(sIter = sBegin; sIter != sEnd; ++sIter)
	{
		if( (*sIter != '-') && (*sIter < '0' || *sIter > '9') )
			return false;
	}
	return true;
}

bool CTool::IsHexLetter(char c)
{
	return (c >= '0' && c<= '9') || (c >= 'A' && c<= 'F') || (c >= 'a' && c<= 'f');
}

string CTool::ip_ui2str(unsigned int uiIP)
{
	unsigned char ucBytes[4];
	for(int k=0; k<4; k++)
	{
		ucBytes[k] = (unsigned char)(uiIP % 256);
		uiIP /= 256;
	}
	char buff[32];
	sprintf(buff, "%d.%d.%d.%d", ucBytes[3], ucBytes[2], ucBytes[1], ucBytes[0]);
	return string(buff);
}

unsigned int CTool::ip_str2ui(const string & sIP)
{
	vector<string> sStrings;
	CTool::SplitString(sIP.c_str(), (int)sIP.length(), '.', sStrings);
	if(sStrings.size() != 4) return 0;

	unsigned int uiIP = 0;
	for(int i=0; i<(int)sStrings.size(); i++)
	{
		uiIP = (uiIP<<8) + atoi(sStrings[i].c_str());
	}

	return uiIP;
}

int CTool::ip_ui2mem(unsigned int uiIP, unsigned char * ucBytes)
{
	if(ucBytes==NULL) return -1;
	unsigned char * ps=ucBytes+3;
	for(int i=0; i<4; i++)
	{
		*ps-- = (unsigned char)(uiIP%256);
		uiIP >>= 8;
	}
	return 1;
}
char * CTool::memdup(const char * buff, int len)
{
	if (buff==NULL || len<0) return NULL;
	char * newBuff=new char[len+1];
	memset(newBuff, 0x00, len+1);
	memcpy(newBuff, buff, len);
	return newBuff;
}

long CTool::flength(const char * szFile)
{
	FILE * fp=fopen(szFile, "rb");
	if(fp==NULL) return -1;
	fseek(fp, 0, SEEK_SET);
	int iFileLen=ftell(fp);
	fclose(fp);
	return iFileLen;
}

const char * char_map="0123456789abcdef";

int CTool::hex_encode(const char * in, int n, char * out)
{
	out[0]='0';
	out[1]='x';
	for(int i=0; i<n; i++)
	{
		unsigned char c=in[i];
		out[2*i+2]=char_map[c>>4];
		out[2*i+3]=char_map[c&15];
	}
	return 2*n+2;
}

int CTool::hex_decode(const char * in, int n, char * out)
{
	if(in[0]!='0' || (in[1]!='x' && in[1]!='X')) return -1;

	unsigned char c1, c2, d1, d2;

	int L=(n-2)/2;

	for(int i=0; i<L; i++)
	{
		c1=in[2*i+2];
		if(c1>='0' && c1<='9')
		{
			d1=c1-'0';
		}
		else if(c1>='a' && c1<='f')
		{
			d1=c1-'a'+10;
		}
		else if(c1>='A' && c1<='F')
		{
			d1=c1-'A'+10;
		}
		else
		{
			return -1;
		}

		c2=in[2*i+3];
		if(c2>='0' && c2<='9')
		{
			d2=c2-'0';
		}
		else if(c2>='a' && c2<='f')
		{
			d2=c2-'a'+10;
		}
		else if(c2>='A' && c2<='F')
		{
			d2=c2-'A'+10;
		}
		else
		{
			return -1;
		}
		
		out[i]=(char)((d1<<4)+d2);
	}

	return L;
}


void* CTool::aligned_malloc(size_t size, size_t align)
{
	void * malloc_ptr;
	void * aligned_ptr;

	/* Error if align is not a power of two.  */
	if (align & (align - 1))
	{
		return ((void*) 0);
	}

	if (size == 0)
	{
		return ((void *) 0);
	}

	malloc_ptr = malloc (sizeof(void *) + align + size);
	if (!malloc_ptr)
	{
		return ((void *) 0);
	}

	aligned_ptr = (void *) (((size_t)malloc_ptr + sizeof(void *) + align-1) & ~(align-1));
  
	((void **) aligned_ptr) [-1] = malloc_ptr;

	return aligned_ptr;
}

void CTool::aligned_free(void * aligned_ptr)
{
	if (aligned_ptr)
	{
		free (((void **) aligned_ptr) [-1]);
	}
}

