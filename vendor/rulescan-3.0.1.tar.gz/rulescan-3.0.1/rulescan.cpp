/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-04-18
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#include <iostream>
#include <vector>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>

#include "pcre.h"
#include "rulescan.h"
#include "regexlib/source/cstring.h"
#include "regexlib/source/md5.h"
#include "string_matching.h"
#include "regex_matching.h"

using namespace std;
const size_t default_cache_size = 128;

enum rs_db_type {
    RS_DB_TYPE_LITERAL = 1,
    RS_DB_TYPE_REGEX
};

struct rs_database {
    enum rs_db_type type;
    union {
        struct group_string_matcher *gs_matcher;
        struct dfa_matcher *dfa_matcher;
    };
    size_t n_pattern_ids;
    long long *pattern_ids;
    std::tr1::unordered_map<unsigned int, pattern_cs_t> pat_cs; //  <pattern_id, pattern_cs_t>
};

struct rs_stream {
    const rs_database_t *db;
    int thread_id;
    size_t cache_size; /* cross cache size */
    size_t cache_len;  /* already cached data len <= cache_size */
    char *cache;
    int offset;        /* stream offset */
};

static void set_group_param(int keys_num, int *group_num, unsigned int *group_len,
                            SMType *group_algo, algo_param_t *group_param)
{
	*group_num = 2;
	group_algo[0] = SM_AC;
	group_algo[1] = SM_KRF;

	if (keys_num <= 750000) {
		group_len[0] = 6;
		group_param[1].krf_scale_bits = 5;
	} else if (keys_num <= 1500000) {
		group_len[0] = 6;
		group_param[1].krf_scale_bits = 4;
	} else if (keys_num <= 3500000) {
		group_len[0] = 6;
		group_param[1].krf_scale_bits = 3;
	} else if (keys_num <= 7500000) {
		group_len[0] = 6;
		group_param[1].krf_scale_bits = 3;
	} else {
		group_len[0] = 6;
		group_param[1].krf_scale_bits = 5;
	}
}

int rs_compile_lit(struct scan_pattern *pats, size_t n_pats, rs_database_t **db)
{
    if (NULL == pats || 0 == n_pats || NULL == db) {
        return -1;
    }

    vector<pattern_t> patterns(n_pats);
    bool case_sensitive = true;
    struct rs_database *database = new rs_database;

    for (size_t i = 0; i < n_pats; i++) {
        patterns[i].pattern_id = pats[i].id;
        patterns[i].pattern = pats[i].pattern;
        patterns[i].pattern_len = pats[i].pattern_len;
        if (0 == pats[i].case_sensitive) {
            case_sensitive = false;
        }

        pattern_cs_t cs;
        cs.case_sensitive = pats[i].case_sensitive;
        cs.pat_len = pats[i].pattern_len;
        cs.pat = new char[cs.pat_len + 1];
        memcpy(cs.pat, pats[i].pattern, pats[i].pattern_len);
        std::pair<unsigned int, pattern_cs_t> pair(pats[i].id, cs);
        database->pat_cs.insert(pair);
    }

    unsigned int group_len[15];
    SMType group_algo[16];
    algo_param_t group_param[16];
    int group_num = 0;

    set_group_param((int)patterns.size(), &group_num, group_len, group_algo, group_param);
    if (group_num < 0) {
        delete database;
        return -1;
    }

    unsigned long long mem_size = 0;
    struct group_string_matcher *matcher = string_preproc(group_num, group_len, group_algo, group_param,
                                                          &(patterns[0]), n_pats, case_sensitive, &mem_size);
    if (NULL == matcher) {
        delete database;
        return -1;
    }

    database->type = RS_DB_TYPE_LITERAL;
    database->gs_matcher = matcher;
    database->pattern_ids = NULL;
    database->n_pattern_ids = 0;
    *db = database;

    return 0;
}

static void remove_rulescan_tempfile(const char *reg_file_name)
{
	cstring tempfile_name;
	remove(reg_file_name);

	tempfile_name = cstring(reg_file_name) + cstring(".ext");
	remove(tempfile_name.c_str());

#ifndef RULESCAN_LOAD_DFA_FROM_FILE
 	tempfile_name = cstring(reg_file_name) + cstring(".ext") + cstring(".dfa");
 	remove(tempfile_name.c_str());
#endif
}

static const char *charmap = "0123456789abcdef";
int rs_compile_regex(struct scan_pattern *pats, size_t n_pats, size_t thread_num,
                     rs_database_t **db, size_t *n_failed_pats)
{
    if (NULL == pats || 0 == n_pats || NULL == db) {
        return -1;
    }

    /* The underlying regular expression library needs to pass in rules in the form of files,
        calculate the md5 values of all rules as file names to avoid conflicts */
    size_t i = 0;
    unsigned char md5[16];
    MD5_CTX ctx;
    bool case_sensitive = true;
    long long *pat_ids = new long long[n_pats];
    struct rs_database *database = new rs_database;
    
	MD5Init(&ctx);

    for (i = 0; i < n_pats; i++) {
        pat_ids[i] = pats[i].id;
        MD5Update(&ctx, (unsigned char *)pats[i].pattern, pats[i].pattern_len);
        /* As long as one pattern is case insensitive, the set of patterns is case insensitive */
        if (0 == pats[i].case_sensitive) {
            case_sensitive = false;
        }
    }
    MD5Final(md5, &ctx);

    /* Convert md5 to hex string as rule filename */
    char reg_file_name[512]="./rulescan_tmp/";
	int n = strlen(reg_file_name);

    if ((access(reg_file_name, F_OK)) < 0) {
		if ((mkdir(reg_file_name, 0777)) < 0) {
            delete [] pat_ids;
            delete database;
			return -1;
		}
	}

	for(i = 0; i < 16; i++) {
		unsigned char c = md5[i];
		reg_file_name[2 * i + n ] = charmap[c >> 4];
		reg_file_name[2 * i + 1 + n] = charmap[c & 15];
	}

	const char suffix_name[100] = ".regex";
	strcpy(reg_file_name + 32 + n, suffix_name);

	FILE *fp = fopen((const char*)&reg_file_name, "wb");	
	if(fp == NULL) {
        delete [] pat_ids;
        delete database;
        return -1;
    }

	for (i = 0 ; i < n_pats; i++) {
        /* regexlib requires regex expr id > 0, so i = 1,2,... */
		fprintf(fp, "%zu\t%s\n", i + 1, pats[i].pattern);
	}

	fclose(fp);

    unsigned int failed_ids = 0;
    struct dfa_matcher *matcher = regex_preprocessing(reg_file_name, thread_num, 
                                                      case_sensitive, (1U<<22),
                                                      &failed_ids, 1);
	remove_rulescan_tempfile(reg_file_name);

	if (NULL == matcher) {
        delete [] pat_ids;
        delete database;
		return -1;
	} else {
		*n_failed_pats = failed_ids;
	}

    
    database->type = RS_DB_TYPE_REGEX;
    database->dfa_matcher = matcher;
    database->pattern_ids = pat_ids;
    database->n_pattern_ids = n_pats;
    
    *db = database;

    return 0;
}

void rs_free_database(rs_database_t *db)
{
    if (NULL == db) {
        return;
    }

    if (db->type == RS_DB_TYPE_LITERAL) {
        if (db->gs_matcher != NULL) {
            string_destroy(db->gs_matcher);
            db->gs_matcher = NULL;
        }
    } else {
        if (db->dfa_matcher != NULL) {
            regex_destroy(db->dfa_matcher);
            db->dfa_matcher = NULL;
        }
    }

    if (db->pattern_ids != NULL) {
        delete [] db->pattern_ids;
        db->pattern_ids = NULL;
    }

    for (std::tr1::unordered_map<unsigned int, pattern_cs_t>::iterator it = db->pat_cs.begin(); it != db->pat_cs.end(); ++it) {
        if (it->second.pat != NULL) {
            delete [] it->second.pat;
            it->second.pat = NULL;
        }
    }

    delete db;
}

int rs_verify_regex(const char *regex_expr)
{
    const char *errptr = NULL;
	int erroffset = 0;
	pcre *handle = pcre_compile(regex_expr, PCRE_ANCHORED|PCRE_DOTALL|PCRE_DOLLAR_ENDONLY, 
                                &errptr, &erroffset, NULL);
    if (NULL == handle) {
        return 0;
    } else {
        pcre_free(handle);
        return 1;
    }
}

int rs_scan(const rs_database_t *db, int thread_id, const char *data, size_t data_len,
            int pos_offset, match_event_handler onEvent, void *context)
{
    if (NULL == db || NULL == data || 0 == data_len) {
        return -1;
    }

    if (db->type == RS_DB_TYPE_LITERAL) {
        return string_search(db->gs_matcher, data, data_len, pos_offset,
                             db->pat_cs, onEvent, context);
    } else {
        return regex_searching(db->dfa_matcher, db->pattern_ids, db->n_pattern_ids, thread_id,
                               data, data_len, pos_offset, onEvent, context);
    }
}

rs_stream_t *rs_open_stream(const rs_database_t *db, int thread_id, size_t cache_size)
{
    if (NULL == db || thread_id < 0) {
        return NULL;
    }

    struct rs_stream *rs_stream = new struct rs_stream;
    rs_stream->db = db;
    rs_stream->thread_id = thread_id;

    if (0 == cache_size) {
        rs_stream->cache_size = default_cache_size;
    } else {
        rs_stream->cache_size = cache_size;
    }

    rs_stream->cache = new char[rs_stream->cache_size];
    rs_stream->cache_len = 0;
    rs_stream->offset = 0;

    return rs_stream;
}

void rs_close_stream(rs_stream_t *stream)
{
    if (NULL == stream) {
        return;
    }

    if (stream->cache != NULL) {
        delete [] stream->cache;
        stream->cache = NULL;
    }

    delete stream;
}

size_t populate_scan_buff(char *scan_buff, size_t scan_buff_size, rs_stream_t *stream,
                          const char *data, size_t data_len)
{
    size_t scan_data_len = 0;

    /* cached some scan_data from the previous scan */
    if (stream->cache_len > 0) {
        memcpy(scan_buff, stream->cache, stream->cache_len);
        memcpy(scan_buff + stream->cache_len, data, data_len);
        scan_data_len = stream->cache_len + data_len;
    } else {
        memcpy(scan_buff, data, data_len);
        scan_data_len = data_len;
    }

    return scan_data_len;
}

void revise_cross_cache(rs_stream_t *stream, const char *data, size_t data_len)
{
    size_t avail_cache_len = stream->cache_size - stream->cache_len;

    if (data_len <= avail_cache_len) {
        memcpy(stream->cache + stream->cache_len, data, data_len);
        stream->cache_len += data_len;
    } else if (data_len > avail_cache_len && data_len <= stream->cache_size) {
        size_t forward_offset = stream->cache_len + data_len - stream->cache_size;
        size_t to_copy_size = stream->cache_size - data_len;
        memmove(stream->cache, stream->cache + forward_offset, to_copy_size);
        memcpy(stream->cache + to_copy_size, data, data_len);
        stream->cache_len = stream->cache_size;
        stream->offset += forward_offset;
    } else {
        /* data_len > stream->cache_size */
        memcpy(stream->cache, (data + data_len - stream->cache_size), stream->cache_size);
        stream->cache_len = stream->cache_size;
        stream->offset += (data_len - avail_cache_len);
    }
}

int stream_search(rs_stream_t *stream, const char *data, size_t data_len,
                  match_event_handler onEvent, void *context)
{   
    const rs_database_t *db = stream->db;
    if (NULL == db) {
        return -1;
    }

    /* scan buffer should have enough memory */
    size_t scan_buff_size = data_len + stream->cache_size;
    int stream_offset = stream->offset;
    char *scan_buff = new char[scan_buff_size];
    size_t scan_buff_len = populate_scan_buff(scan_buff, scan_buff_size,
                                              stream, data, data_len);
    revise_cross_cache(stream, data, data_len);

    int ret = rs_scan(stream->db, stream->thread_id, scan_buff, scan_buff_len,
                      stream_offset, onEvent, context);
    delete [] scan_buff;
    scan_buff = NULL;

    return ret;
}

int rs_scan_stream(rs_stream_t *stream, const char *data, size_t data_len,
                   match_event_handler onEvent, void *context)
{
    if (NULL == stream || NULL == data || 0 == data_len ||
        0 == stream->cache_size) {
        return -1;
    }

    
    return stream_search(stream, data, data_len, onEvent, context);
}
