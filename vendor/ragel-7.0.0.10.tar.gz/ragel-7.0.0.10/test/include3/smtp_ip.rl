%%{
  machine smtp_ip;

}%%
