%%{
  machine smtp_whitespace;

}%%
