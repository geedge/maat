#ifndef TOOLS_H
#define TOOLS_H

#include <stdint.h>
#include "flag_matcher.h"

void new_case(const char *file_path, uint32_t n_case);

int read_case(const char *file_path, struct flag_rule *rule, uint32_t n_rule);

int get_flags(uint64_t *flag, uint32_t n_flag);





#endif // TOOLS_H