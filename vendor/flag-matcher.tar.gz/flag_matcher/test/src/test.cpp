#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "flag_matcher.h"
#include "../include/tools.h"

static inline uint64_t gettime(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (uint64_t)(ts.tv_sec * 1000000000 + ts.tv_nsec);
}


int main(int argc, char* argv[])
{
    if (argc != 3 || atoi(argv[1]) < 0 || atoi(argv[2]) < 0)
    {
        fprintf(stderr, "wrong parameters, we need two parameters for n_rule and flag. they all >0");
        return -1;
    }

    uint64_t begin_time = 0, end_time = 0;
    uint64_t *flag;
    uint32_t n_rule = (uint32_t)atoi(argv[1]), n_flag = (uint32_t)atoi(argv[2]);

    struct flag_result *result = NULL;
    int *result_number, matched_number = 0;

    struct flag_matcher *matcher;
    const char *file_path = "/root/flag_matcher/test/case/case_100w.txt";
    struct flag_rule *rule;
    rule = (struct flag_rule *)malloc(sizeof(struct flag_rule) * n_rule);
    memset(rule, 0, sizeof(struct flag_rule) * n_rule);

    flag = (uint64_t *)malloc(sizeof(uint64_t) * n_flag);
    memset(flag, 0, sizeof(uint64_t) * n_flag);

    result_number = (int *)malloc(sizeof(int) * n_flag);
    memset(flag, 0, sizeof(int) * n_flag);

    // read rule from file
    read_case(file_path, rule, n_rule);

    // get_flags by srand(1);
    get_flags(flag, n_flag);

    // for (uint32_t i = 0; i < n_rule; i ++)
    // {
    //     printf("%lu, %llu, %llu\n", rule[i].flag_rule_id, rule[i].flag, rule[i].mask);
    // }

    // for (uint32_t i = 0; i < n_flag; i ++)
    // {
    //     printf("%llu\n", flag[i]);
    // }

    matcher = flag_matcher_new(rule, n_rule);

    result = (struct flag_result *)malloc(sizeof(struct flag_result) * n_rule);
    memset(result, 0, sizeof(struct flag_result) * n_rule);
    
    begin_time = gettime();
    for (uint32_t i = 0; i < n_flag; i ++)
        result_number[i] = flag_matcher_match(matcher, flag[i], result, n_rule);
    end_time = gettime();
    
    
    // printf("The number of rules matched to each flag is:\n");
    for (uint32_t i = 0; i < n_flag; i ++)
    {
        // printf("%d %lu\n", result_number[i], flag[i]);
        matched_number += result_number[i];
    }
    printf("The total number of matches is: %d\n", matched_number);

    printf("Average per flag matched used time: %fns\n", (float)(end_time - begin_time)/(float)n_flag);

    free(rule);
    free(flag);
    free(result_number);
    flag_matcher_free(matcher);
    return 0;
}