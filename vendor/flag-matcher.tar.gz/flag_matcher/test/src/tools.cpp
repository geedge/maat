#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "tools.h"

static inline uint64_t get_sign()
{
    int temp = rand() % 2;
    if (temp)
        return 1;
    else
        return -1;
}


void new_case(const char *file_path, uint32_t n_case)
{
    if (!file_path)
    {
        fprintf(stderr, "new_case Invalid argument: char *file_path\n");
        return;
    }
    
    uint64_t flag, mask;
    FILE *fp = fopen(file_path, "w+"); 
    if (!fp)      
    {
        fprintf(stderr, "file_path %s open failure!\n", file_path);
        return;
    }

    srand(time(NULL));
    for (uint32_t i = 0; i < n_case; i ++)
    {
        flag = ((uint64_t)rand() * get_sign() << 32) + (uint64_t)rand() * get_sign();
        mask = ((uint64_t)rand() * get_sign() << 32) + (uint64_t)rand() * get_sign();

        fprintf(fp, "%u %lu %lu\n", i + 1, flag, mask);
    }

    fclose(fp);
    return;
}



int read_case(const char *file_path, struct flag_rule *rule, uint32_t n_rule)
{
    if (!file_path)
    {
        fprintf(stderr, "read_case Invalid argument: char *file_path\n");
        return -1;
    }

    if (!rule)
    {
        fprintf(stderr, "read_case Invalid argument: struct flag_rule *rule\n");
        return -1;
    }

    uint32_t number = 0, max_line = 256;
    char line[max_line];
    // char *flag = NULL, *mask = NULL, *id = NULL;
    FILE *fp = fopen(file_path, "r"); 
    if (!fp)      
    {
        fprintf(stderr, "file_path %s open failure!\n", file_path);
        return -1;
    }

    while (NULL != fgets(line, max_line, fp))
    {
        // id = strtok(line, ",");
        // flag = strtok(NULL, ",");
        // mask = strtok(NULL, "\n");
        // rule[number].flag = strtoll(flag, NULL, 0);
        // rule[number].mask = strtoll(mask, NULL, 0);
        // rule[number].flag_rule_id = atoi(id);
        sscanf(line, "%lu %lu %lu", &rule[number].rule_id, &rule[number].flag, &rule[number].mask);
        number ++;

        if (number == n_rule)
        {
            // fprintf(stderr, "rule table is full\n");
            fclose(fp);
            return number;
        }
    }

    fclose(fp);
    return number;
}


int get_flags(uint64_t *flag, uint32_t n_flag)
{
    if (!flag || n_flag <= 0)
    {
        fprintf(stderr, "flag can't be NULL and n_flag can't <=0");
        return -1;
    }

    srand(1);
    for (uint32_t i = 0; i < n_flag; i ++)
        flag[i] = ((uint64_t)rand() * get_sign() << 32) + (uint64_t)rand() * get_sign();
    
    return n_flag;
}