#include <stdio.h>
#include <stdlib.h>
#include "tools.h"

int main(int argc, char* argv[])
{
    if (argc > 2 || atoi(argv[1]) < 0)
    {
        fprintf(stderr, "Too many parameters, we just need a positive integer.");
        return -1;
    }

    int number = atoi(argv[1]);
    const char *file_path = "../case/case_100w.txt";

    new_case(file_path, (uint32_t)number);
    return 0;
}