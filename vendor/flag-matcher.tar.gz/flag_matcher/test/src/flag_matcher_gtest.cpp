#include <gtest/gtest.h>
#include <time.h>

#include "flag_matcher.h"
#include "tools.h"

#define ALLOC(type, number) (type *)calloc(sizeof(type), number)
#define FREE(p)             {free(p);p=NULL;}

const char *file_path = "../case/case_100w.txt";
const char *file_path_func = "../case/func_test_case.txt";

static inline uint64_t gettime(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (uint64_t)(ts.tv_sec * 1000000000 + ts.tv_nsec);
}


TEST(FlagMatcherTest, NewParameterTest) {

    size_t n_rule = 0;
    struct flag_rule *test_rule = NULL;
    struct flag_matcher *matcher = NULL;

    // rule = NULL;
    EXPECT_EQ(flag_matcher_new(NULL, 1), nullptr);

    // rule = NULL && n_rule = 0
    EXPECT_EQ(flag_matcher_new(NULL, 0), nullptr);

    n_rule = 100;
    test_rule = ALLOC(struct flag_rule, n_rule);
    read_case(file_path, test_rule, 100);

    // rule != NULL && n_rule = 0
    EXPECT_EQ(flag_matcher_new(test_rule, 0), nullptr);

    // rule != NULL && n_rule != 0
    EXPECT_NE(matcher = flag_matcher_new(test_rule, 100), nullptr);
    // EXPECT_EQ(test_rule[20].rule_id, 21);

    FREE(test_rule);
    flag_matcher_free(matcher);
}


TEST(FlagMatcherTest, MatcherParameterTest) {

    size_t n_rule = 0;
    struct flag_rule *test_rule = NULL;
    struct flag_result *result = NULL;
    struct flag_matcher *matcher = NULL;

    // flag_matcher = NULL && result = NULL
    EXPECT_EQ(flag_matcher_match(NULL, 1, NULL, 1), -1);

    n_rule = 100;
    test_rule = ALLOC(struct flag_rule, n_rule);
    read_case(file_path, test_rule, n_rule);

    matcher = flag_matcher_new(test_rule, n_rule);

    // flag_matcher != NULL && result = NULL
    EXPECT_EQ(flag_matcher_match(matcher, 1, result, n_rule), -1);

    result = ALLOC(struct flag_result, n_rule);

    // flag_matcher != NULL && result != NULL && n_result = 0
    EXPECT_EQ(flag_matcher_match(matcher, 1, result, 0), 0);

    // flag_matcher != NULL && result != NULL && n_result != 0
    EXPECT_NE(flag_matcher_match(matcher, 2384768191554408960, result, n_rule), 0);

    FREE(test_rule);
    FREE(result);
    flag_matcher_free(matcher);
}

TEST(FlagMatcherTest, MatcherFunctionTest) {

    size_t n_rule = 10;
    struct flag_rule *test_rule = NULL;
    struct flag_result *result = NULL;
    struct flag_matcher *matcher = NULL;

    test_rule = ALLOC(struct flag_rule, n_rule);
    read_case(file_path_func, test_rule, n_rule);

    matcher = flag_matcher_new(test_rule, n_rule);

    result = ALLOC(struct flag_result, n_rule);

    // flag_matcher != NULL && result != NULL && n_result != 0
    EXPECT_EQ(flag_matcher_match(matcher, 2384768191554408960, result, n_rule), 3);
    EXPECT_EQ(result[0].rule_id, (uint64_t)2);

    EXPECT_EQ(flag_matcher_match(matcher, 2594850416947234068, result, n_rule), 3);
    EXPECT_EQ(result[0].rule_id, (uint64_t)4);

    EXPECT_EQ(flag_matcher_match(matcher, 25948504169234068, result, n_rule), 2);

    n_rule = 3;
    read_case(file_path_func, test_rule, n_rule);
    matcher = flag_matcher_new(test_rule, n_rule);
    EXPECT_EQ(flag_matcher_match(matcher, 25948504169234068, result, n_rule), 0);

    FREE(test_rule);
    FREE(result);
    flag_matcher_free(matcher);
}

TEST(FlagMatcherTest, MatcherPressureTest) {

    size_t n_rule = 1000000;
    int *result_number, matched_times = 0;
    uint32_t n_flag = 2000;
    uint64_t *flag_array = NULL, begin_time = 0, end_time = 0;
    struct flag_rule *test_rule = NULL;
    struct flag_result *result = NULL;
    struct flag_matcher *matcher = NULL;

    test_rule = ALLOC(struct flag_rule, n_rule);
    result = ALLOC(struct flag_result, n_rule);
    flag_array = ALLOC(uint64_t, n_flag);
    result_number = ALLOC(int, n_flag);

    read_case(file_path, test_rule, n_rule);
    // get_flags by srand(1);
    get_flags(flag_array, n_flag);
    matcher = flag_matcher_new(test_rule, n_rule);

    begin_time = gettime();
    for (uint32_t i = 0; i < n_flag; i ++)
        result_number[i] = flag_matcher_match(matcher, flag_array[i], result, n_rule);
    end_time = gettime();

    printf("Average per flag matched used time: %fns\n", (float)(end_time - begin_time)/(float)n_flag);

    for (uint32_t i = 0; i < n_flag; i ++)
    {
        EXPECT_NE(result_number[i], -1);
        matched_times += result_number[i];
    }

    EXPECT_EQ(matched_times, 19);

    FREE(flag_array);
    FREE(test_rule);
    FREE(result);
    FREE(result_number);
    flag_matcher_free(matcher);
}

int main(int argc, char ** argv)
{
	int ret=0;
	::testing::InitGoogleTest(&argc, argv);
	ret=RUN_ALL_TESTS();
	return ret;
}
