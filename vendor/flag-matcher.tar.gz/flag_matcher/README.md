这是flag_matcher的发行版分支

目前该分支中使用naive方式实现，需要将每一条规则都做一次匹配；

各种方法性能对比（持续更新）：https://docs.geedge.net/display/~yangyubo/flag_matcher#flag_matcher-4.3%E6%B5%8B%E8%AF%95%E7%BB%93%E6%9E%9C%E8%AE%B0%E5%BD%95

