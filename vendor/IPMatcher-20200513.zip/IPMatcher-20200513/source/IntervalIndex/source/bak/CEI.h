/*
 *
 * Copyright (c) 2008
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:        Liu Yanbing	(liuyanbing@software.ict.ac.cn)
 * Date:              2008-05-03
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written 
 * permission from the authors.
 *
 */

#ifndef H_CEI_CPP_H
#define H_CEI_CPP_H

#include "IntervalIndex.h"
#include <map>

class CEI : public CIntervalIndex
{
public:
	// Virtual Construct size is L
	CEI(unsigned int L=65536);

	virtual ~CEI();

	virtual int PreProcessing(const std::vector<unsigned int>& a, const std::vector<unsigned int>& b);

	virtual std::vector<unsigned int> Find(unsigned int key);

private:
	void BestPartition(unsigned int id, unsigned int a, unsigned int b);

private:
	std::vector<unsigned int> m_IndexForMaxInt;
	unsigned int m_r;
	unsigned int m_l;
	unsigned int m_L;
	typedef std::map< unsigned int, std::vector<unsigned int> > TIntMap;
	TIntMap m_IDList;
	unsigned int m_uiIDNum;
};

#endif
