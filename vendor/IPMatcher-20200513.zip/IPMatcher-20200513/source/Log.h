#ifndef H_RULESCAN_LOG_H 
#define H_RULESCAN_LOG_H

#include <stdio.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>

#define LOG_FILE_PATH "./ipscan_tmp/ipscan_iie.log"
#define OPEN_LOG

int printf_log(const char * log_file_path, const char * format, ...);
int clear_log(const char * log_file_path);
int set_log_close_flag(bool close_flag);

#endif