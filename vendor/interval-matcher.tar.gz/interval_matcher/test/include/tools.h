#ifndef TOOLS_H
#define TOOLS_H

#include <stdint.h>
#include "interval_matcher.h"

void new_case(const char *file_path, size_t n_case);

int read_case(const char *file_path, struct interval_rule *rule, size_t n_rule);

int get_targets(uint64_t *target, size_t n_target, struct interval_rule *rule, size_t n_rule);





#endif // TOOLS_H