#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "interval_matcher.h"
#include "../include/tools.h"

static inline uint64_t gettime(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (uint64_t)(ts.tv_sec * 1000000000 + ts.tv_nsec);
}


int main(int argc, char* argv[])
{
    if (argc != 3 || atoi(argv[1]) < 0 || atoi(argv[2]) < 0)
    {
        fprintf(stderr, "wrong parameters, we need two parameters for n_rule and flag. they all >0");
        return -1;
    }

    uint64_t begin_time = 0, end_time = 0;
    uint64_t *targets;
    uint64_t n_rule = (uint64_t)atoi(argv[1]), n_target = (uint64_t)atoi(argv[2]);

    struct interval_result *result;
    uint64_t *result_number, matched_number = 0;

    struct interval_matcher *matcher;
    const char *file_path = "/root/interval_matcher/test/case/cases_100w.txt";
    struct interval_rule *rule;

    result = (struct interval_result *)calloc(sizeof(struct interval_result), n_rule);
    rule = (struct interval_rule *)calloc(sizeof(struct interval_rule), n_rule);
    targets = (uint64_t *)calloc(sizeof(uint64_t), n_target);
    result_number = (uint64_t *)calloc(sizeof(uint64_t), n_target);
    
    // read rule from file
    read_case(file_path, rule, n_rule);

    // get_flags by srand(1);
    get_targets(targets, n_target, rule, n_rule);

    // for (uint32_t i = 0; i < n_rule; i ++)
    // {
    //     printf("%lu, %llu, %llu\n", rule[i].flag_rule_id, rule[i].flag, rule[i].mask);
    // }

    // for (uint32_t i = 0; i < n_flag; i ++)
    // {
    //     printf("%llu\n", flag[i]);
    // }

    matcher = interval_matcher_new(rule, n_rule);

    begin_time = gettime();
    for (uint32_t i = 0; i < n_target; i ++)
        result_number[i] = interval_matcher_match(matcher, targets[i], result, n_rule);
    end_time = gettime();
    
    
    printf("The number of rules matched to each flag is:\n");
    for (uint32_t i = 0; i < n_target; i ++)
    {
        printf("%lu %lu\n", result_number[i], targets[i]);
        matched_number += result_number[i];
    }
    printf("The total number of matches is: %lu\n", matched_number);

    printf("Average per flag matched used time: %fns\n", (float)(end_time - begin_time)/(float)n_target);
    getchar();
    free(rule);
    free(targets);
    free(result_number);
    free(result);
    interval_matcher_free(matcher);
    return 0;
}