#include <gtest/gtest.h>
#include <time.h>

#include "interval_matcher.h"
#include "tools.h"

#define ALLOC(type, number) (type *)calloc(sizeof(type), number)
#define FREE(p)             {free(p);p=NULL;}

const char *file_path = "../case/cases_100w.txt";
const char *file_path_func = "../case/cases_100w_100.txt";
const char *file_path_ll = "../case/cases_10_ll.txt";

static inline uint64_t gettime(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (uint64_t)(ts.tv_sec * 1000000000 + ts.tv_nsec);
}


TEST(intervalMatcherTest, NewParameterTest) {

    size_t n_rule = 0;
    struct interval_rule *test_rule = NULL;
    struct interval_matcher *matcher = NULL;

    // rule = NULL;
    EXPECT_EQ(interval_matcher_new(NULL, 1), nullptr);

    // rule = NULL && n_rule = 0
    EXPECT_EQ(interval_matcher_new(NULL, 0), nullptr);

    n_rule = 100;
    test_rule = ALLOC(struct interval_rule, n_rule);
    read_case(file_path, test_rule, 100);

    // rule != NULL && n_rule = 0
    EXPECT_EQ(interval_matcher_new(test_rule, 0), nullptr);

    // rule != NULL && n_rule != 0
    EXPECT_NE(matcher = interval_matcher_new(test_rule, 100), nullptr);
    // EXPECT_EQ(test_rule[20].rule_id, 21);

    FREE(test_rule);
    interval_matcher_free(matcher);
}


TEST(intervalMatcherTest, MatcherParameterTest) {

    size_t n_rule = 0;
    struct interval_rule *test_rule = NULL;
    struct interval_result *result = NULL;
    struct interval_matcher *matcher = NULL;

    // interval_matcher = NULL && result = NULL
    EXPECT_EQ(interval_matcher_match(NULL, 1, NULL, 1), -1);

    n_rule = 100;
    test_rule = ALLOC(struct interval_rule, n_rule);
    read_case(file_path, test_rule, n_rule);

    matcher = interval_matcher_new(test_rule, n_rule);

    // interval_matcher != NULL && result = NULL
    EXPECT_EQ(interval_matcher_match(matcher, 1, result, n_rule), -1);

    result = ALLOC(struct interval_result, n_rule);

    // interval_matcher != NULL && result != NULL && n_result = 0
    EXPECT_EQ(interval_matcher_match(matcher, 1, result, 0), -1);

    // interval_matcher != NULL && result != NULL && n_result != 0
    EXPECT_NE(interval_matcher_match(matcher, 329330, result, n_rule), 0);

    FREE(test_rule);
    FREE(result);
    interval_matcher_free(matcher);
}

TEST(intervalMatcherTest, MatcherFunctionTest) {

    size_t n_rule = 10;
    struct interval_rule *test_rule = NULL;
    struct interval_result *result = NULL;
    struct interval_matcher *matcher = NULL;

    test_rule = ALLOC(struct interval_rule, n_rule);
    read_case(file_path, test_rule, n_rule);

    matcher = interval_matcher_new(test_rule, n_rule);

    result = ALLOC(struct interval_result, n_rule);

    // interval_matcher != NULL && result != NULL && n_result != 0
    EXPECT_EQ(interval_matcher_match(matcher, 405861, result, n_rule), 7);
    EXPECT_EQ(result[0].rule_id, (uint64_t)2);

    EXPECT_EQ(interval_matcher_match(matcher, 453828, result, n_rule), 6);
    EXPECT_EQ(result[0].rule_id, (uint64_t)3);

    EXPECT_EQ(interval_matcher_match(matcher, 458315, result, n_rule), 6);
    interval_matcher_free(matcher);

    n_rule = 3;
    read_case(file_path, test_rule, n_rule);
    matcher = interval_matcher_new(test_rule, n_rule);
    EXPECT_EQ(interval_matcher_match(matcher, 477864, result, n_rule), 0);
    interval_matcher_free(matcher);

    n_rule = 10;
    read_case(file_path_ll, test_rule, n_rule);
    matcher = interval_matcher_new(test_rule, n_rule);
    EXPECT_EQ(interval_matcher_match(matcher, 477864, result, n_rule), 0);
    EXPECT_EQ(interval_matcher_match(matcher, 9851024843233476741ull, result, n_rule), 6);
    EXPECT_EQ(interval_matcher_match(matcher, 169252308722635002ull, result, n_rule), 7);
    EXPECT_EQ(interval_matcher_match(matcher, 18446744073709551614ull, result, n_rule), 0);
    EXPECT_EQ(interval_matcher_match(matcher, 18446744073709551615ull, result, n_rule), -1);
    EXPECT_EQ(interval_matcher_match(matcher, (uint64_t)(-1), result, n_rule), -1);
    EXPECT_EQ(interval_matcher_match(matcher, 1, result, n_rule), 0);
    EXPECT_EQ(interval_matcher_match(matcher, 100000, result, n_rule), 0);
    EXPECT_EQ(interval_matcher_match(matcher, 12922216671677261088ull, result, n_rule), 3);
    EXPECT_EQ(interval_matcher_match(matcher, 17601921813485417827ull, result, n_rule), 1);
    
    FREE(test_rule);
    FREE(result);
    interval_matcher_free(matcher);
}

TEST(intervalMatcherTest, MatcherPressureTest) {

    size_t n_rule = 1000000;
    int *result_number, matched_times = 0;
    uint32_t n_interval = 5000;
    uint64_t *interval_array = NULL, begin_time = 0, end_time = 0;
    struct interval_rule *test_rule = NULL;
    struct interval_result *result = NULL;
    struct interval_matcher *matcher = NULL;

    test_rule = ALLOC(struct interval_rule, n_rule);
    result = ALLOC(struct interval_result, n_rule);
    interval_array = ALLOC(uint64_t, n_interval);
    result_number = ALLOC(int, n_interval);

    read_case(file_path_func, test_rule, n_rule);
    // get_intervals by srand(1);
    get_targets(interval_array, n_interval, test_rule, n_rule);
    matcher = interval_matcher_new(test_rule, n_rule);

    begin_time = gettime();
    for (uint32_t i = 0; i < n_interval; i ++)
        result_number[i] = interval_matcher_match(matcher, interval_array[i], result, n_rule);
    end_time = gettime();

    printf("Average per interval matched used time: %fns\n", (float)(end_time - begin_time)/(float)n_interval);

    for (uint32_t i = 0; i < n_interval; i ++)
    {
        EXPECT_NE(result_number[i], -1);
        matched_times += result_number[i];
    }

    EXPECT_EQ(matched_times, 510521);

    FREE(interval_array);
    FREE(test_rule);
    FREE(result);
    FREE(result_number);
    interval_matcher_free(matcher);
}

int main(int argc, char ** argv)
{
	int ret=0;
	::testing::InitGoogleTest(&argc, argv);
	ret=RUN_ALL_TESTS();
	return ret;
}
