#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "tools.h"

void new_case(const char *file_path, size_t n_case)
{
    if (!file_path)
    {
        fprintf(stderr, "new_case Invalid argument: char *file_path\n");
        return;
    }
    
    uint64_t start, end;
    FILE *fp = fopen(file_path, "w+"); 
    if (!fp)      
    {
        fprintf(stderr, "file_path %s open failure!\n", file_path);
        return;
    }

    srand(time(NULL));
    for (size_t i = 0; i < n_case; i ++)
    {
        start = (uint64_t)rand()%n_case/2;
        end = start + (uint64_t)rand()%n_case/2;
        // if (rand() % 100 < 1) // 1%的规则区间大小为1
        // {
        //     end = start;
        // }
        
        fprintf(fp, "%lu %lu %lu\n", i + 1, start, end);
    }

    fclose(fp);
    return;
}



int read_case(const char *file_path, struct interval_rule *rule, size_t n_rule)
{
    if (!file_path)
    {
        fprintf(stderr, "read_case Invalid argument: char *file_path\n");
        return -1;
    }

    if (!rule)
    {
        fprintf(stderr, "read_case Invalid argument: struct flag_rule *rule\n");
        return -1;
    }

    uint64_t number = 0, max_line = 256;
    char line[max_line];
    // char *flag = NULL, *mask = NULL, *id = NULL;
    FILE *fp = fopen(file_path, "r"); 
    if (!fp)      
    {
        fprintf(stderr, "file_path %s open failure!\n", file_path);
        return -1;
    }

    while (NULL != fgets(line, max_line, fp))
    {
        // id = strtok(line, ",");
        // flag = strtok(NULL, ",");
        // mask = strtok(NULL, "\n");
        // rule[number].flag = strtoll(flag, NULL, 0);
        // rule[number].mask = strtoll(mask, NULL, 0);
        // rule[number].flag_rule_id = atoi(id);
        sscanf(line, "%lu %lu %lu", &rule[number].result.rule_id, &rule[number].start, &rule[number].end);
        number ++;

        if (number >= n_rule)
        {
            break;
        }
    }

    fclose(fp);
    return number;
}


int get_targets(uint64_t *target, size_t n_target, struct interval_rule *rule, size_t n_rule)
{
    if (!target || n_target <= 0)
    {
        fprintf(stderr, "flag can't be NULL and n_flag can't <=0");
        return -1;
    }

    srand(1);
    int index = 0;
    for (uint64_t i = 0; i < n_target; i ++)
    {
        index = rand()%n_rule;
        target[i] = rule[index].start;
    }
        
    return n_target;
}