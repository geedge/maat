/*
 *
 * Copyright (c) 2008
 * DSMS Group, Institute of Computing Technology, Chinese Academy of Sciences.
 * All rights reserved.
 *
 * Authors:        Liu Yanbing	(liuyanbing@software.ict.ac.cn)
 * Date:              2008-05-03
 *
 * This code is the exclusive and proprietary property of DSMS@ICT. Usage for 
 * direct or indirect commercial advantage is not allowed without written 
 * permission from the authors.
 *
 */

#include "CEI.h"

#include <algorithm>
#include <map>
#include <cstdlib>
#include <cassert>
using namespace std;

CEI::CEI(unsigned int L)
{
	m_L=L;
}

CEI::~CEI()
{
}

int CEI::PreProcessing(const std::vector<unsigned int>& a, const std::vector<unsigned int>& b)
{
	this->m_uiIDNum=0;

	vector<unsigned int> A=a, B=b;

	for(int i=0; i<(int)A.size(); i++)
	{
		assert(A[i]<=B[i]);

		if(B[i]==UINT_MAX)
		{
			this->m_IndexForMaxInt.push_back(i);
			--B[i];
		}
		B[i]++; // now A[i], B[i] is half closed interval.
		if(A[i]>=B[i]) continue;

		unsigned int inf=(A[i]+m_L-1)&-m_L;
		unsigned int sup=B[i]&-m_L;

		if(inf>sup)
		{
			this->BestPartition(i, A[i], B[i]);
		}
		else
		{
			for(unsigned int p=inf; p<sup; p+=m_L)
			{
				m_IDList[(p<<1)+1].push_back(i);
				if(m_IDList.size()%1000000==0) printf("m_IDList.size=%u.\n", m_IDList.size());
				m_uiIDNum++;
				if(m_uiIDNum%1000000==0) printf("m_uiIDNum=%u.\n", m_uiIDNum);
			}

			if(A[i]<inf) this->BestPartition(i, A[i], inf);
			if(sup<B[i]) this->BestPartition(i, sup, B[i]);
		}
	}

	int iMemBytes=0;//sizeof(unsigned int)*(M+1+m_pIDList[M]);

#ifdef DEBUG_INTERVAL_INDEX
	printf("CEI membyte=%5.3lf (MB).\n", (double)iMemBytes/(1u<<20));
#endif

	return iMemBytes;
}

void CEI::BestPartition(unsigned int id, unsigned int a, unsigned int b)
{
	unsigned int g=(a&-m_L)<<1;

	while(a<b)
	{
		unsigned int t=(a&(m_L-1))+m_L;
		unsigned int delta=1;
		while((t&1)==0 && a+(delta<<1)<=b)
		{
			t>>=1;
			delta<<=1;
		}

		m_IDList[g+t].push_back(id);
		if(m_IDList.size()%1000000==0) printf("m_IDList.size=%u.\n", m_IDList.size());
		m_uiIDNum++;
		if(m_uiIDNum%1000000==0) printf("m_uiIDNum=%u.\n", m_uiIDNum);
		a+=delta;
	}
}

std::vector<unsigned int> CEI::Find(unsigned int key)
{
	if(key==UINT_MAX)
	{
		return m_IndexForMaxInt;
	}
	else
	{
		vector<unsigned int> v;

		unsigned int g=(key&-m_L)<<1;

		for(unsigned int t=(key&(m_L-1))+m_L; t; t>>=1)
		{
			unsigned int c=g+t;
			TIntMap::const_iterator pb=m_IDList.find(c);
			if(pb!=m_IDList.end())
			{
				copy(pb->second.begin(), pb->second.end(), back_inserter(v));
			}
		}

		sort(v.begin(), v.end());

		return v;
	}
}
