/*
*
* Copyright (c) 2008--2012
* String Matching Group, Lab for Intelligent Information Processing Technology,
* Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS).
* All rights reserved.
*
* Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
* Last modification: 2012-07-10
*
* This code is the exclusive and proprietary property of IIE-CAS. Usage for direct 
* or indirect commercial advantage is not allowed without written permission from 
* the authors.
*
*/

#include "../source/IntervalIndex.h"
#include "../source/NaiveIntervalIndex.h"
#include "../source/NaiveIntervalIndex2.h"
#include "../source/IntervalTree.h"
#include "../source/FastIntervalIndex.h"
#include "../source/CEI.h"
#include "../source/ACEI.h"
#include "../source/DirectIndex.h"
#include "getopt.h"

#include <cmath>
#include <cstdlib>
#include <climits>
#include <utility>
#include <iostream>
#include <cassert>
#include <vector>
#include <ctime>
#include <fstream>
#include <cstring>
using namespace std;

static unsigned long long A=6364136223846793005LL;
static unsigned long long C=1442695040888963407LL;
static unsigned long long X=2014;

unsigned int myrand(unsigned int R)
{
	X=A*X+C;
	return X%R;
}

void GenRandInterval(int n, vector<unsigned int>& a, vector<unsigned int>& b)
{
	for(int i=0; i<n; i++)
	{
		unsigned int inf=myrand(0xFFFFFFFF);
		unsigned int sup=inf+myrand(0xFFFF);

		if(sup<inf) sup=inf;

		a.push_back(inf);
		b.push_back(sup);
	}
}

void GenRandPoint(const vector<unsigned int>& a, const vector<unsigned int>& b, int m, double r, vector<unsigned int>& p)
{
	for(int i=0; i<m; i++)
	{
		double rd=myrand(100);
		if(rd/100<r)
		{
			int idx=myrand(a.size());
			p.push_back( a[idx]+myrand(b[idx]-a[idx]) );
		}
		else
		{
			p.push_back( myrand(UINT_MAX) );
		}
	}
}

void PrintUsage()
{
	cout << endl << "----------welcome to Interval Index library!----------" << endl;
	cout << "written by: LIU YANBING (liuyanbing@iie.ac.cn)" << endl;
	cout << "-------------------------------------------------------" << endl << endl;

	cout << "1. usage: " << endl;
	cout << "\t" << "TestIntervalIndex -r rule_num -p point_num -f hit_rate -a algorithm" << endl;
	cout << endl;

	cout << "2. options: " << endl;
	cout << "\t" << "-r" << "\t\t\t" << "number of rules." << endl; 	
	cout << "\t" << "-p" << "\t\t\t" << "number of points." << endl;
	cout << "\t" << "-f" << "\t\t\t" << "percent of points matched. (default: 0.1)" << endl;
	cout << "\t" << "-a" << "\t\t\t" << "algorithm to be tested." << endl;
	cout << endl;

	cout << "3. supported algorithms: " << endl;
	cout << "\t" << "NaiveIndex"        << endl;
	cout << "\t" << "NaiveIndex2"       << endl;
	cout << "\t" << "FastIndex"         << endl;
	cout << "\t" << "TreeIndex"         << endl;
	cout << "\t" << "CEI"               << endl;
	cout << "\t" << "ACEI"              << endl;
	cout << "\t" << "DirectIndex"       << endl;
	cout << endl;
}

CIntervalIndex * new_algor(const char * algor_name)
{
	if(strcmp(algor_name, "NaiveIndex")==0)
	{
		return new CNaiveIntervalIndex;
	}
	else if(strcmp(algor_name, "NaiveIndex2")==0)
	{
		return new CNaiveIntervalIndex2;
	}
	else if(strcmp(algor_name, "FastIndex")==0)
	{
		return new CFastIntervalIndex;
	}
	else if(strcmp(algor_name, "TreeIndex")==0)
	{
		return new CIntervalTree;
	}
	else if(strcmp(algor_name, "CEI")==0)
	{
		return new CEI;
	}
	else if(strcmp(algor_name, "ACEI")==0)
	{
		return new ACEI;
	}
	else if(strcmp(algor_name, "DirectIndex")==0)
	{
		return new CDirectIndex;
	}
	else
	{
		return NULL;
	}
}

int main(int argc, char* argv[])
{
	int ch;
	vector<string> AlgorNames;
	vector<CIntervalIndex *> Algors;
	CIntervalIndex * algor=NULL;
	int rule_num=0;
	int point_num=0;
	double hit_rate=0.1;

#define	LONG_OPT_CHAR	65536
	const struct option LongOptions []={ 
		{"rule-num", 1, NULL, LONG_OPT_CHAR+0},
		{"point-num", 1, NULL, LONG_OPT_CHAR+1},
		{"hit-rate", 1, NULL, LONG_OPT_CHAR+2},
		{NULL, 0, NULL, 0}
	};

	while((ch=getopt_long(argc, argv, "r:p:f:a:h", LongOptions, NULL))!=-1)
	{
		switch(ch)
		{
		case LONG_OPT_CHAR+0 :
			rule_num=atol(optarg); 
			break;
		case LONG_OPT_CHAR+1 :
			point_num=atol(optarg);
			break;
		case LONG_OPT_CHAR+2 :
			sscanf(optarg, "%lf", &hit_rate);
			break;
		case 'r' :
			rule_num=atol(optarg);
			break;
		case 'p' :
			point_num=atol(optarg);
			break;
		case 'f' :
			sscanf(optarg, "%lf", &hit_rate);
			break;
		case 'a' :
			AlgorNames.push_back(string(optarg));
			algor=new_algor(optarg);
			if(algor==NULL)
			{
				cout << "invalid algorithm name!" << endl;
				return -1;
			}
			Algors.push_back(algor);
			break;
		case 'h' :
		default :
			PrintUsage();
			return -1;
		}
	}

	if(rule_num>0 && point_num>0)
	{
		printf("******************************************\n");

		vector<unsigned int> a, b, p;

		GenRandInterval(rule_num, a, b);

		GenRandPoint(a, b, point_num, hit_rate, p);

		//a.push_back(0); 
		//b.push_back(0xFFFFFFFF);

		//a.push_back(0xFFFFFFFF); 
		//b.push_back(0xFFFFFFFF);

		//a.push_back(0); 
		//b.push_back(0);

		//a.push_back(0x0a000000); 
		//b.push_back(0x0a00FFFF);

		//p.push_back(0);
		//p.push_back(0xFFFFFFFF);
		//p.push_back(0x09FFFFFF);

		printf("rule_num=%u, point_num=%u.\n\n", (unsigned int)a.size(), (unsigned int)p.size());

		for(int i=0; i<(int)Algors.size(); i++)
		{
			printf("algorithm %s: ", AlgorNames[i].c_str());

			clock_t clk=clock();
			int iMemBytes=Algors[i]->PreProcessing(a, b);
			clk=clock()-clk;
			if(iMemBytes<0) continue;
			double sec=(double)clk/CLOCKS_PER_SEC;

			printf("membyte=%5.3lf (MB), preprocessing time=%5.3lf (s), ", (double)iMemBytes/(1u<<20), sec);

			unsigned int iMatchCount=0;

			clk=clock();
			for(int j=0; j<point_num; j++)
			{
				vector<unsigned int> v=Algors[i]->Find(p[j]);
				iMatchCount+=(unsigned int)v.size();
			}
			clk=clock()-clk;
			sec=(double)clk/CLOCKS_PER_SEC;
			printf("iMatchCount=%u, speed=%5.3lf (k/s).\n\n", iMatchCount, point_num/sec/1000);

			delete Algors[i];
		}
	}
	else
	{
		PrintUsage();
	}

	return 1;
}
