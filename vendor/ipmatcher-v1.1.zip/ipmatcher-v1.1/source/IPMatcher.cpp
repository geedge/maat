#include "../include/IPMatcher.h"
#include "RuleMatch.h"
#include "IPv4Match.h"
#include "IPv6Match.h"
#include <list>
#include <map>
using namespace std;

int ipmatcher_VERSION_2020_05_13 = 0;
//#define RULESCAN_DEBUG

struct ip_matcher
{
	CRuleMatch *	ipv4_matcher;
	CRuleMatch *	ipv6_matcher;

#ifdef RULESCAN_DEBUG
	//for test
	double						search_time;
	int							search_cnt;
#endif
};

CRuleMatch * new_rule_matcher(enum IP_TYPE type)
{
	if(type==IPv4)
	{
		return new CIPv4Match();
	}
	else if(type==IPv6)
	{
		return new CIPv6Match();
	}
	else
	{
		return NULL;
	}
}

struct ip_matcher * ip_matcher_new(struct ip_rule * rules, size_t rule_num, size_t * mem_use)
{
	if(rules == NULL || rule_num == 0)
	{
		printf_log(NULL,"[%s:%d]:  ip_matcher_new() failed, for param is wrong!\n", __FILE__, __LINE__);
		return NULL;
	}

	long long mem_bytes=0;

	struct ip_matcher * matcher = new struct ip_matcher;
	mem_bytes = sizeof(struct ip_matcher);
	matcher->ipv4_matcher = NULL;
	matcher->ipv6_matcher = NULL;

	map<unsigned int, struct ip_rule> ipv4_rules;
	map<unsigned int, struct ip_rule> ipv6_rules;
	for(unsigned int i = 0; i < (unsigned int)rule_num; i++)
	{
		unsigned int id = rules[i].rule_id;
		if(rules[i].type == IPv4)
			ipv4_rules[id] = rules[i];
		if(rules[i].type == IPv6 )
			ipv6_rules[id] = rules[i];
	}

	//����ipv4ɨ����
	if(ipv4_rules.size() != 0)
	{	
		CRuleMatch * v4_matcher = new CIPv4Match;
		long long ret = v4_matcher->initialize(ipv4_rules);
		if(ret<0)
		{
			delete v4_matcher;
			v4_matcher=NULL;
			printf_log(NULL,"ip_matcher_new() failed !\n", __FILE__, __LINE__);
			return NULL;
		}

		mem_bytes += ret;
		matcher->ipv4_matcher = v4_matcher;
	}

	//����ipv6ɨ����
	if(ipv6_rules.size() != 0)
	{
		CRuleMatch * v6_matcher = new CIPv6Match;
		long long ret = v6_matcher->initialize(ipv6_rules);
		if(ret<0)
		{
			delete v6_matcher;
			v6_matcher=NULL;
			printf_log(NULL,"ip_matcher_new() failed !\n", __FILE__, __LINE__);
			return NULL;
		}

		mem_bytes += ret;
		matcher->ipv6_matcher = v6_matcher;
	}

	*mem_use = mem_bytes;

	return matcher;
}

int ip_matcher_match(struct ip_matcher* matcher, struct ip_data* data, struct scan_result* result, size_t size)
{
	if(matcher == NULL || data == NULL || result == NULL)
	{
		printf_log(NULL,"[%s:%d]: ip_matcher_match() failed, for param is NULL!\n", __FILE__, __LINE__);
		return -1;
	}

	CRuleMatch * tmp_matcher = NULL;

	if(data->type == IPv4)
	{
		tmp_matcher = matcher->ipv4_matcher;
	}
	if(data->type == IPv6)
	{
		tmp_matcher = matcher->ipv6_matcher;
	}

	if(tmp_matcher==NULL) 
	{
		printf_log(NULL,"[%s:%d]: ip_matcher_match() failed, for can't find the right rule_matcher!\n", __FILE__, __LINE__);
		return -1;
	}

	int ret = tmp_matcher->search_rule(data,result,size);
	if(ret<0) 
	{
		printf_log("[%s:%d]: ip_matcher_match() failed, for the value returned by search_rule() is wrong !\n", __FILE__, __LINE__);
		return -1;
	}

	return ret;
}

void ip_matcher_free(struct ip_matcher* matcher)
{
	if(matcher == NULL) return;

	if(matcher->ipv4_matcher != NULL)
		delete matcher->ipv4_matcher;
	if(matcher->ipv6_matcher != NULL)
		delete matcher->ipv6_matcher;

	delete matcher;
}