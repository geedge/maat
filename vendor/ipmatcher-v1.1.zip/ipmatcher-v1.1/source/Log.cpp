#include "Log.h"

bool log_close_flag = true;

int set_log_close_flag(bool close_flag)
{
	log_close_flag = close_flag;
	return 1;
}

int printf_log(const char * log_file_path,const char * format, ...)
{

//#ifdef OPEN_LOG
	if(!log_close_flag)
	{
#define LOG_FILE_MAX_SIZE  10000000

		const char * path = NULL;
		if(log_file_path == NULL)
			path = LOG_FILE_PATH;
		else
			path = log_file_path;	
		//�жϣ������־�ļ��Ĵ�С����10M�������¿�ʼд
		FILE * flog;
		flog=fopen(path,"rb");	
		int now_size=0;
		if(flog!=NULL)
		{
			fseek(flog,0,SEEK_END);
			now_size=ftell(flog);
			fclose(flog);
		}
		FILE * fp;
		if(now_size > LOG_FILE_MAX_SIZE)
		{
			//��Ҫ���¿�ʼ
			fp = fopen(path, "w+");
		}
		else
		{
			//����Ҫ���¿�ʼ
			fp = fopen(path, "a");
		}
		if(fp==NULL) 
		{
			return  -1;
		}

#define MAX_LOG_LINES 65536
		va_list ap;
		char * buf=new char[MAX_LOG_LINES];
		va_start(ap, format);
		vsprintf(buf, format, ap);
		va_end(ap);

		time_t cur;
		char buf2[128];
		memset(buf2, 0, 128);
		time(&cur);
		sprintf(buf2, "%s", ctime(&cur));
		buf2[strlen(buf2) - 1] = '\0';
		fprintf(fp, "[%s]: %s", buf2, buf);
		fclose(fp);

		delete [] buf;
	}

//#endif

	return 1;
}

int clear_log(const char * log_file_path)
{
	FILE * fp = NULL;
	if(log_file_path == NULL)
		fp = fopen(LOG_FILE_PATH, "wb");
	else
		fp = fopen(log_file_path,"wb");
	if(fp!=NULL) fclose(fp);
	return 1;
}
