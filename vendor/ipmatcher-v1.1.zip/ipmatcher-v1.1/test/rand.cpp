/*
 *
 * Copyright (c) 2008-2016
 * String Algorithms Research Group
 * Institute of Information Engineering, Chinese Academy of Sciences (IIE-CAS)
 * National Engineering Laboratory for Information Security Technologies (NELIST)
 * All rights reserved
 *
 * Written by: LIU YANBING    (liuyanbing@iie.ac.cn)
 * Last modification: 2016-04-29
 *
 * This code is the exclusive and proprietary property of IIE-CAS and NELIST. 
 * Usage for direct or indirect commercial advantage is not allowed without 
 * written permission from the authors.
 *
 */

#include "rand.h"
#include <stdlib.h>
#include <time.h>

/*
�ο����ף�
Linear congruential generator - Wikipedia, the free encyclopedia  
https://en.wikipedia.org/wiki/Linear_congruential_generator
*/

unsigned int intrand()
{
	const unsigned int A=1664525;
	const unsigned int C=1013904223;
	static unsigned int X=(unsigned int)time(NULL);
	return X=A*X+C;
}

unsigned long long longrand()
{
	const unsigned long long A=6364136223846793005LL;
	const unsigned long long C=1442695040888963407LL;
	static unsigned long long X=(unsigned long long)time(NULL);
	return X=A*X+C;
}

unsigned int range_rand(unsigned int a, unsigned int b)
{
	return (unsigned int)(a+longrand()%(b-a+1));
}

double stdrand()
{
	return (double)rand()/(RAND_MAX+1.0);
}
