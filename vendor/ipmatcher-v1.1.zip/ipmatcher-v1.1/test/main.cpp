#include "../include/IPMatcher.h"
#include "rand.h"
#include <stdio.h>
#include <stdlib.h>
#include "../source/IntervalIndex/source/Int128IntervalIndex.h"

void gen_ipv4_rule(struct ipv4_range * rule, unsigned int rnum)
{
	for(unsigned int i = 0; i < rnum; i++)
	{
		rule[i].start_ip = longrand()&0xFFFFFFFF;
		while(1)
		{
			rule[i].end_ip = longrand()&0xFFFFFFFF;
			if(rule[i].end_ip > rule[i].start_ip)
				break;
		}
	}
}

void gen_one_ipv4_data(const struct ipv4_range * rule, unsigned int rnum, struct ip_data &data, double ratio)
{
	double p=stdrand();
	if(p<ratio)
	{
		int j=longrand()%rnum;
		int x = range_rand(rule[j].start_ip,rule[j].end_ip);
		data.ipv4 = rule[j].start_ip + x;
	}
	else
	{
		data.ipv4 = longrand()&0xFFFFFFFF;
	}
}

void test_ipv4(unsigned int rnum, double ratio)
{
	printf("testing ipv4...\n");

	unsigned int dnum=10;

	struct ipv4_range * rule=new struct ipv4_range[rnum];
	gen_ipv4_rule(rule, rnum);

	struct ip_rule * ip_array = new struct ip_rule[rnum];
	for(unsigned int i = 0; i < rnum; i++)
	{
		ip_array[i].rule_id = i;
		ip_array[i].type = IPv4;
		ip_array[i].user_tag = NULL;
		ip_array[i].ipv4_rule = rule[i];
	}

	size_t mem_uses = 0;
	struct ip_matcher * matcher = ip_matcher_new(ip_array, rnum, &mem_uses);
	if(matcher == NULL)
	{
		printf("rulescan_update() error!\n");
		exit(0);
	}	

	struct scan_result result[1000];
	for(int i = 0; i < dnum; i++)
	{
		struct ip_data data;
		data.type = IPv4;
		//ratio = 1;
		gen_one_ipv4_data(rule, rnum, data, ratio);

		int ret = ip_matcher_match(matcher,&data,result,1000);

		unsigned int interval = -1;
		printf("###################################\n");
		for(int j = 0; j < ret; j++)
		{
			int id = result[j].rule_id;
			interval = rule[id].end_ip - rule[id].start_ip;
			//printf("%u\n",interval);
			printf("rule id = %u, rule interval = %u\n",result[j].rule_id, interval);
		}
		printf("###################################\n");

	}

	ip_matcher_free(matcher);	
	delete [] ip_array;
	delete [] rule;
}

void gen_ipv6_rule(struct ipv6_range * rule, unsigned int rnum)
{
	for(int i = 0; i < rnum; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			rule[i].start_ip[j] = longrand()&0xFFFFFFFF;
		}

		while(1)
		{
			for(int j = 0; j < 4; j++)
			{
				rule[i].end_ip[j] = longrand()&0xFFFFFFFF;
			}

			uint128_t a(rule[i].start_ip);
			uint128_t b(rule[i].end_ip);
			if(a < b)
				break;
		}
	}
}

void gen_one_ipv6_data(const struct ipv6_range * rule, unsigned int rnum, struct ip_data &data, double ratio)
{
	double p=stdrand();
	if(p<ratio)
	{
		int j=longrand()%rnum;

		for(int i = 0; i < 4; i++)
		{
			if(rule[j].start_ip[i] != rule[j].end_ip[i])
			{
				int x = range_rand(rule[j].start_ip[i],rule[j].end_ip[i]);
				data.ipv6[i] = rule[j].start_ip[i] + x;
			}
			else
			{
				data.ipv6[i] = rule[j].end_ip[i];
			}
		}
	}
	else
	{
		for(int i = 0; i < 4; i++)
			data.ipv6[i] = longrand()&0xFFFFFFFF;
	}
}

void test_ipv6(unsigned int rnum, double ratio)
{
	printf("testing ipv6...\n");

	unsigned int dnum=10;

	struct ipv6_range * rule=new struct ipv6_range[rnum];
	gen_ipv6_rule(rule, rnum);


	struct ip_rule * ip_array = new struct ip_rule[rnum];
	for(unsigned int i = 0; i < rnum; i++)
	{
		ip_array[i].rule_id = i;
		ip_array[i].type = IPv6;;
		ip_array[i].user_tag = NULL;
		ip_array[i].ipv6_rule = rule[i];
	}

	size_t mem_use = 0;
	struct ip_matcher * matcher = ip_matcher_new(ip_array,rnum,&mem_use);
	if(matcher == NULL)
	{
		printf("ip_matcher_new() error!\n");
		exit(0);
	}	

	struct scan_result result[1000];
	for(int i = 0; i < dnum; i++)
	{
		struct ip_data data;
		data.type = IPv6;
		//ratio = 1;
		gen_one_ipv6_data(rule, rnum, data, ratio);

		int ret = ip_matcher_match(matcher,&data,result,1000);

		printf("###################################\n");
		for(int j = 0; j < ret; j++)
		{
			printf("rule id = %u, rule interval = ",result[j].rule_id);
			int id = result[j].rule_id;
			uint128_t interval;
			uint128_t h(rule[id].end_ip);
			uint128_t l(rule[id].start_ip);
			interval = h - l;
			unsigned int a = (interval.I[1]>>32) & 0xFFFFFFFF;
			unsigned int b = interval.I[1] & 0xFFFFFFFF;
			unsigned int c = (interval.I[0]>>32) & 0xFFFFFFFF;
			unsigned int d = interval.I[0] & 0xFFFFFFFF;
			printf("%u::%u::%u::%u\n",a,b,c,d);

// 			for(int k = 3; k >= 0; k--)
// 			{
// 				int x = rule[id].end_ip[k] - rule[id].start_ip[k];
// 				if(x > 0)
// 				{
// 					interval[k] = x;
// 				}
// 				else
// 				{
// 					interval[k] = 0;			
// 				}
// 				printf("%u::", interval[k]);
// 			}
// 			printf("\n");
		}
		printf("###################################\n");

	}

	ip_matcher_free(matcher);	
	delete [] ip_array;
	delete [] rule;
}

int main(int argc, char *argv[])
{
	

// 	test_ipv4(100,0.1);
// 	test_ipv6(100,1);
	
	struct ipv6_range rule[2] = {0};
	rule[0].start_ip[0] = 5678;
	rule[0].start_ip[1] = 1234;
	rule[0].start_ip[2] = 0;
	rule[0].start_ip[3] = 0;

	rule[0].end_ip[0] = 5678;
	rule[0].end_ip[1] = 1235;
	rule[0].end_ip[2] = 0;
	rule[0].end_ip[3] = 0;

	rule[1].start_ip[0] = 5678;
	rule[1].start_ip[1] = 1234;
	rule[1].start_ip[2] = 0;
	rule[1].start_ip[3] = 1;

	rule[1].end_ip[0] = 5678;
	rule[1].end_ip[1] = 1234;
	rule[1].end_ip[2] = 0;
	rule[1].end_ip[3] = 5210;

	uint128_t a(rule[0].start_ip);
	uint128_t b(rule[0].end_ip);
	uint128_t c = b - a;

	uint128_t x(rule[1].start_ip);
	uint128_t y(rule[1].end_ip);
	uint128_t z = y - x;

	struct ip_data data;
	data.type = IPv6;
	data.ipv6[0] = 5678;
	data.ipv6[1] = 1234;
	data.ipv6[2] = 0;
	data.ipv6[3] = 5000;

	struct ip_rule ip_array[2];
	for(unsigned int i = 0; i < 2; i++)
	{
		ip_array[i].rule_id = i+103;
		ip_array[i].type = IPv6;;
		ip_array[i].user_tag = NULL;
		ip_array[i].ipv6_rule = rule[i];
	}

	size_t mem_use = 0;
	struct ip_matcher * matcher = ip_matcher_new(ip_array,2,&mem_use);
	if(matcher == NULL)
	{
		printf("ip_matcher_new() error!\n");
		exit(0);
	}	

	struct scan_result result[1000];
	int ret = ip_matcher_match(matcher,&data,result,1000);
	for(int i = 0; i < ret; i++)
	{
		printf("rule id = %u\n",result[i].rule_id);
	}

	ip_matcher_free(matcher);	


	return 1;
}
