rmdir /S /Q Release
rmdir /S /Q Debug
rmdir /S /Q ipch
rmdir /S /Q source\Debug
rmdir /S /Q source\Release
rmdir /S /Q source\Debug
rmdir /S /Q IPMatcher\Release
rmdir /S /Q IPMatcher\Debug
rmdir /S /Q test\Release
rmdir /S /Q test\Debug
rmdir /S /Q test\ipscan_tmp
del /S /Q lib\*
del /S /Q *.sdf
cd source\IntervalIndex
clean.bat