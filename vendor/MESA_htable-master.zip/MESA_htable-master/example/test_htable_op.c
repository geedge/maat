#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <assert.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif

#ifndef MALLOC_CHECK_
#define MALLOC_CHECK_ (1)
#endif

#define TEST_COMPLEX_KEY		(0)


#define KEY_STR_LEN			(100)
typedef struct{
#if TEST_COMPLEX_KEY
	char *key1;
	char *key2;
#endif	
	int key3;
	long key4;
}complex_key_t;


MESA_htable_handle htable;

#define MULTI_THREAD    (8)
#define HTABLE_SIZE     (1024 * 1024)

#define RAND_NUM_RANGE  (0xFFFF)

static volatile int insert_ok = 0, insert_err = 0;
static volatile int select_hit = 0, select_not_hit = 0;
static volatile int delete_hit = 0, delete_not_hit = 0;
static volatile int rdelete_hit = 0, rdelete_not_hit = 0; /* �ݹ�ɾ�� */
static volatile int tot_op_times = 0;

static int ins_n;
static int sel_n;
static int del_n; 

#if TEST_COMPLEX_KEY
void complex_key_free(uchar *key, uint key_size)
{
	complex_key_t *rkey = (complex_key_t *)key;
	free(rkey->key1);
	free(rkey->key2);
	free(rkey);
}

uchar* test_complex_key_dup(const uchar *key, uint key_size)
{
	complex_key_t *raw_key = (complex_key_t *)key;
	complex_key_t *new_key = (complex_key_t *)malloc(sizeof(complex_key_t));

	new_key->key1 = (char *)malloc(KEY_STR_LEN);
	memcpy(new_key->key1, raw_key->key1,KEY_STR_LEN);
	new_key->key2 = (char *)malloc(KEY_STR_LEN);
	memcpy(new_key->key2, raw_key->key2,KEY_STR_LEN);
	new_key->key3 = raw_key->key3;
	new_key->key4 = raw_key->key4;

	return (uchar *)new_key;
}
#endif

uint test_hash_key2index(const MESA_htable_handle table, const uchar * key, uint size)
{
		complex_key_t *raw_key = (complex_key_t *)key;

		return raw_key->key3 + raw_key->key4;
}

int test_key_cmp(const uchar * key1, uint size1, const uchar * key2, uint size2)
{
	complex_key_t *rkey1 = (complex_key_t *)key1;
	complex_key_t *rkey2 = (complex_key_t *)key2;

#if TEST_COMPLEX_KEY
	if(strncmp(rkey1->key1, rkey2->key1, KEY_STR_LEN) != 0){
		return -1;
	}

	if(strncmp(rkey1->key2, rkey2->key2, KEY_STR_LEN) != 0){
		return -1;
	}
#endif

	if(rkey1->key3 != rkey2->key3){
		return -1;
	}

	if(rkey1->key4 != rkey2->key4){
		return -1;
	}

	return 0;
}

int test_hash_data_expire_with_condition(void *data, int eliminate_type)
{
	return 0;
}

void my_free(void *data)
{
	free(data);
}

int test_hash_insert(int num)
{
	int ret;

	int *data = (int *)calloc(1, sizeof(int)*(rand()%1024) + sizeof(int)); /* ÿ�����벻�����ڴ� */

	complex_key_t ckey;
#if TEST_COMPLEX_KEY
	ckey.key1 = "hello";
	ckey.key2 = "world";
#endif	
	ckey.key3 = num;
	ckey.key4 = num;
	ret = MESA_htable_add(htable, (u_char *)&ckey, sizeof(complex_key_t), (void *)data);
	if(ret < 0){
		free(data);
		insert_err++;
		tot_op_times++;
		return -1;
	}

	insert_ok++;
	tot_op_times++;
	return 0;
}

static int test_hash_delete(int num)
{
	int ret;

	complex_key_t ckey;

	ckey.key3 = num;
	ckey.key4 = num;

	ret = MESA_htable_del(htable, (u_char *)&ckey, sizeof(complex_key_t), NULL);
	if(ret >= 0){
		delete_hit++;
		tot_op_times++;
		return 0;
	}

	delete_not_hit++;
	tot_op_times++;
	return -1;
}

static int test_hash_delete_manual(int num)
{
	int ret;

	del_n = num;
	ret = MESA_htable_del_oldest_manual(htable, NULL, 10);
	if(0 == ret){
		delete_hit++;
		tot_op_times++;
		return 0;
	}

	delete_not_hit++;
	tot_op_times++;
	return -1;
}

static long __sel_cb(void *data, const uchar *key, uint size, void *arg)
{
	if(0 == MESA_htable_del(arg, key, size, NULL)){
		rdelete_hit++;
	}else{
		rdelete_not_hit++;
	}
	tot_op_times++;

	return 0;
}

int test_hash_select(int num)
{
	void *ret;
	long cb_ret;
	sel_n = num;

	complex_key_t ckey;
#if TEST_COMPLEX_KEY
	ckey.key1 = "hello";
	ckey.key2 = "world";
#endif	
	ckey.key3 = num;
	ckey.key4 = num;
	ret = MESA_htable_search(htable, (u_char *)&ckey, sizeof(complex_key_t));


	if(ret != NULL){
	//if(MESA_htable_search_cb(htable, (u_char *)&sel_n, sizeof(int), __sel_cb, htable, &cb_ret)){
		//printf("%d is in hash-table!\n", n);
		select_hit++;
		tot_op_times++;
		return 0;
	}

	//printf("%d not in hash-table!\n", n);
	select_not_hit++;
	tot_op_times++;
	return -1;
}

void iterate_cb(const uchar * key, uint size, void * data, void *arg)
{
	int key2 = rand() % RAND_NUM_RANGE;

	if(0 == MESA_htable_del(htable, (uchar *)&key2, sizeof(int), NULL)){
		rdelete_hit++;
	}else{
		rdelete_not_hit++;
	}
	tot_op_times++;

	return;
}

int test_hash_iterate(void)
{
	MESA_htable_iterate(htable, iterate_cb, NULL);
}

#if MULTI_THREAD   

void *thread_iterate(void *arg)
{
	while(1){
		test_hash_iterate();
		//usleep(rand() % 100);
	}

	return NULL;
}

void *thread_insert(void *arg)
{
	while(1){
		test_hash_insert(rand() % RAND_NUM_RANGE);
		//usleep(rand() % 100);
	}

	return NULL;
}

void *thread_delete(void *arg)
{
	while(1){
		test_hash_delete(random() % RAND_NUM_RANGE);
		//usleep(rand() % 200 + 200);
	}

	return NULL;
}

void *thread_delete_manual(void *arg)
{
	while(1){
		test_hash_delete_manual(rand() % RAND_NUM_RANGE);
		//usleep(rand() % 200 + 200);
	}

	return NULL;
}

void *thread_select(void *arg)
{
	int times = 0;
	while(1){
		test_hash_select(rand() % RAND_NUM_RANGE);
	}

	return NULL;
}
#else
void *single_thread(void *arg)
{
    int n, times = 0;
    while(1)
    {
        n = random() % 5;
        switch(n)
        {
            case 0:
                test_hash_insert(rand() % RAND_NUM_RANGE);
            break;

            case 1:
            case 3:
            case 4:
                test_hash_delete(rand() % RAND_NUM_RANGE);
            break;

            case 2:
                test_hash_select(rand() % RAND_NUM_RANGE);
            break;

            default:
                test_hash_select(rand() % RAND_NUM_RANGE);
            break;
        }
        
        //usleep(n);
        //if(times++ > 999)
        if(0)
        {
            printf("select thread exit!\n");
            pthread_exit(NULL);
        }
    }

    return NULL;
}


#endif

void *thread_print(void *arg)
{
    int n;

    while(1)
    {     
        printf("\ntotal element=%u, \ntotal-op-times:%u pps, \nop-detail:\n", MESA_htable_get_elem_num(htable),  tot_op_times);
      
        tot_op_times = 0;
        printf("\tOK : ins=%d, sel=%d, del=%d, rdel=%d\n", insert_ok, select_hit, delete_hit, rdelete_hit);
        printf("\tERR: ins=%d, sel=%d, del=%d, rdel=%d\n", insert_err, select_not_hit, delete_not_hit, rdelete_not_hit);

        srand(time(NULL));
        
        usleep(1000 * 990);
    }

    return NULL;
}


static void test_hash_functionality(void)
{
	int i, ret;
	void *res;
	void *phony_data;
	complex_key_t ckey;

	memset(&ckey, 0, sizeof(complex_key_t));

	for(i =0 ; i < 100; i++){
		ckey.key3 = i;
		ckey.key4 = i;
		phony_data = malloc(1);
		ret = MESA_htable_add(htable, (uchar *)&ckey, sizeof(complex_key_t), phony_data);
		assert(ret >= 0);
		printf("MESA_htable_add: %d, ret = %d\n", i, ret);
	}
	printf("after MESA_htable_add(), item is:%u\n", MESA_htable_get_elem_num(htable));

	for(i =0 ; i < 100; i++){
		ckey.key3 = i;
		ckey.key4 = i;
		res = MESA_htable_search(htable, (uchar *)&ckey, sizeof(complex_key_t));
		assert(res != NULL);
		printf("MESA_htable_search: %d\n", i);
	}
	
	for(i =0 ; i < 100; i++){
		ckey.key3 = i;
		ckey.key4 = i;
		ret = MESA_htable_del(htable, (uchar *)&ckey, sizeof(complex_key_t), NULL);
		assert(0 == ret);
		printf("MESA_htable_del: %d\n", i);
	}
	printf("after MESA_htable_del(), item is:%u\n", MESA_htable_get_elem_num(htable));

	sleep(3);
}



int main(void)
{
	pthread_t t[20];
	MESA_htable_create_args_t hargs;

	srand(time(NULL));

	memset(&hargs, 0, sizeof(MESA_htable_create_args_t));

	hargs.thread_safe = 0;
	hargs.hash_slot_size = HTABLE_SIZE;
	hargs.max_elem_num = RAND_NUM_RANGE + 1000;
	hargs.eliminate_type = HASH_ELIMINATE_ALGO_LRU;
	hargs.expire_time = 100;
#if TEST_COMPLEX_KEY
	hargs.complex_key_dup = test_complex_key_dup;
	hargs.complex_key_free = complex_key_free;
#endif	
	hargs.key_comp = test_key_cmp;

	hargs.key2index = test_hash_key2index;
	hargs.data_free = my_free;
	hargs.data_expire_with_condition = test_hash_data_expire_with_condition;

#if MULTI_THREAD
	hargs.thread_safe = 512;
	hargs.recursive = 1;
	htable = MESA_htable_create(&hargs, sizeof(MESA_htable_create_args_t));
	if(NULL == htable){
		return -1;
	}

	MESA_htable_print_crtl(htable, 0);


	test_hash_functionality();
	
    
	pthread_create(&t[0], NULL, thread_insert, NULL);    
	//pthread_create(&t[1], NULL, thread_insert, NULL); 
	//pthread_create(&t[2], NULL, thread_insert, NULL); 
	//pthread_create(&t[3], NULL, thread_insert, NULL); 
	//pthread_create(&t[4], NULL, thread_insert, NULL); 

	pthread_create(&t[5], NULL, thread_select, NULL);    
	//pthread_create(&t[6], NULL, thread_select, NULL); 
	//pthread_create(&t[7], NULL, thread_select, NULL); 
	//pthread_create(&t[8], NULL, thread_select, NULL); 
	//pthread_create(&t[9], NULL, thread_select, NULL); 

	//pthread_create(&t[10], NULL, thread_delete, NULL); 
	//pthread_create(&t[11], NULL, thread_delete, NULL);
	//pthread_create(&t[12], NULL, thread_delete_manual, NULL);
	//pthread_create(&t[13], NULL, thread_iterate, NULL);
	//pthread_create(&t[14], NULL, thread_iterate, NULL);
#else
	hargs.thread_safe = 100;
	htable = MESA_htable_create(&hargs, sizeof(MESA_htable_create_args_t));
	//MESA_hash_create(&htable, 0, HTABLE_SIZE, NULL, NULL, my_free, HASH_ELIMINATE_ALGO_FIFO, 3);

	test_hash_functionality();
	
	pthread_create(&t[15], NULL, single_thread, NULL);
#endif

	pthread_create(&t[16], NULL, thread_print, NULL);  

	MESA_htable_print_crtl(htable, 0);

	while(1) {
		sleep(1);
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif


