#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>
#include "MESA_list_queue.h"

#define CUSTOM_THREAD_NUM   (1)
#define PRODUCT_THREAD_NUM   (1)

struct timeval cur_time;
MESA_lqueue_head QUEUE;

void *producer_thread(void *arg)
{
    int i, ret, count = 0;
    char data[1000];
    long data_len;

    for(i = 0; i < 1000; i++)
    //while(1)
    {
        data_len = rand() % 999 + 1;
        ret = MESA_lqueue_join_tail(QUEUE, data, data_len);
        //MESA_lqueue_try_join_tail(QUEUE, data, data_len);

        if(ret == 0){
		count++;
		if(count == 1000){
			printf("post join queue num:%6ld, mem used:%10ld\n", MESA_lqueue_get_count(QUEUE), MESA_lqueue_get_mem_used(QUEUE));
			//sleep(100);
		}
        }else{
		printf("%s\n", MESA_lqueue_strerror(ret));
        }
    }

    return NULL;
}

void *customer_thread(void *arg)
{
    int i=0, ret, count = 0;
    char data[1000];
    long data_len;


    sleep(3);
    printf("pre get queue num:%6ld, mem used:%10ld\n", MESA_lqueue_get_count(QUEUE), MESA_lqueue_get_mem_used(QUEUE));
    
    //for(i = 0; i < 100000; i++)
    while(1)
    {
        data_len = 1000;
        ret = MESA_lqueue_try_get_head(QUEUE, data, &data_len);
        //ret = MESA_lqueue_try_get_head(QUEUE, data, &data_len);
        //ret = MESA_lqueue_read_head(QUEUE, data, &data_len);
        //if((MESA_QUEUE_RET_OK == ret) && (i++ > 10000))

        if(ret == 0){
		count++;
		if(count == 1000){
			printf("get, queue num is %d\n", 1000);

			printf("post get queue num:%6ld, mem used:%10ld\n", MESA_lqueue_get_count(QUEUE), MESA_lqueue_get_mem_used(QUEUE));
			//sleep(1000);
		}
        }else{
		MESA_lqueue_destroy(QUEUE, NULL, NULL);
		exit(0);
        }
    }

    return NULL;
}

int main(void)
{
    void *tmp;
    int i, ret;
    pthread_t p_tid[PRODUCT_THREAD_NUM], c_tid[CUSTOM_THREAD_NUM];


    QUEUE = MESA_lqueue_create(1, 100000);
    if(NULL == QUEUE)
    {
        return -1;
    }

    printf("#init, queue num:%ld\n", MESA_lqueue_get_count(QUEUE));

    srand(time(NULL));

    for(i = 0; i < PRODUCT_THREAD_NUM; i++)
    {
        pthread_create(&p_tid[i], NULL, producer_thread, NULL);
    }

    for(i = 0; i < CUSTOM_THREAD_NUM; i++)
    {
        pthread_create(&c_tid[i], NULL, customer_thread, NULL);
    }

    for(i = 0; i < PRODUCT_THREAD_NUM; i++)
    {
        pthread_join(p_tid[i], NULL);
    }
    for(i = 0; i < CUSTOM_THREAD_NUM; i++)
    {
        pthread_join(c_tid[i], NULL);
    }
    
    MESA_lqueue_destroy(QUEUE, NULL, NULL);
    
    return 0;
}


#ifdef __cplusplus
}
#endif

