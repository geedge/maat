#include "MESA_ring_queue.h"
#include "MESA_list_queue.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/time.h>


#ifdef __cplusplus
extern "C"
{
#endif

#define USE_LQUEUE		(0)
#define ITEM_LEN		(1024)
#define ITEM_NUM		(10000000)

#if USE_LQUEUE
static MESA_lqueue_head VSQUEUE;
#else
static MESA_ring_queue_head VSQUEUE;
#endif


static struct timeval start_time, end_time;

void *queue_producter(void *arg)
{
	int i;
	char data[ITEM_LEN];
	
	//while(1)
	{
		for(i = 0; i <= ITEM_NUM; i++){
#if USE_LQUEUE	
			MESA_lqueue_join_tail(VSQUEUE, data, ITEM_LEN);
#else
			MESA_ring_queue_join(VSQUEUE, data, ITEM_LEN);
#endif			
		}
	}

	while(1){
	pause();
	}

	return NULL;
}

void *queue_customer(void *arg)
{
	int ret, item_num = 0;

#if USE_LQUEUE	
	long data_len;
#else
	int data_len;
#endif
	char data[ITEM_LEN];
	
	while(1){
		data_len = ITEM_LEN;
#if USE_LQUEUE	
		ret = MESA_lqueue_get_head(VSQUEUE, data, &data_len);
#else
		ret = MESA_ring_queue_get(VSQUEUE, data, &data_len);
#endif
		if(ret == 0){
			item_num++;
			//printf("data:%p, num:%d\n", data, item_num);
			if(item_num >= ITEM_NUM){
				gettimeofday(&end_time, NULL);
				printf("time:%ld ms\n", 
				       (end_time.tv_sec * 1000 + end_time.tv_usec/1000) - 
				       (start_time.tv_sec * 1000 + start_time.tv_usec/1000));
				exit(0);
			}
		}
	}

	return NULL;

}


int main(void)
{
	pthread_t pid;

#if USE_LQUEUE	
	VSQUEUE = MESA_lqueue_create(1, ITEM_NUM+2);
#else
	VSQUEUE = MESA_ring_queue_born();

	int opt = ITEM_LEN;
	MESA_ring_queue_set_opt(VSQUEUE, RQO_PRE_ALLOC_BUF_LEN, &opt, sizeof(int));

	opt = 100000;
	MESA_ring_queue_set_opt(VSQUEUE, RQO_RING_ELEMENT_NUM, &opt, sizeof(int));
	
	MESA_ring_queue_mature(VSQUEUE);
#endif

	gettimeofday(&start_time, NULL);

	pthread_create(&pid, NULL, queue_producter, NULL);
	pthread_create(&pid, NULL, queue_customer, NULL);

	while(1){
		pause();
	}

	return 0;
}

#ifdef __cplusplus
}
#endif


