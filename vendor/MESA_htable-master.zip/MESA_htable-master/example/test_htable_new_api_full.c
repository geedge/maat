#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <assert.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif

#define MIN_NUM		(0)
#define MAX_NUM		(0x7fffffff)

static MESA_htable_handle htable;

static long add_times, search_times, del_times;

static void fstack4(MESA_htable_handle shtable, const uchar *key, uint key_len, const void *data)
{
	MESA_htable_add(shtable, key, key_len, data);
}

static void fstack3(MESA_htable_handle shtable, const uchar *key, uint key_len, const void *data)
{
	fstack4(shtable, key, key_len, data);
}

static void fstack2(MESA_htable_handle shtable, const uchar *key, uint key_len, const void *data)
{
	fstack3(shtable, key, key_len, data);
}

static void fstack1(MESA_htable_handle shtable, const uchar *key, uint key_len, const void *data)
{
	fstack2(shtable, key, key_len, data);
}


static void *thread_insert(void *arg)
{
	int i;
	
	while(1){
		for(i = MIN_NUM; i <= MAX_NUM; i++){
			fstack1(htable, (const uchar *)&i, sizeof(int), NULL);
			add_times++;
		}
	}

	return NULL;
}

static void *thread_select(void *arg)
{
	int i;
	int max_times;
	double avg_times;
	int len;
	
	while(1){
		for(i = MIN_NUM; i < MAX_NUM/2; i++){
			MESA_htable_search(htable, (const uchar *)&i, sizeof(int));
			search_times++;
		}
		for(i = MAX_NUM/2+1; i <= MAX_NUM; i++){
			MESA_htable_search(htable, (const uchar *)&i, sizeof(int));
			search_times++;
		}		

		len = sizeof(int);
		MESA_htable_get_opt(htable, MHO_HASH_SEARCH_MAX_TIMES, &max_times, &len);
		printf("max times:%d\n", max_times);
		
		len = sizeof(double);
		MESA_htable_get_opt(htable, MHO_HASH_SEARCH_AVG_TIMES, &avg_times, &len);
		printf("avg times:%.3f\n", avg_times);
	}

	return NULL;
}

static void *thread_delete(void *arg)
{
	int i ;
	
	while(1){
		for(i = MAX_NUM-1; i > MIN_NUM; i--){
			MESA_htable_del(htable, (const uchar *)&i, sizeof(int), NULL);
			del_times++;
		}
	}

	return NULL;
}

static void *thread_print(void *arg)
{
    int n;
    long this_op_times = 0, last_op_times = 0;

    while(1)
    {     
    	this_op_times = add_times+search_times+del_times;
        printf("\ntotal element=%u, total op times=%ld, op/s=%ld\n", MESA_htable_get_elem_num(htable), this_op_times, this_op_times-last_op_times);
        last_op_times = this_op_times;
        sleep(1);
	}

	return NULL;
}
int main(void)
{
	int ret;
	int opt_int;
	pthread_t pid;
	
	htable = MESA_htable_born();
	assert(htable != NULL);

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_THREAD_SAFE, &opt_int, sizeof(int));

	opt_int = 128;
	MESA_htable_set_opt(htable, MHO_MUTEX_NUM, &opt_int, sizeof(int));

	opt_int = 1048576;
	MESA_htable_set_opt(htable, MHO_HASH_SLOT_SIZE, &opt_int, sizeof(int));

	opt_int = 99999;
	MESA_htable_set_opt(htable, MHO_HASH_MAX_ELEMENT_NUM, &opt_int, sizeof(int));

	opt_int = 10;
	MESA_htable_set_opt(htable, MHO_EXPIRE_TIME, &opt_int, sizeof(int));

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_AUTO_UPDATE_TIME, &opt_int, sizeof(int));

	opt_int = 0;
	MESA_htable_set_opt(htable, MHO_SCREEN_PRINT_CTRL, &opt_int, sizeof(int));

	opt_int = HASH_ELIMINATE_ALGO_LRU;
	MESA_htable_set_opt(htable, MHO_ELIMIMINATE_TYPE, &opt_int, sizeof(int));	

	opt_int = 5;
	MESA_htable_set_opt(htable, MHO_HASH_LIST_COLLIDE_THRESHOLD, &opt_int, sizeof(int));	

	char *err_log = "./test_hash_collide.log";
	MESA_htable_set_opt(htable, MHO_HASH_LOG_FILE, err_log, strlen(err_log));	
	
	ret = MESA_htable_mature(htable);
	if(0 == ret){
		printf("MESA_htable_mature success!\n");
	}else{
		printf("MESA_htable_mature error!\n");
		return -1;
	}

	pthread_create(&pid, NULL, thread_insert, NULL);  
	usleep(10000);
	pthread_create(&pid, NULL, thread_select, NULL);  
	pthread_create(&pid, NULL, thread_delete, NULL);  

	pthread_create(&pid, NULL, thread_print, NULL);  
	
	while(1){
		pause();
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif




