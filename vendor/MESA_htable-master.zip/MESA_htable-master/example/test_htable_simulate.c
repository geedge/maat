#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <assert.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif

#define HTABLE_ITEM_NUM  (1000000)

const char *G_HTABLE_ITEM_ARRAY[HTABLE_ITEM_NUM];
char G_HTABLE_ITEM_LEN[HTABLE_ITEM_NUM];
static volatile int insert_succ_flag = 0;
static MESA_htable_handle htable;

static long add_times, search_times, del_times;


static inline void rand_data(char *data, int len)
{
	int i;
	for(i = 0; i < len; i++){
		data[i] = (char)rand();
	}
}

static void *thread_insert(void *arg)
{
	int i, ret;
	int randval;
	void *pdata;
	int max_hash_collide = 0;
	
	for(i = 0; i < HTABLE_ITEM_NUM; i++){
		randval = rand() % 1000 + 10;
		pdata = malloc(randval);
		rand_data(pdata, randval);
		ret = MESA_htable_add(htable, pdata, randval, pdata);
		assert(ret >= 0);
		if(ret > max_hash_collide){
			max_hash_collide = ret;
			printf("Max hash collide = %d\n", max_hash_collide);
		}
		G_HTABLE_ITEM_ARRAY[i] = pdata;
		G_HTABLE_ITEM_LEN[i] = randval;
	}

	insert_succ_flag = 1;
	
	while(1){
		pause();
	}

	return NULL;
}

static void *thread_select(void *arg)
{
	int i;
	void *res;
	int max_times;
	double avg_times;
	int len;
	int randval;
	
	while(1){
		for(i = 0; i < HTABLE_ITEM_NUM; i++){
			randval = rand() % HTABLE_ITEM_NUM; /* �������, ģ��ʵ����� */
			if(randval < 0){
				randval = 0;
			}
			res = MESA_htable_search(htable, (const uchar *)G_HTABLE_ITEM_ARRAY[randval], G_HTABLE_ITEM_LEN[randval]);
			assert(res != NULL);		
			search_times++;

#if 1 /* �ٴβ�ѯ��ͬ����, ���ʹ��bucket-LRU, �ܴ���ʵ�һ�ξ����� */
			res = MESA_htable_search(htable, (const uchar *)G_HTABLE_ITEM_ARRAY[randval], G_HTABLE_ITEM_LEN[randval]);
			assert(res != NULL);		
			search_times++;
#else /* �ٴβ�ѯ��ͬ���� */
			randval = rand() % HTABLE_ITEM_NUM; /* �������, ģ��ʵ����� */
			res = MESA_htable_search(htable, (const uchar *)G_HTABLE_ITEM_ARRAY[randval], G_HTABLE_ITEM_LEN[randval]);
			assert(res != NULL);		
			search_times++;
#endif
		}

		len = sizeof(int);
		MESA_htable_get_opt(htable, MHO_HASH_SEARCH_MAX_TIMES, &max_times, &len);
		printf("max times:%d\n", max_times);
		
		len = sizeof(double);
		MESA_htable_get_opt(htable, MHO_HASH_SEARCH_AVG_TIMES, &avg_times, &len);
		printf("avg times:%.3f\n", avg_times);
	}

	return NULL;
}

static void *thread_print(void *arg)
{
    int n;
    long this_op_times = 0, last_op_times = 0;

    while(1)
    {     
    	this_op_times = add_times+search_times+del_times;
        printf("\ntotal element=%u, total op times=%ld, op/s=%ld\n", MESA_htable_get_elem_num(htable), this_op_times, this_op_times-last_op_times);
        last_op_times = this_op_times;
        sleep(1);
	}

	return NULL;
}
int main(void)
{
	int ret;
	int opt_int;
	pthread_t pid;

	srand(time(NULL));
	
	htable = MESA_htable_born();
	assert(htable != NULL);

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_THREAD_SAFE, &opt_int, sizeof(int));

	opt_int = 512;
	MESA_htable_set_opt(htable, MHO_MUTEX_NUM, &opt_int, sizeof(int));

	opt_int = 1048576;
	MESA_htable_set_opt(htable, MHO_HASH_SLOT_SIZE, &opt_int, sizeof(int));

	opt_int = HTABLE_ITEM_NUM+1;
	MESA_htable_set_opt(htable, MHO_HASH_MAX_ELEMENT_NUM, &opt_int, sizeof(int));

	opt_int = 0;
	MESA_htable_set_opt(htable, MHO_EXPIRE_TIME, &opt_int, sizeof(int));

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_AUTO_UPDATE_TIME, &opt_int, sizeof(int));

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_SCREEN_PRINT_CTRL, &opt_int, sizeof(int));

	opt_int = HASH_ELIMINATE_ALGO_LRU;
	MESA_htable_set_opt(htable, MHO_ELIMIMINATE_TYPE, &opt_int, sizeof(int));	

	opt_int = 0;
	MESA_htable_set_opt(htable, MHO_HASH_LIST_COLLIDE_THRESHOLD, &opt_int, sizeof(int));	

	char *err_log = "./test_hash_collide.log";
	MESA_htable_set_opt(htable, MHO_HASH_LOG_FILE, err_log, strlen(err_log));	
	
	ret = MESA_htable_mature(htable);
	if(0 == ret){
		printf("MESA_htable_mature success!\n");
	}else{
		printf("MESA_htable_mature error!\n");
		return -1;
	}

	pthread_create(&pid, NULL, thread_insert, NULL);  
	while(0 == insert_succ_flag){
		usleep(1); /* �������ݲ����̲߳���������� */
	}
	pthread_create(&pid, NULL, thread_select, NULL);  
	//pthread_create(&pid, NULL, thread_delete, NULL);  

	pthread_create(&pid, NULL, thread_print, NULL);  
	
	while(1){
		pause();
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif





