#include <semaphore.h>
#include <stdio.h>
#include <pthread.h>

static int sem_val;
static long long wait_num, post_num;
static sem_t sem;

void *sem_perf_thread(void *a)
{
	long long last_wait_num, last_post_num;
	
	while(1){
		sem_getvalue(&sem, &sem_val);
		printf("sem wait pps:%lld, post pps:%lld, sem_val = %d\n",  
			wait_num - last_wait_num, 
			post_num - last_post_num, 
			sem_val);
		last_wait_num = wait_num;
		last_post_num = post_num;

		sleep(1);
	}

	return NULL;
}

void *sem_wait_thread(void *a)
{
	while(1){
		sem_wait(&sem);
		wait_num++;
	}

	return NULL;
}

void *sem_post_thread(void *a)
{
	while(1){
		sem_post(&sem);
		post_num++;
	}

	return NULL;
}

int main(void)
{
	pthread_t pid;
	
	if(sem_init(&sem, 0, 0) < 0){
		return -1;
	}

	pthread_create(&pid, NULL, sem_wait_thread, NULL);
	pthread_create(&pid, NULL, sem_post_thread, NULL);

	pthread_create(&pid, NULL, sem_perf_thread, NULL);

	while(1){
		pause();
	}

	return 0;
}

