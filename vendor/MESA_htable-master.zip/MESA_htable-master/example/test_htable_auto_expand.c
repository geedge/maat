#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <assert.h>
#include "MESA_htable.h"
#include "MESA_htable_internal.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define MIN_NUM		(0)
#define MAX_NUM		(9999999)

static MESA_htable_handle htable;

static multi_thread_cache_align_t add_times[64], search_times[64], del_times;

static volatile int add_fin_flag = 0;

static unsigned int *global_hitem_array;

#define MULTI_INSERT_THREAD_NUM		(4)

static void *thread_insert(void *arg)
{
	int i, ret;
	long tid = (long )arg;
	
	while(1){
		for(i = MIN_NUM; i < MAX_NUM; i++){
			ret = MESA_htable_add(htable, (const uchar *)&i, sizeof(int), (void *)&global_hitem_array[i]);
			if(ret < 0){
				assert(ret == MESA_HTABLE_RET_DUP_ITEM);
			}
		}

		usleep(rand() % 100 + 100);
		
		add_fin_flag = MULTI_INSERT_THREAD_NUM; /* Ԫ�ز�����ɱ�־ */

		while(1){
			pause();
		}
	}

	return NULL;
}

static long search_cb(void *data, const uchar *key, uint size, void *user_arg)
{
	return 0;
}

static void *thread_select(void *arg)
{
	int i;
	void *res;
	int max_times;
	double avg_times;
	int len;
	long cb_ret;
	long tid = (long)arg;

	while(add_fin_flag < MULTI_INSERT_THREAD_NUM){
		usleep(10); /* �����ȴ��������ݲ���HTABLE */
	}

	usleep(rand() % 100000);
	
	while(1){
		for(i = MIN_NUM; i < MAX_NUM; i++){
			res = MESA_htable_search_cb(htable, (const uchar *)&i, sizeof(int), search_cb, NULL, &cb_ret);
			assert(res != NULL);
			search_times[tid].long_val++;
		}
	}

	return NULL;
}


static void *thread_print(void *arg)
{
	int i, n;
	long this_op_times = 0, last_op_times = 0;
	long cur_search_times = 0;

	while(1){
		cur_search_times = 0;
		for(i = 0; i < 64; i++){
			cur_search_times += search_times[i].long_val;
		}
		
		this_op_times = cur_search_times;
		printf("\ntotal element=%u, total op times=%ld, op/s=%ld\n",  
		        MESA_htable_get_elem_num(htable), this_op_times, this_op_times-last_op_times);
		last_op_times = this_op_times;
		sleep(1);
	}

	return NULL;
}

static void data_free_cb_fun(void *data)
{
	printf("%d expired, del it!\n", *((int *)data));
}

int main(void)
{
	int ret;
	int opt_int;
	pthread_t pid;
	long tid;
	
	htable = MESA_htable_born();
	assert(htable != NULL);

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_THREAD_SAFE, &opt_int, sizeof(int));

	opt_int = 512;
	MESA_htable_set_opt(htable, MHO_MUTEX_NUM, &opt_int, sizeof(int));

	/* ��ʼ��Сֵ, ��ͻ��Ԫ����������MHO_HASH_LIST_COLLIDE_THRESHOLD��, �Զ���չ */
	opt_int = 128;
	MESA_htable_set_opt(htable, MHO_HASH_SLOT_SIZE, &opt_int, sizeof(int));

	opt_int = MAX_NUM;
	MESA_htable_set_opt(htable, MHO_HASH_MAX_ELEMENT_NUM, &opt_int, sizeof(int));


#if 1
	MESA_htable_set_opt(htable, MHO_CBFUN_KEY_TO_INDEX, &BKDR_hash_algo, sizeof(void *));
#elif 0
	MESA_htable_set_opt(htable, MHO_CBFUN_KEY_TO_INDEX, &APHash_algo, sizeof(void *));
#elif 0
	MESA_htable_set_opt(htable, MHO_CBFUN_KEY_TO_INDEX, &murmur3_32_algo, sizeof(void *));
#endif

	MESA_htable_set_opt(htable, MHO_CBFUN_DATA_FREE, &data_free_cb_fun, sizeof(void *));

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_AUTO_UPDATE_TIME, &opt_int, sizeof(int));

	opt_int = 1;
	MESA_htable_set_opt(htable, MHO_SCREEN_PRINT_CTRL, &opt_int, sizeof(int));

	opt_int = 0;
	MESA_htable_set_opt(htable, MHO_EXPIRE_TIME, &opt_int, sizeof(int));
	
	opt_int = HASH_ELIMINATE_ALGO_LRU;
	MESA_htable_set_opt(htable, MHO_ELIMIMINATE_TYPE, &opt_int, sizeof(int));	

	opt_int = 20;
	MESA_htable_set_opt(htable, MHO_HASH_LIST_COLLIDE_THRESHOLD, &opt_int, sizeof(int));	

	opt_int = 1024;
	MESA_htable_set_opt(htable, MHO_AUTO_EXPAND_MULTIPLE, &opt_int, sizeof(int));	
	

	char *err_log = "./test_hash_collide.log";
	MESA_htable_set_opt(htable, MHO_HASH_LOG_FILE, err_log, strlen(err_log));	
	
	ret = MESA_htable_mature(htable);
	if(0 == ret){
		printf("MESA_htable_mature success!\n");
	}else{
		printf("MESA_htable_mature error!\n");
		return -1;
	}

	/* ��ʼ��������Ԫ��, ���⶯̬malloc/free */
	global_hitem_array = (unsigned int *)malloc(sizeof(int) * MAX_NUM);
	unsigned int i;
	for(i = 0; i < MAX_NUM; i++){
		global_hitem_array[i] = i;
	}

	/* ģ�����߳�ͬʱ��������, �������bit����, [0-15] */
	for(tid = 0; tid < 1; tid++){
		pthread_create(&pid, NULL, thread_insert, (void *)tid);  
	}
	
	usleep(10000);
	/* ģ�����߳�ͬʱ�������� */
	for(tid = 0; tid < MULTI_INSERT_THREAD_NUM; tid++){
		pthread_create(&pid, NULL, thread_select, (void *)tid);  
	}

	pthread_create(&pid, NULL, thread_print, NULL);  
	
	while(1){
		pause();
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif


