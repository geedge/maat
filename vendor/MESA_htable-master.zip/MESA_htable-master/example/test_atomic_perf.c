
#include <stdio.h>
#include <pthread.h>
#include "MESA_atomic.h"

static long long read_num[64], write_num[64];
static MESA_ATOMIC_T atomic_num;

void *atomic_perf_thread(void *a)
{
	int i;
	long long tot_read_num = 0, tot_write_num = 0;
	long long last_read_num, last_write_num;
	
	while(1){
		tot_read_num = 0;
		tot_write_num = 0;
		for(i = 0; i < 64; i++){
			tot_read_num += read_num[i];
			tot_write_num += write_num[i];
		}
	
		printf("atomic read pps:%lld,  write = %lld\n",  
			tot_read_num - last_read_num, 
			tot_write_num - last_write_num);
		last_read_num = tot_read_num;
		last_write_num = tot_write_num;

		sleep(1);
	}

	return NULL;
}

void *atomic_read_thread(void *arg)
{
	long tid = (long )arg;
	while(1){
		MESA_ATOMIC_READ(atomic_num);
		read_num[tid]++;
	}

	return NULL;
}

void *atomic_write_thread(void *arg)
{
	long tid = (long )arg;
	while(1){
		MESA_ATOMIC_INC(atomic_num);
		write_num[tid]++;
	}

	return NULL;
}

int main(void)
{
	pthread_t pid;
	
	MESA_ATOMIC_SET(atomic_num, 0);

	pthread_create(&pid, NULL, atomic_read_thread, (void *)0);
	pthread_create(&pid, NULL, atomic_read_thread, (void *)1);
	pthread_create(&pid, NULL, atomic_read_thread, (void *)2);
	pthread_create(&pid, NULL, atomic_write_thread, (void *)0);

	pthread_create(&pid, NULL, atomic_perf_thread, NULL);

	while(1){
		pause();
	}

	return 0;
}

