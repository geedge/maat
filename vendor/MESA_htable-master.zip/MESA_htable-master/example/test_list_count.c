#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <assert.h>
#include <sys/time.h>
#include "MESA_list_count.h"


#define LCOUNT_NUM 100

static struct MESA_list_count g_test_lcount_head;

struct MESA_list_count *create_new_lcount_item(long n)
{
	struct MESA_list_count *tmp;

	tmp = (struct MESA_list_count  *)malloc(sizeof(struct MESA_list_count ));

	tmp->quiddity = (void *)n;

	return tmp;
}

static void test_lcount_iterate(void)
{
	struct MESA_list_count *tmp_lcount =  g_test_lcount_head.nextele;

	while(tmp_lcount != &g_test_lcount_head){
		printf("%lld\n", (long )tmp_lcount->quiddity);
		tmp_lcount = tmp_lcount->nextele;
	}
}

int main(void)
{
	int i;
	struct MESA_list_count *tmp_lcount;
	
	MESA_list_count_init_head(&g_test_lcount_head);

	for(i = 0; i < LCOUNT_NUM; i++){
		tmp_lcount = create_new_lcount_item(i);
		switch(i % 4){
			case 0:
				MESA_list_count_add(&g_test_lcount_head, tmp_lcount);
			break;
			
			case 1:
				MESA_list_count_add_tail(&g_test_lcount_head, tmp_lcount);
			break;	
			
			case 2:
				MESA_list_count_add_tail(&g_test_lcount_head, tmp_lcount);
				MESA_list_count_move(&g_test_lcount_head, tmp_lcount);
			break;	
			
			case 3:
				MESA_list_count_add(&g_test_lcount_head, tmp_lcount);
				MESA_list_count_move_tail(&g_test_lcount_head, tmp_lcount);			
		}
	}

	assert(LCOUNT_NUM == MESA_list_count_get_count(&g_test_lcount_head));

	test_lcount_iterate();

	return 0;
}

#ifdef __cplusplus
}
#endif
