#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif


#define PERF_THREAD_NUM    (8)
#define HTABLE_SIZE     (1024 * 1024)
#define HASH_PERF_TEST_NUM	(5000000)

static MESA_htable_handle perf_test_htable;


typedef struct{
	unsigned long long hash_search_ok_num;
	unsigned long long hash_search_not_found_num;
	long long pad[6]; /* 64�ֽ�cache���� */
}hash_perf_test_stat_t;


static hash_perf_test_stat_t HASH_PERF_TEST_STAT[PERF_THREAD_NUM];



int test_hash_insert_perf(int num)
{
	int ret;
	static void *data = (void *)0x6620894;

	ret = MESA_htable_add(perf_test_htable, (u_char *)&num, sizeof(int), (void *)data);
	if(ret < 0){
		return -1;
	}

	return 0;
}



static void *thread_select_perf(void *arg)
{	
	int i, tid;
	void *ret;

	tid = *((int *)arg);
	while(1){
		for(i = 0; i < 0x7ffffffff; i++){
			ret = MESA_htable_search(perf_test_htable, (const uchar *)&i, sizeof(int));
			if(NULL == ret){
				HASH_PERF_TEST_STAT[tid].hash_search_not_found_num++;
			}else{
				HASH_PERF_TEST_STAT[tid].hash_search_ok_num++;
			}
		}
	}

	return NULL;
}

static void *thread_print_for_test_perf(void *arg)
{
    int i;
    time_t last_time = time(NULL);
    unsigned long long new_search_time, last_search_time = 0;

    while(1)
    {     
    	if(last_time < time(NULL)){
    		new_search_time = 0;
		for(i = 0; i < PERF_THREAD_NUM; i++){
			new_search_time += HASH_PERF_TEST_STAT[i].hash_search_ok_num;
			new_search_time += HASH_PERF_TEST_STAT[i].hash_search_not_found_num;
		}
	        printf("\ntotal element=%u,\nhash op perf:%llu pps\n", MESA_htable_get_elem_num(perf_test_htable),  new_search_time-last_search_time);
	        last_time = time(NULL);
	        last_search_time = new_search_time;
        }
        usleep(100);
    }

    return NULL;
}

void my_free(void *data)
{
	free(data);
}

int main(void)
{
	pthread_t ptid[PERF_THREAD_NUM];
	int thread_seq[PERF_THREAD_NUM];
	MESA_htable_create_args_t hargs;
	int i;

	srand(time(NULL));

	memset(&hargs, 0, sizeof(MESA_htable_create_args_t));
	hargs.thread_safe = 100;
	hargs.recursive = 1;
	hargs.hash_slot_size = HTABLE_SIZE;
	hargs.max_elem_num = 100*HTABLE_SIZE;
	hargs.eliminate_type = HASH_ELIMINATE_ALGO_LRU;
	hargs.expire_time = 0;
	hargs.key2index = NULL;
	hargs.data_free = my_free;
	hargs.data_expire_with_condition = NULL;

	perf_test_htable = MESA_htable_create(&hargs, sizeof(MESA_htable_create_args_t));
	if(NULL == perf_test_htable){
		return -1;
	}

	MESA_htable_print_crtl(perf_test_htable, 0);

	printf("please wait for preprocess data......\n");
	for(i = 0; i < HASH_PERF_TEST_NUM; i++){
		test_hash_insert_perf(i);/* Ԥ�Ȳ������� */
	}
	printf("preprocess data success!\n\n");
	
	pthread_create(&ptid[0], NULL, thread_print_for_test_perf, NULL); 

	for(i = 0; i < PERF_THREAD_NUM; i++){
		thread_seq[i] = i; 
		pthread_create(&ptid[i], NULL, thread_select_perf, &thread_seq[i]);   
	}

	while(1) {
		sleep(1);
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif



