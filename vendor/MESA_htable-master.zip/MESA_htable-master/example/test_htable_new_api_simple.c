#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <assert.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif

static MESA_htable_handle htable;


int main(void)
{
	int ret;
	
	htable = MESA_htable_born();
	assert(htable != NULL);

	/* don't use MESA_htable_set_opt(), use default args. */
		
	ret = MESA_htable_mature(htable);
	if(0 == ret){
		printf("MESA_htable_mature success!\n");
	}else{
		printf("MESA_htable_mature error!\n");
		return -1;
	}

	int key = 1234;
	const char *raw_data = "I am in htable.";

	ret = MESA_htable_add(htable, (const uchar *)&key, sizeof(int), raw_data);
	if(ret < 0){
		abort();
	}
	const char *hdata;
	hdata = (const char *)MESA_htable_search(htable, (const uchar *)&key, sizeof(int));
	if(hdata != NULL){
		printf("search ok, data=%s\n", hdata);
	}else{
		printf("not found!\n");
	}

	MESA_htable_destroy(htable, NULL);

	htable = NULL;
	
	return 0;
}

#ifdef __cplusplus
}
#endif



