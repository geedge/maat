#include "MESA_ring_queue.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __cplusplus
extern "C"
{
#endif

#define RING_QUEUE_TEST_NUM  (10000000)

static MESA_ring_queue_head RQ;
static time_t start_time;

void *rq_producter(void *arg)
{
	int i;
	while(1){
		for(i = 0; i < RING_QUEUE_TEST_NUM+10; i++){
			//while(MESA_ring_queue_try_join(RQ, &i, sizeof(int)) != 0);
			MESA_ring_queue_join(RQ, &i, sizeof(int));
			//usleep(1000);
		}

		//MESA_ring_queue_destroy(RQ, NULL, NULL);
		//exit(1);
	}

	return NULL;
}

void *rq_customer(void *arg)
{
	int ret, data, data_len, i;
	int tid = *(int *)arg;
	while(1){
		data_len = sizeof(int);
		for(i = 0; i < RING_QUEUE_TEST_NUM; i++){
			MESA_ring_queue_get(RQ, &data, &data_len);
		}
		//printf("tid:%d get %d\n", tid, data);
		//usleep(100000);

		printf("time cost = %d\n", time(NULL) - start_time);

		exit(0);
	}

	return NULL;

}


int main(void)
{
	pthread_t pid;
	int opt, i;
	
	printf("program start, time=%d\n", time(NULL));
	
	RQ = MESA_ring_queue_born();

	opt = 0;
	MESA_ring_queue_set_opt(RQ, RQO_THREAD_SAFE, &opt, sizeof(int));

	opt = 1024;
	MESA_ring_queue_set_opt(RQ, RQO_PRE_ALLOC_BUF_LEN, &opt, sizeof(int));

	opt = RING_QUEUE_TEST_NUM;
	MESA_ring_queue_set_opt(RQ, RQO_RING_ELEMENT_NUM, &opt, sizeof(int));

	opt =1;
	MESA_ring_queue_set_opt(RQ, RQO_MULTI_THREAD_LOCK_FREE, &opt, sizeof(int));
	
        if(MESA_ring_queue_mature(RQ) < 0){
                return -1;
        }
        
	i = 0;

	printf("queue init OK, time=%d\n", time(NULL));
	start_time = time(NULL);
	pthread_create(&pid, NULL, rq_producter, NULL);
	pthread_create(&pid, NULL, rq_customer, (void *)&i);


	while(1){
		pause();
	}

	return 0;
}

#ifdef __cplusplus
}
#endif

