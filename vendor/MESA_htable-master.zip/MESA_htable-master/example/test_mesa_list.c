#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>
#include "MESA_list_count.h"

MESA_list_count_t list_head;

static void insert_value(int value)
{
	int *p = malloc(sizeof(int));
	MESA_list_count_t *obj = malloc(sizeof(MESA_list_count_t));
	*p = value;
	obj->quiddity = p;
	MESA_list_count_add_tail(&list_head, obj);
}


MESA_list_count_t *find_value(MESA_list_count_t *head, int value)
{
	MESA_list_count_t *next, *p = head->nextele;

	while(p != head){
		next = p->nextele;
		if(*((int *)p->quiddity) == value){
			return p;
		}
		p = next;
	}

	return NULL;
}

void print_list(MESA_list_count_t *head)
{
	MESA_list_count_t *next, *p = head->nextele;

	while(p != head){
		next = p->nextele;
		printf("%d, ", *((int *)p->quiddity));
		p = next;
	}

	printf("\n");
}

int main(void)
{
	MESA_list_count_t *p, *new_obj;
	int *value;
	
	MESA_list_count_init_head(&list_head);

	insert_value(1);
	insert_value(2);
	insert_value(3);
	insert_value(5);
	print_list(&list_head);

	p = find_value(&list_head, 3);
	if(NULL == p){
		printf("Not found %d\n", 3);
		exit(1);
	}
	new_obj = malloc(sizeof(MESA_list_count_t));
	value = malloc(sizeof(int));
	*value = 4;
	new_obj->quiddity = value;

#if 1
	MESA_list_count_join_n(&list_head, p, new_obj);
#else
	MESA_list_count_join_p(&list_head, new_obj, p);
#endif

	print_list(&list_head);

	return 0;
}

#ifdef __cplusplus
}
#endif

