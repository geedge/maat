#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif

#ifndef MALLOC_CHECK_
#define MALLOC_CHECK_ (1)
#endif

MESA_htable_handle htable;

#define MULTI_THREAD    (1)
#define HTABLE_SIZE     (1024 * 1024)

#define RAND_NUM_RANGE  (0xfffff)

static volatile int insert_ok = 0, insert_err = 0;
static volatile int select_hit = 0, select_not_hit = 0;
static volatile int delete_hit = 0, delete_not_hit = 0;
static volatile int rdelete_hit = 0, rdelete_not_hit = 0; /* �ݹ�ɾ�� */
static volatile int tot_op_times = 0;

static int ins_n;
static int sel_n;
static int del_n; 

void my_free(void *data)
{
	free(data);
}

int my_expire(void *arg, int type)
{
	int ret;
	int *data = (int *)arg;
//	if((*data %2) == 0)
	{
		//printf("\t\t\titem %d expired, del it!\n", *data);
		//return 1;
	}
	
	if(ELIMINATE_TYPE_NUM == type){
		printf("\t\t\t ##### item %d exceed threshold, force del it!\n", *data);
		ret = 1;
	}else if(ELIMINATE_TYPE_MANUAL== type){
		printf("\t\t\titem %d del by manual!\n", *data);
		ret = 0;
	}else{
		printf("\t\t\titem %d still in use can't del it!\n", *data);
		ret = 0;
	}	
	
	return ret;
}



void *sel_thread(void *arg)
{
    int key = 50;
	sleep(2);
    
    while(1)
    {
        MESA_htable_search(htable, (uchar *)&key, sizeof(int));
	usleep(1000 * 5);
	key++;
	if(key > 70){
		key = 50;
	}
    }

    return NULL;
}



void *thread_print(void *arg)
{
    int n;

    while(1)
    {     
        //printf("\ntotal element=%u\n", MESA_htable_get_elem_num(htable));
      
        tot_op_times = 0;
        //printf("\tOK : ins=%d, sel=%d, del=%d, rdel=%d\n", insert_ok, select_hit, delete_hit, rdelete_hit);
        //printf("\tERR: ins=%d, sel=%d, del=%d, rdel=%d\n", insert_err, select_not_hit, delete_not_hit, rdelete_not_hit);
        usleep(1000 * 995);
    }

    return NULL;
}

void *del_thread(void *arg)
{
    int n;
	sleep(10);

    while(1)
    {     
	MESA_htable_del_oldest_manual(htable, my_free, 10);
        //printf("\ntotal element=%u\n", MESA_htable_get_elem_num(htable));
        //printf("\tOK : ins=%d, sel=%d, del=%d, rdel=%d\n", insert_ok, select_hit, delete_hit, rdelete_hit);
        //printf("\tERR: ins=%d, sel=%d, del=%d, rdel=%d\n", insert_err, select_not_hit, delete_not_hit, rdelete_not_hit);
        usleep(1000 * 95);
    }

    return NULL;
}

int main(void)
{
	pthread_t t[20];
	MESA_htable_create_args_t hargs;
	int num = 0;
	int *data;

	srand(time(NULL));
	memset(&hargs, 0, sizeof(MESA_htable_create_args_t));
	hargs.thread_safe = 1;
	hargs.recursive = 1;
	hargs.hash_slot_size = HTABLE_SIZE;
	hargs.max_elem_num = 100000;
	hargs.eliminate_type = HASH_ELIMINATE_ALGO_LRU;
	hargs.expire_time = 0;
	hargs.key_comp = NULL;
	hargs.key2index = NULL;
	hargs.data_free = my_free;
	hargs.data_expire_with_condition = my_expire;
	htable = MESA_htable_create(&hargs, sizeof(MESA_htable_create_args_t));
MESA_htable_print_crtl(htable, 0);

	pthread_create(&t[0], NULL, sel_thread, NULL);
	pthread_create(&t[1], NULL, thread_print, NULL);  
	pthread_create(&t[2], NULL, del_thread, NULL);  
	pthread_create(&t[3], NULL, del_thread, NULL);  

	while(1) {
		data = (int *)malloc(sizeof(int));
		*data = num;
		if(MESA_htable_add(htable, (uchar *)&num, sizeof(int), data) < 0){
			printf("item %d insert error!\n", num);
		}else{
			printf("item %d insert OK!\n", num);
		}
		usleep(1000 * 5);
		num++;
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif



