#include <gtest/gtest.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <assert.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/types.h>			/* See NOTES */
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "MESA_htable.h"

#define GTEST_HT_ELEM_SLOT_SIZE	(1024 * 256)
#define GTEST_HT_ELEM_MAX_NUM	(10000)
#define GTEST_HT_ELEM_OP_NUM	(100)


static int test_hash_functionality_simple(void *htable)
{
	int i, ret;
	int key;
	void *res;
	int *phony_data;

	for(i = 0 ; i < GTEST_HT_ELEM_OP_NUM; i++){
		phony_data = (int *)malloc(sizeof(int));
		*phony_data = i;
		key = i;
		ret = MESA_htable_add(htable, (uchar *)&key, sizeof(int), phony_data);
		if(ret < 0){
			return -1;
		}
	}
	if(MESA_htable_get_elem_num(htable) != GTEST_HT_ELEM_OP_NUM){
		return -1;
	}

	for(i =0 ; i < GTEST_HT_ELEM_OP_NUM; i++){
		key = i;
		res = MESA_htable_search(htable, (uchar *)&key, sizeof(int));
		if(NULL == res){
			return -1;
		}
	}
	
	for(i =0 ; i < GTEST_HT_ELEM_OP_NUM; i++){
		key = i;
		ret = MESA_htable_del(htable, (uchar *)&key, sizeof(int), NULL);
		if(ret < 0){
			return -1;
		}
	}

	return 0;
}


static int __key_cmp(const uchar * key1, uint size1, const uchar * key2, uint size2)
{
	if(size1 != size2){
		return -1;
	}

	return memcmp(key1, key2, size1);
}

static void __data_free(void *data)
{
	free(data);
}

void *htable_create_old_api(void)
{
	MESA_htable_create_args_t hargs;
	void *thable;

	memset(&hargs, 0, sizeof(MESA_htable_create_args_t));

	hargs.thread_safe = 0;
	hargs.hash_slot_size = GTEST_HT_ELEM_SLOT_SIZE;
	hargs.max_elem_num = GTEST_HT_ELEM_MAX_NUM;
	hargs.eliminate_type = HASH_ELIMINATE_ALGO_LRU;
	hargs.expire_time = 0;

	hargs.key_comp = __key_cmp;

	hargs.key2index = NULL;
	hargs.data_free = __data_free;
	hargs.data_expire_with_condition = NULL;

	hargs.thread_safe = 1;
	hargs.recursive = 1;
	thable = MESA_htable_create(&hargs, sizeof(MESA_htable_create_args_t));
	if(NULL == thable){
		return NULL;
	}

	MESA_htable_print_crtl(thable, 0);

	return thable;
}


int gtest_htable_old_api_simple(void)
{
	void *thable;
	int ret;

	thable = htable_create_old_api();
	if(NULL == thable){
		return -1;
	}

	ret = test_hash_functionality_simple(thable);

	MESA_htable_destroy(thable, NULL);

	return ret;
}


