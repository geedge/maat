#include <semaphore.h>
#include <stdio.h>
#include <pthread.h>

static long long rd_num, wr_num;
static pthread_rwlock_t rw_lock;

void *lock_perf_thread(void *a)
{
	long long last_rd_num, last_wr_num;
	
	while(1){
		printf("rdlock pps:%lld, rw_lock = %lld\n",  
			rd_num - last_rd_num, 
			wr_num - last_wr_num);
		last_rd_num = rd_num;
		last_wr_num = wr_num;

		sleep(1);
	}

	return NULL;
}

void *rd_lock_thread(void *a)
{
	while(1){
		pthread_rwlock_rdlock(&rw_lock);
		rd_num++;
		pthread_rwlock_unlock(&rw_lock);
	}

	return NULL;
}

void *rw_lock_thread(void *a)
{
	while(1){
		pthread_rwlock_wrlock(&rw_lock);
		wr_num++;
		pthread_rwlock_unlock(&rw_lock);
	}

	return NULL;
}

int main(void)
{
	pthread_t pid;
	
	if(pthread_rwlock_init(&rw_lock, NULL) < 0){
		return -1;
	}

	pthread_create(&pid, NULL, rd_lock_thread, NULL);
	pthread_create(&pid, NULL, rw_lock_thread, NULL);

	pthread_create(&pid, NULL, lock_perf_thread, NULL);

	while(1){
		pause();
	}

	return 0;
}

