#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif

#ifndef MALLOC_CHECK_
#define MALLOC_CHECK_ (1)
#endif

MESA_htable_handle htable;

#define MULTI_THREAD    (1)
#define HTABLE_SIZE     (1024 * 1024)

#define RAND_NUM_RANGE  (0xfffff)

static volatile int insert_ok = 0, insert_err = 0;
static volatile int select_hit = 0, select_not_hit = 0;
static volatile int delete_hit = 0, delete_not_hit = 0;
static volatile int rdelete_hit = 0, rdelete_not_hit = 0; /* �ݹ�ɾ�� */
static volatile int tot_op_times = 0;

static int ins_n;
static int sel_n;
static int del_n; 

void my_free(void *data)
{
	free(data);
}



 int _iterate_cb(const uchar * key, uint size, void * data,  void *u)
 {
	int *p = (int *)data;
	printf("\t ##  iterate data:%d\n", *p);

#if 0
	if(*p == 13){
		return ITERATE_CB_RET_DEL_FLAG;
	}
#endif
#if 0
	if(*p == 12){
		return ITERATE_CB_RET_REVERSE_FLAG;
	}
#endif
#if 1
	//if(*p == 7)
	{
		free(data);
		return ITERATE_CB_RET_REMOVE_BUT_NOT_FREE;
	}
#endif

	return ITERATE_CB_RET_CONTINUE_FLAG;
	//return ITERATE_CB_RET_BREAK_FLAG;
 }

void *iterate_thread(void *arg)
{
    int n;
	sleep(5);

    while(1)
    {     
	MESA_htable_iterate_bytime(htable, 1, _iterate_cb, NULL);
        //printf("\ntotal element=%u\n", MESA_htable_get_elem_num(htable));
        //printf("\tOK : ins=%d, sel=%d, del=%d, rdel=%d\n", insert_ok, select_hit, delete_hit, rdelete_hit);
        //printf("\tERR: ins=%d, sel=%d, del=%d, rdel=%d\n", insert_err, select_not_hit, delete_not_hit, rdelete_not_hit);
        usleep(1000 * 950);
    }

    return NULL;
}

int main(void)
{
	pthread_t t[20];
	MESA_htable_create_args_t hargs;
	int num = 0;
	int *data;

	srand(time(NULL));
	memset(&hargs, 0, sizeof(MESA_htable_create_args_t));
	hargs.thread_safe = 1;
	hargs.recursive = 1;
	hargs.hash_slot_size = HTABLE_SIZE;
	hargs.max_elem_num = 100000;
	hargs.eliminate_type = HASH_ELIMINATE_ALGO_LRU;
	hargs.expire_time = 0;
	hargs.key_comp = NULL;
	hargs.key2index = NULL;
	hargs.data_free = NULL;
	hargs.data_expire_with_condition = NULL;
	htable = MESA_htable_create(&hargs, sizeof(MESA_htable_create_args_t));
MESA_htable_print_crtl(htable, 1);

	//pthread_create(&t[0], NULL, sel_thread, NULL);
	//pthread_create(&t[1], NULL, thread_print, NULL);  
	pthread_create(&t[2], NULL, iterate_thread, NULL);  
	//pthread_create(&t[3], NULL, del_thread, NULL);  

	while(1) {
		data = (int *)malloc(sizeof(int));
		*data = num;
		if(num < 200000000){
			if(MESA_htable_add(htable, (uchar *)&num, sizeof(int), data) < 0){
				printf("item %d insert error!\n", num);
			}else{
				printf("item %d insert OK!\n", num);
			}
			num++;
		}
		usleep(1000 * 59);
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif



