valgrind --tool=memcheck --leak-check=yes --leak-resolution=high --log-file=valgrind.log $1
