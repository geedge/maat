#include <gtest/gtest.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <assert.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/types.h>			/* See NOTES */
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "MESA_htable.h"
#include "MESA_htable_internal.h"


TEST(htable, old_api_simple)
{
	int ret;

	ret = gtest_htable_old_api_simple();

	ASSERT_EQ(ret, 0);
}


static void usage(int argc, char *argv[])
{
	printf("args example:\n"); 
	printf("\t%s --gtest_list_tests\n", argv[0]);
	printf("\t%s --gtest_filter=htable.simple\n", argv[0]);
	printf("\t%s --gtest_filter=htable*\n", argv[0]);
	exit(1);
}

int main(int argc, char *argv[])
{
	if((2 == argc)  && (strncasecmp(argv[1], "-h", 2) == 0)){
		usage(argc, argv);
	}

	::testing::InitGoogleTest(&argc, argv);

	int ret=RUN_ALL_TESTS();
	return ret;
}

