#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "MESA_htable.h"
#ifdef __cplusplus
extern "C"
{
#endif

#ifndef MALLOC_CHECK_
#define MALLOC_CHECK_ (1)
#endif

MESA_htable_handle htable;

#define MULTI_THREAD    (1)
#define HTABLE_SIZE     (1024 * 1024)

#define RAND_NUM_RANGE  (0xfffff)

struct test_complex_key{
	char *s1;
	char *s2;
};

void my_free(void *data)
{
	free(data);
}

uchar* test_key_dup(const uchar *key, uint key_size)
{
	struct test_complex_key *complex_key = (struct test_complex_key *)malloc(sizeof(struct test_complex_key));

	complex_key->s1 = (char *)malloc(100);
	complex_key->s2 = (char *)malloc(100);

	return (uchar *)complex_key;
}

void test_key_free(uchar *key, uint key_size)
{
	struct test_complex_key *complex_key = (struct test_complex_key *)key;

	free(complex_key->s1);
	free(complex_key->s2);
	free(complex_key);

	return ;
}
/* �����ڲ��Դ���������, �˴����ж������ */
 int test_key_comp(const uchar * key1, uint size1, const uchar * key2, uint size2)
 {
	return -1;
 }

 static void test_htable_add(MESA_htable_handle ttable)
 {
 	unsigned char key[128];
	char *data = malloc(100);
	
 	snprintf(key, 128, "%d", rand());
 	
	MESA_htable_add(ttable, key, strlen(key), data);
 }

static MESA_htable_handle test_htable_create(void)
{
	MESA_htable_handle ttable;
	MESA_htable_create_args_t hargs;

	memset(&hargs, 0, sizeof(MESA_htable_create_args_t));
	hargs.thread_safe = 1;
	hargs.recursive = 1;
	hargs.hash_slot_size = HTABLE_SIZE;
	hargs.max_elem_num = 100000;
	hargs.eliminate_type = HASH_ELIMINATE_ALGO_LRU;
	hargs.expire_time = 0;
	hargs.key_comp = test_key_comp;
	hargs.key2index = NULL;
	hargs.data_free = my_free;
	hargs.data_expire_with_condition = NULL;
	hargs.complex_key_dup = test_key_dup;
	hargs.complex_key_free = test_key_free;
	ttable = MESA_htable_create(&hargs, sizeof(MESA_htable_create_args_t));

	return ttable;
}


int main(void)
{
	MESA_htable_handle ttable;
	int i, j;

	srand(time(NULL));

	for(i = 0; i < 1000; i++){
		ttable = test_htable_create();
		MESA_htable_print_crtl(ttable, 1);
		for(j = 0; j < 100; j++){
			test_htable_add(ttable);
		}
		MESA_htable_destroy(ttable, NULL);
	}
	
	return 0;
}

#ifdef __cplusplus
}
#endif




