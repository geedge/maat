#ifdef __cplusplus
extern "C"
{
#endif
#include <stdio.h>
#include "MESA_list.h"

/*************************** �ڲ�ʵ�ֽӿ� ********************************/

const char *MESA_list_version_VERSION_20150529 = "MESA_list_version_VERSION_20150529";
const unsigned int MESA_LIST_VERSION_INT = 20150529;

/*
 * Simple doubly linked list implementation.
 *
 * Some of the internal functions ("__xxx") are useful when
 * manipulating whole lists rather than single entries, as
 * sometimes we already know the next/prev entries and we can
 * generate better code by using them directly rather than
 * using the generic single-entry routines.
 */

#if 0
static void __MESA_list_count_init(void **list_count)
{
    long *p_c = (long *)list_count;
    *p_c = 0;
}

static void __MESA_list_count_inc(void **list_count)
{
    long *p_c = (long *)list_count;
    long c = *p_c;
    *p_c = c + 1;
}

static void __MESA_list_count_dec(void **list_count)
{
    long *p_c = (long *)list_count;
    long c = *p_c;
    *p_c = c - 1;
}
#endif

void MESA_list_init_head(struct MESA_list *head)
{
	head->nextele = head;
	head->preele = head;
	//__MESA_list_count_init(&head->quiddity);
}

long MESA_list_get_count(const struct MESA_list *head)
{
	return (long)head->quiddity;
}


/*
 * Insert a new entry between two known consecutive entries.
 *
 * This is only for internal list manipulation where we know
 * the prev/next entries already!
 */
static inline void __MESA_list_add(struct MESA_list *new_list,
			      struct MESA_list *prev,
			      struct MESA_list *next)
{
	next->preele = new_list;
	new_list->nextele = next;
	new_list->preele = prev;
	prev->nextele = new_list;
}

/**
 * list_add - add a new entry
 * @new: new entry to be added
 * @head: list head to add it after
 *
 * Insert a new entry after the specified head.
 * This is good for implementing stacks.
 * lijia comment: list_add()���½ڵ����head��head->next֮��.
 */
void MESA_list_add(struct MESA_list *head, struct MESA_list *new_list)
{
	__MESA_list_add(new_list, head, head->nextele);
	//__MESA_list_count_inc(&head->quiddity);
}


/**
 * list_add_tail - add a new entry
 * @new: new entry to be added
 * @head: list head to add it before
 *
 * Insert a new entry before the specified head.
 * This is useful for implementing queues.
 * lijia comment: list_add_tail()���½ڵ����head��head->prev֮��.
 */
void MESA_list_add_tail(struct MESA_list *head, struct MESA_list *new_list)
{
	__MESA_list_add(new_list, head->preele, head);
	//__MESA_list_count_inc(&head->quiddity);
}

/*
 * Delete a list entry by making the prev/next entries
 * point to each other.
 *
 * This is only for internal list manipulation where we know
 * the prev/next entries already!
 */
static inline void __MESA_list_del(struct MESA_list * prev, struct MESA_list * next)
{
	next->preele = prev;
	prev->nextele = next;
}

static inline void __MESA_list_del_entry(struct MESA_list *entry)
{
	__MESA_list_del(entry->preele, entry->nextele);
	entry->nextele = NULL;
	entry->preele = NULL;
}

/**
 * list_del - deletes entry from list.
 * @entry: the element to delete from the list.
 * Note: list_empty() on entry does not return true after this, the entry is
 * in an undefined state.
 */

void MESA_list_del(struct MESA_list *head, struct MESA_list *entry)
{
	__MESA_list_del(entry->preele, entry->nextele);
	entry->nextele = NULL;
	entry->preele = NULL;
	//__MESA_list_count_dec(&head->quiddity);
}


/**
 * list_move - delete from one list and add as another's head
 * @list: the entry to move
 * @head: the head that will precede our entry
 */
void MESA_list_move(struct MESA_list *head, struct MESA_list *list)
{
	__MESA_list_del_entry(list);
	MESA_list_add(head, list);
}

/**
 * list_move_tail - delete from one list and add as another's tail
 * @list: the entry to move
 * @head: the head that will follow our entry
 */
void MESA_list_move_tail(struct MESA_list *head, struct MESA_list *list)
{
	__MESA_list_del_entry(list);
	MESA_list_add_tail(head, list);
}

#if 0
/**
 * list_empty - tests whether a list is empty
 * @head: the list to test.
 */
static int list_empty(const struct MESA_list *head)
{
	return head->nextele == head;
}
#endif

/* insert "new_obj" between "op_place" and "op_place->nextele" */
struct MESA_list *MESA_list_join_n(struct MESA_list *head, struct MESA_list *op_place, struct MESA_list *new_obj)
{
	__MESA_list_add(new_obj, op_place, op_place->nextele);
	//__MESA_list_count_inc(&head->quiddity);
	return new_obj;
}

/* insert "new_obj" between "op_place->preele" and "op_place" */
struct MESA_list *MESA_list_join_p(struct MESA_list *head, struct MESA_list *new_obj, struct MESA_list *op_place)
{
	__MESA_list_add(new_obj, op_place->preele, op_place);
	//__MESA_list_count_inc(&head->quiddity);
	return new_obj;
}

/**
 * list_empty_careful - tests whether a list is empty and not being modified
 * @head: the list to test
 *
 * Description:
 * tests whether a list is empty _and_ checks that no other CPU might be
 * in the process of modifying either member (next or prev)
 *
 * NOTE: using list_empty_careful() without synchronization
 * can only be safe if the only activity that can happen
 * to the list entry is list_del_init(). Eg. it cannot be used
 * if another CPU could re-list_add() it.
 */
int MESA_list_is_empty(const struct MESA_list *head)
{
	struct MESA_list *next = head->nextele;
	return (next == head) && (next == head->preele);
}

#ifdef __cplusplus
}
#endif

