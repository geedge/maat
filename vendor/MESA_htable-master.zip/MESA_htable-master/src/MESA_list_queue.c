#ifdef __cplusplus
extern "C"
{
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/types.h>
#include <linux/stddef.h>
#include <assert.h>
#ifndef __USE_UNIX98
#define __USE_UNIX98 1
#endif
#include <pthread.h>
#include <time.h>
#include <assert.h>
#include <errno.h>
#include <semaphore.h>
#include "MESA_list_queue.h"
#include "MESA_list_count.h"
#include "MESA_htable_internal.h"

const char * MESA_lqueue_version_VERSION_20160308 = "MESA_lqueue_version_VERSION_20160308";
const unsigned int MESA_LIST_QUEUE_VERSION_INT = 20160308;

/*
    ��֤nextele��preeleλ�ò��䣬���Ը���list_common�еĲ���������
*/
typedef struct list_index_v3 {
	struct list_index_v3	*nextele; /* ����ָ�������ڽṹ��ǰ2λ, ����MESA_list���� */
	struct list_index_v3	*preele;  /* ����ָ�������ڽṹ��ǰ2λ, ����MESA_list���� */
	void				*data;
	long				data_len;
}MESA_list_index_v3_t;

typedef struct list_head_v3 {
	struct list_index_v3	*nextele; /* ����ָ�������ڽṹ��ǰ2λ, ����MESA_list���� */
	struct list_index_v3	*preele;  /* ����ָ�������ڽṹ��ǰ2λ, ����MESA_list���� */
	volatile long		cur_item_num; /* ��ǰԪ������������ڵ�3λ */
	volatile long		max_item_num;
	volatile long		mem_used; /* 2014-02-24 add  */
	int				thread_safe;
	pthread_mutex_t	mutex;
	pthread_cond_t	customer_cond;
	pthread_cond_t	producter_cond;
}Inter_head_v3_t;

extern void list_count_init(void **list_count);
extern void list_count_inc(void **list_count);
extern void list_count_dec(void **list_count);


static int MESA_q_lock_v3(Inter_head_v3_t *queue_v3_handle, int block)
{
	int ret = -1;

	if(queue_v3_handle->thread_safe){
		if(MESA_list_BOLCK == block){
			ret = pthread_mutex_lock(&queue_v3_handle->mutex);
			if(ret != 0){
				ret = MESA_QUEUE_RET_CANT_GET_LOCK;
			}
		}else{
			ret = pthread_mutex_trylock(&queue_v3_handle->mutex);
			if(ret != 0){
				ret = MESA_QUEUE_RET_CANT_GET_LOCK;
			}
		}
	}else{
		ret = MESA_QUEUE_RET_OK;
	}

	return ret;
}



static int MESA_q_unlock_v3(Inter_head_v3_t *queue_v3_handle)
{
    int ret = 0;
    
    if(queue_v3_handle->thread_safe){
        ret = pthread_mutex_unlock(&queue_v3_handle->mutex);
    }
    
    return ret;
}

static int MESA_q_cond_wait_v3(Inter_head_v3_t *queue_v3_handle, int op_type, int block)
{
	int ret = -1;

	if(queue_v3_handle->thread_safe){
		if(MESA_list_BOLCK == block){
			if(MESA_list_GET == op_type){
				ret = pthread_cond_wait(&queue_v3_handle->customer_cond, &queue_v3_handle->mutex);
			}else{
				ret = pthread_cond_wait(&queue_v3_handle->producter_cond, &queue_v3_handle->mutex);
			}
			if(ret != 0){
				ret = -1;
			}
		}else{ /* ������ģʽ��, ֱ�ӷ���ʧ�� */
			ret = -1;
		}
	}else{
		ret = -1;
	}

	return ret;
}

static int __can_i_do_it(Inter_head_v3_t *queue_v3_handle, int op_type, int block)
{
	int ret = MESA_QUEUE_RET_OK;
	
	ret = MESA_q_lock_v3(queue_v3_handle, block);
	if(ret < 0){
		ret = MESA_QUEUE_RET_CANT_GET_LOCK;
		goto err1;
	}

	if(MESA_list_JOIN == op_type){
		 if((queue_v3_handle->max_item_num != 0) 
		  && (queue_v3_handle->cur_item_num >= queue_v3_handle->max_item_num)){
			ret = MESA_q_cond_wait_v3(queue_v3_handle, op_type, block);
			if(ret < 0){
				ret = MESA_QUEUE_RET_NUM_FULL;
				goto err2;
			}
		}else{
			ret = MESA_QUEUE_RET_OK;
		}
	}else{
		if(0 == queue_v3_handle->cur_item_num){
			ret = MESA_q_cond_wait_v3(queue_v3_handle, op_type, block);
			if(ret < 0){
				ret = MESA_QUEUE_RET_QEMPTY;
				goto err2;
			}
		}else{
			ret = MESA_QUEUE_RET_OK;
		}
	}
	
	return ret;

err2:
	MESA_q_unlock_v3(queue_v3_handle);
err1:
	return ret;
}

static int MESA_lqueue_del_node(MESA_list_index_v3_t *queue_node)
{
    //MESA_list_count_del(NULL, (struct MESA_list_count *)queue_node);
    queue_node->preele->nextele = queue_node->nextele;
    queue_node->nextele->preele = queue_node->preele;
    free(queue_node->data);
    free(queue_node);
    return 0;
}

long MESA_lqueue_get_mem_used(MESA_lqueue_head head)
{
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;
	return queue_v3_handle->mem_used;
}

long MESA_lqueue_get_mem_used_exactly(MESA_lqueue_head head)
{
	long memuse = -1;
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;

	if(MESA_q_lock_v3(queue_v3_handle,  MESA_list_BOLCK) < 0){
		errno = ERANGE;
		return (long)-1;
	}

	memuse =  queue_v3_handle->mem_used;

	MESA_q_unlock_v3(queue_v3_handle);

	return memuse;
}


long MESA_lqueue_get_count(MESA_lqueue_head head)
{
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;
	/* 
		TODO:
		�˴��Ƿ���Ҫ������?
		Ӧ�ò���, ����˴�����, �������غ�, ���������Ҳ���ϻ�ı�, û��������.
		�����õ���ȷ��������, Ȼ�����������Ļ�, Ӧ���ûص�������ʽ.

	*/	
	return queue_v3_handle->cur_item_num;
}

long MESA_lqueue_get_count_exactly(MESA_lqueue_head head)
{
	long count = -1;
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;

	if(MESA_q_lock_v3(queue_v3_handle,  MESA_list_BOLCK) < 0){
		errno = ERANGE;
		return (long)-1;
	}

	count =  queue_v3_handle->cur_item_num;

	MESA_q_unlock_v3(queue_v3_handle);

	return count;
}

/* 
	args description:
	[IN]:
		lq_head : the handler of MESA_lqueue.

	[OUT]:
		data	    : receive buffer.

	[IN $ OUT]:
		data_len: is value-result argument, like "addrlen of recvfrom(2)"
			the caller should initialize before the call to the size of the 'data', 
			and modified on return to indicate the actual size of the queue item.

*/
static int __MESA_lqueue_read_head(MESA_lqueue_head head, void *data, long *data_len, int block)
{
    int ret;
    MESA_list_index_v3_t *queue_node;
    Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;

	if(MESA_list_BOLCK == block){
		ret = __can_i_do_it(queue_v3_handle, MESA_list_GET, block);
		if(unlikely(ret < 0)){
			ret = MESA_QUEUE_RET_COMMON_ERR;
			goto err_1;
		}
	}else{
		ret = MESA_q_lock_v3(queue_v3_handle, block);
		if(unlikely(ret != 0)){
			ret = MESA_QUEUE_RET_CANT_GET_LOCK;
			goto err_1;
		}
	}

    if(MESA_list_count_is_empty((const struct MESA_list_count *)queue_v3_handle)){
        ret = MESA_QUEUE_RET_QEMPTY;
        goto err_2;
    }

    queue_node = queue_v3_handle->nextele;
    if((NULL == data) || (NULL == data_len) || (queue_node->data_len > *data_len)){
        ret = MESA_QUEUE_RET_ARG_ERR;
        goto err_2;
    }

    memcpy(data, queue_node->data, queue_node->data_len);
    *data_len = queue_node->data_len;

    MESA_q_unlock_v3(queue_v3_handle);
    return 0;

err_2:
    MESA_q_unlock_v3(queue_v3_handle);
err_1:
    return ret;
}


/* 
	args description:
	[IN]:
		lq_head : the handler of MESA_lqueue.

	[OUT]:
		data	    : receive buffer.

	[IN $ OUT]:
		data_len: is value-result argument, like "addrlen of recvfrom(2)"
			the caller should initialize before the call to the size of the 'data', 
			and modified on return to indicate the actual size of the queue item.

*/
int MESA_lqueue_read_head(MESA_lqueue_head head, void *data, long *data_len)
{
	return __MESA_lqueue_read_head(head, data, data_len, MESA_list_BOLCK);
}

int MESA_lqueue_try_read_head(MESA_lqueue_head head, void *data, long *data_len)
{
	return __MESA_lqueue_read_head(head, data, data_len, MESA_list_NONBOLCK);
}

/*
    get_place: 1:head; 2:tail
*/
static int MESA_q_get_v3(MESA_lqueue_head head, void *data, long *data_len, int get_place, int block)
{
	int ret;
	MESA_list_index_v3_t *queue_node;
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;

	if(unlikely((NULL == data) || (NULL == data_len))){
		ret = MESA_QUEUE_RET_ARG_ERR;
		goto err_1;
	}

	ret = __can_i_do_it(queue_v3_handle, MESA_list_GET, block);
	if(unlikely(ret < 0)){
		goto err_1;
	}

	if(MESA_list_count_is_empty((const struct MESA_list_count *)queue_v3_handle)){
		ret = MESA_QUEUE_RET_QEMPTY;
		goto err_2;
	}
	
	if(MESA_LIST_OP_PLACE_HEAD == get_place){
		queue_node = queue_v3_handle->nextele;
	}else{
		queue_node = queue_v3_handle->preele;
	}
	if(queue_node->data_len > *data_len){
		ret = MESA_QUEUE_RET_LEN_ERR;
		goto err_2;
	}
	memcpy(data, queue_node->data, queue_node->data_len);
	*data_len = queue_node->data_len;
	
#if 0
	if((queue_v3_handle->max_item_num != 0) 
	 && (queue_v3_handle->cur_item_num >= queue_v3_handle->max_item_num)){
		pthread_cond_signal(&queue_v3_handle->producter_cond);
	} 
#endif	
	
	queue_v3_handle->cur_item_num--;

	queue_v3_handle->mem_used -= queue_node->data_len;

	MESA_lqueue_del_node(queue_node);

	pthread_cond_signal(&queue_v3_handle->producter_cond);

	MESA_q_unlock_v3(queue_v3_handle);
	return MESA_QUEUE_RET_OK;

err_2:
	MESA_q_unlock_v3(queue_v3_handle);
err_1:
	return ret;
}

int MESA_lqueue_detect_get_head(MESA_lqueue_head head, MESA_lqueue_cb_t cb, 
								 void *data, long *data_len, void *arg)
{
	int ret;
	int get_action = 0;
	MESA_list_index_v3_t *queue_node;
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;

	if((NULL==cb) || (NULL == data) || (NULL == data_len)){
		ret = MESA_QUEUE_RET_ARG_ERR;
		goto err_1;
	}
	
	ret = MESA_q_lock_v3(queue_v3_handle, MESA_list_BOLCK);
	if(ret < 0){
		ret = MESA_QUEUE_RET_CANT_GET_LOCK;
		goto err_1;
	}

	if(MESA_list_count_is_empty((const struct MESA_list_count *)queue_v3_handle)){
		ret = MESA_QUEUE_RET_QEMPTY;
		goto err_2;
	}
	
	queue_node = queue_v3_handle->nextele;


	if( cb(queue_node->data, queue_node->data_len, arg) != 0){
	    get_action = 1;
	}
    
	if(get_action){
		if(0 == queue_v3_handle->cur_item_num){
			ret = MESA_q_cond_wait_v3(queue_v3_handle, MESA_list_GET, MESA_list_BOLCK);
			if(ret < 0){
				ret = MESA_QUEUE_RET_NUM_FULL;
				goto err_2;
			}
		}
#if 0		
		else if((queue_v3_handle->max_item_num != 0) 
		  && (queue_v3_handle->cur_item_num >= queue_v3_handle->max_item_num)){
		  	pthread_cond_signal(&queue_v3_handle->producter_cond);
		}
#endif
		else{
			/* �ǿշ�������, do nothing! */
		}
		
		memcpy(data, queue_node->data, queue_node->data_len);
		*data_len = queue_node->data_len;

		MESA_lqueue_del_node(queue_node);
		queue_v3_handle->cur_item_num--;
		queue_v3_handle->mem_used -= queue_node->data_len;
		pthread_cond_signal(&queue_v3_handle->producter_cond);
	}

	MESA_q_unlock_v3(queue_v3_handle);
	return MESA_QUEUE_RET_OK;

err_2:
    MESA_q_unlock_v3(queue_v3_handle);
err_1:
    return ret;
}

int MESA_lqueue_get_head(MESA_lqueue_head head, void *data, long *data_len)
{
	return MESA_q_get_v3(head, data, data_len, MESA_LIST_OP_PLACE_HEAD, MESA_list_BOLCK);
}

int MESA_lqueue_try_get_head(MESA_lqueue_head head, void *data, long *data_len)
{
	return MESA_q_get_v3(head, data, data_len, MESA_LIST_OP_PLACE_HEAD, MESA_list_NONBOLCK);
}

int MESA_lqueue_get_tail(MESA_lqueue_head head, void *data, long *data_len)
{
	return MESA_q_get_v3(head, data, data_len, MESA_LIST_OP_PLACE_TAIL, MESA_list_BOLCK);
}

int MESA_lqueue_try_get_tail(MESA_lqueue_head head, void *data, long *data_len)
{
	return MESA_q_get_v3(head, data, data_len, MESA_LIST_OP_PLACE_TAIL, MESA_list_NONBOLCK);
}


/*
    join_place: 1:head; 2:tail
*/
static int MESA_q_join_v3(MESA_lqueue_head head, const void *data, long data_len, int join_place, int block)
{
	int ret;
	MESA_list_index_v3_t *queue_node;
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;

	if(unlikely((NULL == data) || (data_len <= 0))){
		ret = MESA_QUEUE_RET_ARG_ERR;
		goto err_1;
	}

	ret = __can_i_do_it(queue_v3_handle, MESA_list_JOIN, block);
	if(unlikely(ret < 0)){
		goto err_1;
	}

	if((queue_v3_handle->max_item_num != 0) 
	  && (queue_v3_handle->cur_item_num >= queue_v3_handle->max_item_num)){
		ret = MESA_QUEUE_RET_NUM_FULL;
		goto err_2;
      }
	queue_node = (MESA_list_index_v3_t *)calloc(1, sizeof(MESA_list_index_v3_t));
	//memset(queue_node, 0, sizeof(MESA_list_index_v3_t));
	queue_node->data = malloc(data_len);
	memcpy(queue_node->data, data, data_len);
	queue_node->data_len = data_len;
	queue_v3_handle->mem_used += data_len;

	if(MESA_LIST_OP_PLACE_HEAD == join_place){
		MESA_list_count_add((struct MESA_list_count *)head, (struct MESA_list_count *)queue_node);
	}else{
		MESA_list_count_add_tail((struct MESA_list_count *)head, (struct MESA_list_count *)queue_node);
	}    

#if 0
	if(0 == queue_v3_handle->cur_item_num){
		pthread_cond_signal(&queue_v3_handle->cond);
	}
#endif
	pthread_cond_signal(&queue_v3_handle->customer_cond);
	
	MESA_q_unlock_v3(queue_v3_handle);

	return MESA_QUEUE_RET_OK;

err_2:
	MESA_q_unlock_v3(queue_v3_handle);
err_1:
	return ret;
}


int MESA_lqueue_join_head(MESA_lqueue_head head, const void *data, long data_len)
{
	return MESA_q_join_v3(head, data, data_len, MESA_LIST_OP_PLACE_HEAD, MESA_list_BOLCK);
}

int MESA_lqueue_try_join_head(MESA_lqueue_head head, const void *data, long data_len)
{
	return MESA_q_join_v3(head, data, data_len, MESA_LIST_OP_PLACE_HEAD, MESA_list_NONBOLCK);
}

int MESA_lqueue_join_tail(MESA_lqueue_head head, const void *data, long data_len)
{
	return MESA_q_join_v3(head, data, data_len, MESA_LIST_OP_PLACE_TAIL, MESA_list_BOLCK);
}

int MESA_lqueue_try_join_tail(MESA_lqueue_head head, const void *data, long data_len)
{
	return MESA_q_join_v3(head, data, data_len, MESA_LIST_OP_PLACE_TAIL, MESA_list_NONBOLCK);
}

MESA_lqueue_head MESA_lqueue_create(int thread_safe, long max_item_num)
{
	Inter_head_v3_t *queue_v3_handle;

	queue_v3_handle = (Inter_head_v3_t *)calloc(1, sizeof(Inter_head_v3_t));
	//memset(queue_v3_handle, 0, sizeof(Inter_head_v3_t));
	queue_v3_handle->thread_safe = thread_safe;
	queue_v3_handle->max_item_num = max_item_num;
	queue_v3_handle->cur_item_num = 0;
	queue_v3_handle->mem_used = 0;

	if(thread_safe != 0){
		pthread_mutex_init(&queue_v3_handle->mutex, NULL);
		//sem_init(&queue_v3_handle->empty_sem, 0, (unsigned int)max_item_num);
		//sem_init(&queue_v3_handle->data_sem, 0, 0);
		pthread_cond_init(&queue_v3_handle->customer_cond, NULL);
		pthread_cond_init(&queue_v3_handle->producter_cond, NULL);
	}

	MESA_list_count_init_head((struct MESA_list_count *)queue_v3_handle);

	return (void *)queue_v3_handle;
}

void MESA_lqueue_destroy(MESA_lqueue_head head, MESA_lqueue_cb_t cb,void *arg)
{
	int ret;
	MESA_list_index_v3_t *queue_node, *queue_next;
	Inter_head_v3_t *queue_v3_handle = (Inter_head_v3_t *)head;

	if(queue_v3_handle->thread_safe){
		ret = pthread_mutex_lock(&queue_v3_handle->mutex);
		if(ret != 0){
			goto err_1;
		}
	}

	if(MESA_list_count_is_empty((const struct MESA_list_count *)queue_v3_handle)){
		goto err_2;
	}
    
	queue_node = (MESA_list_index_v3_t *)queue_v3_handle->nextele;
	while((void *)queue_node != (void *)queue_v3_handle){
		queue_next = queue_node->nextele;
		if(cb){
			cb(queue_node->data, queue_node->data_len, arg);
		}
		MESA_lqueue_del_node(queue_node);
		queue_node = queue_next;
	}
    
	MESA_q_unlock_v3(queue_v3_handle);

	if(queue_v3_handle->thread_safe){
		pthread_mutex_destroy(&queue_v3_handle->mutex);
		//sem_destroy(&queue_v3_handle->empty_sem);
		//sem_destroy(&queue_v3_handle->data_sem);
		pthread_cond_destroy(&queue_v3_handle->customer_cond);
		pthread_cond_destroy(&queue_v3_handle->producter_cond);
	}
	free(head);
	return;
    
err_2:    
	MESA_q_unlock_v3(queue_v3_handle);
	if(queue_v3_handle->thread_safe){
		pthread_mutex_destroy(&queue_v3_handle->mutex);
		pthread_cond_destroy(&queue_v3_handle->customer_cond);
		pthread_cond_destroy(&queue_v3_handle->producter_cond);
	}
	free(head);
err_1:
	return;
}

const char *MESA_lqueue_strerror(MESA_queue_errno_t error_num)
{
	const char *msg;
	
	switch((int)error_num){
		case MESA_QUEUE_RET_OK:
			msg = "success";
		break;

		case MESA_QUEUE_RET_COMMON_ERR:
			msg = "general error";
		break;
		
		case MESA_QUEUE_RET_ARG_ERR:
			msg = "arguments error";
		break;

		case MESA_QUEUE_RET_NUM_FULL:
			msg = "queue number full";
		break;

		case MESA_QUEUE_RET_MEM_FULL:
			msg = "queue memory full";
		break;

		case MESA_QUEUE_RET_QEMPTY:
			msg = "queue empty";
		break;

		case MESA_QUEUE_RET_LEN_ERR:
			msg = "length error";
		break;

		case MESA_QUEUE_RET_CANT_GET_LOCK:
			msg = "get lock error";
		break;

		case MESA_QUEUE_RET_GET_LOCK_TMOUT:
			msg = "get lock timeout";
		break;
		
		default:
			msg = "Invalid error num";
			break;
	}

	return msg;
}

#ifdef __cplusplus
}
#endif

