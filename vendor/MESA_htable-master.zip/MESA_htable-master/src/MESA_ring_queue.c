#ifdef __cplusplus
extern "C"
{
#endif

#include "MESA_ring_queue.h"
#include "MESA_list.h"
#include "MESA_atomic.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


const char * MESA_rqueue_version_VERSION_20160708 = "MESA_rqueue_version_VERSION_20160708";
const unsigned int MESA_RING_QUEUE_VERSION_INT = 20160708;

#define RQ_MULTI_LOCK_FREE_RESERVE_NUM   (2) /* ���߳��������б���Ԫ������ */

/*
    ��֤nextele��preeleλ�ò��䣬���Ը���list_common�еĲ���������
*/
typedef struct __mesa_rlist{
	struct __mesa_rlist	*nextele; /* ����ָ�������ڽṹ��ǰ2λ, ����MESA_list���� */
	struct __mesa_rlist	*preele;  /* ����ָ�������ڽṹ��ǰ2λ, ����MESA_list���� */
	void				*data;
	long				data_len;
}MESA_rlist_index_t;

typedef struct {
	struct __mesa_rlist	*root; /* ���ζ��еĸ�ָ��, createʱ�����������ζ���, destroyʱʹ�� */
	struct __mesa_rlist	*p_customer; /* ������ָ��, ָ�����һ�������ݵ�Ԫ��, ��ȡ���ݺ��ƶ� */
	struct __mesa_rlist	*p_producter;  /* ������ָ��, ִ���Ԫ��, �Ȳ�����ƶ� */
	union{
		volatile unsigned int cur_item_num; /* ��ǰʵ��Ԫ������ */
		MESA_ATOMIC_T cur_item_num_lock_free; /* ��ǰʵ��Ԫ������, ���߳�����ʵ�� */
	};
	volatile unsigned int ring_item_num; /* �������ζ��е����Ԫ������ */
	int thread_safe;
	int multi_thread_lock_free;
	int __pad[1];
	unsigned int pre_alloc_buf_len; /* ����8���ֽ���Ҫ�������ڴ�, С�ڵ���8�ֽ�, ֱ�Ӹ���dataָ��ռ� */			
	pthread_mutex_t	mutex;
	pthread_cond_t	customer_cond;
	pthread_cond_t	producter_cond;
}MESA_ring_inter_t;


static inline unsigned int __MESA_rq_cur_num_get(MESA_ring_inter_t *mesa_rq_handle)
{
	unsigned int res;
	if(mesa_rq_handle->multi_thread_lock_free != 0){
		res = MESA_ATOMIC_READ(mesa_rq_handle->cur_item_num_lock_free);		
	}else{
		res = mesa_rq_handle->cur_item_num;
	}

	return res;
}

static inline void __MESA_rq_cur_num_set(MESA_ring_inter_t *mesa_rq_handle, unsigned int num)
{
	if(mesa_rq_handle->multi_thread_lock_free != 0){
		MESA_ATOMIC_SET(mesa_rq_handle->cur_item_num_lock_free, num);		
	}else{
		mesa_rq_handle->cur_item_num = num;
	}

	return;
}

static inline void __MESA_rq_cur_num_inc(MESA_ring_inter_t *mesa_rq_handle)
{
	if(mesa_rq_handle->multi_thread_lock_free != 0){
		MESA_ATOMIC_INC(mesa_rq_handle->cur_item_num_lock_free);		
	}else{
		mesa_rq_handle->cur_item_num++;
	}

	return ;
}

static inline void __MESA_rq_cur_num_dec(MESA_ring_inter_t *mesa_rq_handle)
{
	if(mesa_rq_handle->multi_thread_lock_free != 0){
		MESA_ATOMIC_DEC(mesa_rq_handle->cur_item_num_lock_free);		
	}else{
		mesa_rq_handle->cur_item_num--;
	}

	return ;
}

static void __MESA_rq_set_default_opt(MESA_ring_inter_t *mesa_rq_handle)
{
	mesa_rq_handle->thread_safe = 1;  /* Ĭ��Ϊ�̰߳�ȫģʽ, ʲô����¶����� */
	mesa_rq_handle->ring_item_num = 10000;
	mesa_rq_handle->pre_alloc_buf_len = 0; /* Ĭ��Ϊ��ָ�뷽ʽ, ����������ռ� */		
	mesa_rq_handle->multi_thread_lock_free = 0;
}

static int __MESA_rq_opt_check(MESA_ring_inter_t *mesa_rq_handle)
{
	if((0 != mesa_rq_handle->thread_safe)
	 &&(0 != mesa_rq_handle->multi_thread_lock_free)){
		printf("\033[41mMESA_ring_queue opt conflict! thread_safe is %d, and  multi_thread_lock_free is:%d!\033[0m\n",
			mesa_rq_handle->thread_safe,  mesa_rq_handle->multi_thread_lock_free);
		return -1;
	}

	return 0;
}


static void __MESA_rq_create_ring(MESA_ring_inter_t *mesa_rq_handle)
{
	int i;
	struct __mesa_rlist *ring_item;

	if(mesa_rq_handle->pre_alloc_buf_len > sizeof(void *)){
		mesa_rq_handle->root->data = malloc(mesa_rq_handle->pre_alloc_buf_len);
	}
	
	for(i = 0; i < mesa_rq_handle->ring_item_num; i++){
		ring_item = malloc(sizeof(struct __mesa_rlist));
		if(mesa_rq_handle->pre_alloc_buf_len > sizeof(void *)){
			ring_item->data = malloc(mesa_rq_handle->pre_alloc_buf_len);
		}
		ring_item->data_len = 0;

		MESA_list_add((struct MESA_list *)mesa_rq_handle->root, (struct MESA_list *)ring_item);
	}

	mesa_rq_handle->p_customer = mesa_rq_handle->root;
	mesa_rq_handle->p_producter = mesa_rq_handle->root;

	__MESA_rq_cur_num_set(mesa_rq_handle, 0);

	return;
}

static int __MESA_rq_lock(MESA_ring_inter_t *mesa_rq_handle, int block)
{
	int ret = MESA_RQUEUE_RET_OK;

	if(mesa_rq_handle->thread_safe){
		if(block){
			ret = pthread_mutex_lock(&mesa_rq_handle->mutex);
			if(ret != 0){
				ret = MESA_RQUEUE_RET_CANT_GET_LOCK;
			}
		}else{
			ret = pthread_mutex_trylock(&mesa_rq_handle->mutex);
			if(ret != 0){
				ret = MESA_RQUEUE_RET_CANT_GET_LOCK;
			}
		}
	}else{
		ret = MESA_RQUEUE_RET_OK;
	}

	return ret;
}

static int __MESA_rq_unlock(MESA_ring_inter_t *mesa_rq_handle)
{
	int ret = MESA_RQUEUE_RET_OK;

	if(mesa_rq_handle->thread_safe){
		ret = pthread_mutex_unlock(&mesa_rq_handle->mutex);
		if(ret != 0){
			ret = MESA_RQUEUE_RET_CANT_GET_LOCK;
		}
	}else{
		ret = MESA_RQUEUE_RET_OK;
	}

	return ret;
}

static int __MESA_rq_wait(MESA_ring_inter_t *mesa_rq_handle, int op_get, int block)
{
	int ret = -1;

	if(mesa_rq_handle->multi_thread_lock_free != 0){
		if(block){
			if(op_get){
				while(__MESA_rq_cur_num_get(mesa_rq_handle) <= RQ_MULTI_LOCK_FREE_RESERVE_NUM){
					usleep(1);
				}
			}else{
				while(__MESA_rq_cur_num_get(mesa_rq_handle) >= mesa_rq_handle->ring_item_num-RQ_MULTI_LOCK_FREE_RESERVE_NUM){
					usleep(1);
				}
			}
		}else{
			ret = -1;
		}
	}else{
		if(mesa_rq_handle->thread_safe){
			if(block){
				if(op_get != 0){
					ret = pthread_cond_wait(&mesa_rq_handle->customer_cond, &mesa_rq_handle->mutex);
				}else{
					ret = pthread_cond_wait(&mesa_rq_handle->producter_cond, &mesa_rq_handle->mutex);
				}
				if(ret != 0){
					ret = -1;
				}
			}else{ /* ������ģʽ��, ֱ�ӷ���ʧ�� */
				ret = -1;
			}
		}else{
			/* ���̰߳�ȫʽ��, ��Ϊ�ǵ��̴߳���, ��������������, ֱ�ӷ���ʧ��,  */
			ret = -1;
		}
	}

	return ret;
}


static int __rq_can_i_do_it(MESA_ring_inter_t *mesa_rq_handle, int op_get, int block)
{
	int ret = MESA_RQUEUE_RET_OK;
	unsigned cur_rqitem_num;
	
	ret = __MESA_rq_lock(mesa_rq_handle, block);
	if(ret < 0){
		ret = MESA_RQUEUE_RET_CANT_GET_LOCK;
		goto err1;
	}

	cur_rqitem_num = __MESA_rq_cur_num_get(mesa_rq_handle);

	if(0 == op_get){  /* join */
		if(mesa_rq_handle->multi_thread_lock_free != 0){
			if(cur_rqitem_num >= mesa_rq_handle->ring_item_num-RQ_MULTI_LOCK_FREE_RESERVE_NUM){ /* �������й̶�����2�����ϵ�Ԫ��, ��ָ֤�벻��ͻ */
				ret = __MESA_rq_wait(mesa_rq_handle, op_get, block);
				if(ret < 0){
					ret = MESA_RQUEUE_RET_NUM_FULL;
					goto err2;
				}
			}else{
				ret = MESA_RQUEUE_RET_OK;
			}
		}else{
			 if(cur_rqitem_num >= mesa_rq_handle->ring_item_num){
				ret = __MESA_rq_wait(mesa_rq_handle, op_get, block);
				if(ret < 0){
					ret = MESA_RQUEUE_RET_NUM_FULL;
					goto err2;
				}
			}else{
				ret = MESA_RQUEUE_RET_OK;
			}
		}
	}else{ /* get  */
		if(mesa_rq_handle->multi_thread_lock_free != 0){
			if(cur_rqitem_num <= RQ_MULTI_LOCK_FREE_RESERVE_NUM){ /* �������й̶�����2�����ϵ�Ԫ��, ��ָ֤�벻��ͻ */
				ret = __MESA_rq_wait(mesa_rq_handle, op_get, block);
				if(ret < 0){
					ret = MESA_RQUEUE_RET_QEMPTY;
					goto err2;
				}
			}else{
				ret = MESA_RQUEUE_RET_OK;
			}
		}else{
			if(0 == cur_rqitem_num){
				ret = __MESA_rq_wait(mesa_rq_handle, op_get, block);
				if(ret < 0){
					ret = MESA_RQUEUE_RET_QEMPTY;
					goto err2;
				}
			}else{
				ret = MESA_RQUEUE_RET_OK;
			}
		}
	}
	
	return ret;

err2:
	__MESA_rq_unlock(mesa_rq_handle);
err1:
	return ret;
}


static int __MESA_rq_read(MESA_ring_inter_t *mesa_rq_handle, void *data, int *data_len, int block)
{
	int ret = MESA_RQUEUE_RET_OK;
	int item_data_len;

	ret = __rq_can_i_do_it(mesa_rq_handle, 1, block);
	if(ret < 0){
		goto err1;
	}
	
	if(mesa_rq_handle->p_customer == mesa_rq_handle->p_producter){
		ret = MESA_RQUEUE_RET_QEMPTY;
		goto err2;
	}

	item_data_len = mesa_rq_handle->p_customer->data_len;
	if(*data_len < item_data_len){
		ret = MESA_RQUEUE_RET_LEN_ERR;
		goto err2;
	}
	if(item_data_len <= sizeof(void *)){
		memcpy(data, &mesa_rq_handle->p_customer->data, item_data_len);
	}else{
		memcpy(data, mesa_rq_handle->p_customer->data, item_data_len);
	}
	*data_len = item_data_len;
	__MESA_rq_unlock(mesa_rq_handle);	

	return ret;

err2:
	__MESA_rq_unlock(mesa_rq_handle);
err1:
	return ret;
}


static int __MESA_rq_get(MESA_ring_inter_t *mesa_rq_handle, void *data, int *data_len, int block)
{
	int ret = MESA_RQUEUE_RET_OK;
	int item_data_len;

	ret = __rq_can_i_do_it(mesa_rq_handle, 1 ,block);
	if(ret < 0){
		goto err1;
	}
	
	if(mesa_rq_handle->p_customer == mesa_rq_handle->p_producter){
		ret = MESA_RQUEUE_RET_QEMPTY;
		goto err2;
	}

	item_data_len = mesa_rq_handle->p_customer->data_len;
	if(*data_len < item_data_len){
		ret = MESA_RQUEUE_RET_LEN_ERR;
		goto err2;
	}
	if(mesa_rq_handle->pre_alloc_buf_len > sizeof(void *)){
		memcpy(data, mesa_rq_handle->p_customer->data, item_data_len);
	}else{
		if(item_data_len <= sizeof(void *)){
			
			memcpy(data, &mesa_rq_handle->p_customer->data, item_data_len);
		}else{
			memcpy(data, mesa_rq_handle->p_customer->data, item_data_len);
		}
	}
	*data_len = item_data_len;

	if((0 == mesa_rq_handle->pre_alloc_buf_len)
	    && (item_data_len > sizeof(void *))){
		free(mesa_rq_handle->p_customer->data);
	}  

	mesa_rq_handle->p_customer = mesa_rq_handle->p_customer->nextele;
	//mesa_rq_handle->cur_item_num--;
	__MESA_rq_cur_num_dec(mesa_rq_handle);

	pthread_cond_signal(&mesa_rq_handle->producter_cond);
	
	__MESA_rq_unlock(mesa_rq_handle);	

	return ret;

err2:
	__MESA_rq_unlock(mesa_rq_handle);
err1:
	return ret;
}


static int __MESA_rq_join(MESA_ring_inter_t *mesa_rq_handle, const void *data, int data_len, int block)
{
	int ret = MESA_RQUEUE_RET_OK;

	ret = __rq_can_i_do_it(mesa_rq_handle, 0, block);
	if(ret < 0){
		goto err1;
	}
	
	if(mesa_rq_handle->p_producter->nextele == mesa_rq_handle->p_customer){
		ret = MESA_RQUEUE_RET_NUM_FULL;
		goto err2;
	}

	if(mesa_rq_handle->pre_alloc_buf_len > sizeof(void *)){
		if(data_len > mesa_rq_handle->pre_alloc_buf_len){
			ret = MESA_RQUEUE_RET_LEN_ERR;
			goto err2;
		}

		memcpy(mesa_rq_handle->p_producter->data, data, data_len);
	}else{
		if(data_len > sizeof(void *)){
			/* δԤ�ȷ���, �ռ䲻��, ��ʱ���� */	
			mesa_rq_handle->p_producter->data = malloc(data_len); 
			memcpy(mesa_rq_handle->p_producter->data, data, data_len);
		}else{
			memcpy(&mesa_rq_handle->p_producter->data, data, data_len);
		}
	}
	mesa_rq_handle->p_producter->data_len = data_len;
	mesa_rq_handle->p_producter = mesa_rq_handle->p_producter->nextele;
	//mesa_rq_handle->cur_item_num++;
	__MESA_rq_cur_num_inc(mesa_rq_handle);

	if(mesa_rq_handle->thread_safe != 0){
		pthread_cond_signal(&mesa_rq_handle->customer_cond);
	}
	
	__MESA_rq_unlock(mesa_rq_handle);	

	return ret;

err2:
	__MESA_rq_unlock(mesa_rq_handle);
err1:
	return ret;
}




MESA_ring_queue_head MESA_ring_queue_born(void)
{
	MESA_ring_inter_t *mesa_rq_handle = (MESA_ring_inter_t *)calloc(1, sizeof(MESA_ring_inter_t));

	__MESA_rq_set_default_opt(mesa_rq_handle);
	
	return (void *)mesa_rq_handle;
}


int MESA_ring_queue_set_opt(MESA_ring_queue_head rq, enum MESA_rq_opt opt_type, void *opt_val, int opt_len)
{
	assert(rq != NULL);

	int ret = 0;
	MESA_ring_inter_t *mesa_rq_handle = (MESA_ring_inter_t *)rq;
	
	switch(opt_type){
		case RQO_THREAD_SAFE:
			mesa_rq_handle->thread_safe = *((int *)opt_val);
		break;

		case RQO_RING_ELEMENT_NUM:
			mesa_rq_handle->ring_item_num = *((unsigned int *)opt_val);
		break;

		case RQO_PRE_ALLOC_BUF_LEN:
			mesa_rq_handle->pre_alloc_buf_len = *((unsigned int *)opt_val);
		break;

		case RQO_MULTI_THREAD_LOCK_FREE:
			mesa_rq_handle->multi_thread_lock_free = *((int *)opt_val);
		break;

		default:
			ret = -1;
			break;
	}

	return ret;
}


int MESA_ring_queue_mature(MESA_ring_queue_head rq)
{
	MESA_ring_inter_t *mesa_rq_handle = (MESA_ring_inter_t *)rq;

	assert(rq != NULL);

	if(__MESA_rq_opt_check(mesa_rq_handle) < 0){
		return -1;
	}

	if(mesa_rq_handle->thread_safe){
		pthread_mutex_init(&mesa_rq_handle->mutex, NULL);
		pthread_cond_init(&mesa_rq_handle->customer_cond, NULL);
		pthread_cond_init(&mesa_rq_handle->producter_cond, NULL);	
	}

	mesa_rq_handle->root = calloc(1, sizeof(struct __mesa_rlist));

	MESA_list_init_head((struct MESA_list *)mesa_rq_handle->root);	

	__MESA_rq_create_ring(mesa_rq_handle);

	return 0;
}


int MESA_ring_queue_get_count(MESA_ring_queue_head rq)
{
	MESA_ring_inter_t *mesa_rq_handle = (MESA_ring_inter_t *)rq;
	int cur_num;

	if(mesa_rq_handle->multi_thread_lock_free){
		cur_num =  MESA_ATOMIC_READ(mesa_rq_handle->cur_item_num_lock_free);
	}else{
		if(mesa_rq_handle->thread_safe){
			pthread_mutex_lock(&mesa_rq_handle->mutex);
			cur_num = mesa_rq_handle->cur_item_num;
			pthread_mutex_unlock(&mesa_rq_handle->mutex);
		}else{
			cur_num = mesa_rq_handle->cur_item_num;
		}
	}

	return cur_num;
}




int MESA_ring_queue_read(MESA_ring_queue_head rq_head, void *data, int *data_len)
{
	assert(rq_head && data && data_len);

	return __MESA_rq_read(rq_head, data, data_len, 1);
}


int MESA_ring_queue_try_read(MESA_ring_queue_head rq_head, void *data, int *data_len)
{
	assert(rq_head && data && data_len);

	return __MESA_rq_read(rq_head, data, data_len, 0);
}

int MESA_ring_queue_get(MESA_ring_queue_head rq_head, void *data, int *data_len)
{
	assert(rq_head && data && data_len);

	return __MESA_rq_get(rq_head, data, data_len, 1);
}


int MESA_ring_queue_try_get(MESA_ring_queue_head rq_head, void *data, int *data_len)
{
	assert(rq_head && data && data_len);

	return __MESA_rq_get(rq_head, data, data_len, 0);
}


int MESA_ring_queue_join(MESA_ring_queue_head rq_head, const void *data, int data_len)
{
	assert(rq_head && data && (data_len > 0));

	return __MESA_rq_join(rq_head, data, data_len, 1);
}


int MESA_ring_queue_try_join(MESA_ring_queue_head rq_head, const void *data, int data_len)
{
	assert(rq_head && data && (data_len > 0));

	return __MESA_rq_join(rq_head, data, data_len, 0);
}


void MESA_ring_queue_destroy(MESA_ring_queue_head rq_head, MESA_rqueue_cb_t cb, void *cb_arg)
{
	MESA_ring_inter_t *mesa_rq_handle = (MESA_ring_inter_t *)rq_head;
	struct __mesa_rlist *p_customer, *p_producter,  *item, *next;

	__MESA_rq_lock(mesa_rq_handle, 1);

	p_customer = mesa_rq_handle->p_customer;
	p_producter = mesa_rq_handle->p_producter;
	
	while(p_customer !=  p_producter){
		item = p_customer->nextele;
		if(p_customer->data_len >  sizeof(void *)){
			if(cb){
				(*cb)(p_customer->data, p_customer->data_len, cb_arg);
			}
			free(p_customer->data);
		}else{
			if(cb){
				(*cb)(&p_customer->data, p_customer->data_len, cb_arg);
			}
		}
		p_customer = item;
	}

	item = mesa_rq_handle->root->nextele;
	while(item != mesa_rq_handle->root){
		next = item->nextele;
		if(mesa_rq_handle->pre_alloc_buf_len >  sizeof(void *)){
			free(item->data);
		}
		free(item);
		item = next;
	}

	if(mesa_rq_handle->pre_alloc_buf_len >  sizeof(void *)){
		free(mesa_rq_handle->root->data);
	}
	free(mesa_rq_handle->root);

	pthread_mutex_destroy(&mesa_rq_handle->mutex);
	pthread_cond_destroy(&mesa_rq_handle->customer_cond);
	pthread_cond_destroy(&mesa_rq_handle->producter_cond);

	free(mesa_rq_handle);

	return;
}

const char *MESA_ring_queue_strerror(MESA_ring_queue_errno_t error_num)
{
	const char *msg;
	
	switch((int)error_num){
		case MESA_RQUEUE_RET_OK:
			msg = "success";
		break;

		case MESA_RQUEUE_RET_COMMON_ERR:
			msg = "general error";
		break;
		
		case MESA_RQUEUE_RET_ARG_ERR:
			msg = "arguments error";
		break;

		case MESA_RQUEUE_RET_NUM_FULL:
			msg = "queue number full";
		break;

		case MESA_RQUEUE_RET_MEM_FULL:
			msg = "queue memory full";
		break;

		case MESA_RQUEUE_RET_QEMPTY:
			msg = "queue empty";
		break;

		case MESA_RQUEUE_RET_LEN_ERR:
			msg = "length error";
		break;

		case MESA_RQUEUE_RET_CANT_GET_LOCK:
			msg = "get lock error";
		break;

		case MESA_RQUEUE_RET_GET_LOCK_TMOUT:
			msg = "get lock timeout";
		break;
		
		default:
			msg = "Invalid error num";
			break;
	}

	return msg;
}

#ifdef __cplusplus
}
#endif
