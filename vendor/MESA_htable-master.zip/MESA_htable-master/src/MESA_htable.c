#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdint.h>
#include <math.h>
#include <stdarg.h>
#include <execinfo.h>
#include "MESA_htable.h"
#include "MESA_list_queue.h"
#include "MESA_list_count.h"
#include "MESA_htable_internal.h"
#include "MESA_atomic.h"

#ifdef __cplusplus
}
#endif


#define N 999

#ifdef __cplusplus
extern "C"
{
#endif

#if MESA_HASH_DEBUG
#define HASH_INLINE 
#else
#define HASH_INLINE 			inline
#endif

const char *MESA_htable_version_VERSION_20181009 = "MESA_htable_version_VERSION_20181009";

const unsigned int MESA_HTABLE_VERSION_INT = 20181009;

#define MESA_HASH_LIST_COLLIDE_DETECT	(0)

/* 2014-09-24 lijia add, ������������ */
#define HARGS_BASE_LEN	(56)  /* ����data_expire_with_condition, ��COMPLEX_KEY_SWITCH */
#define HARGS_COMPLEX_KEY_LEN (72) /* COMPLEX_KEY_SWITCH������ */

#define HTABLE_INNER_BASE_LEN	(88) /* MESA_htable_inner_t �ڲ��ṹ���� */
#define HTABLE_INNER_PRINT_SW_LEN	(96) /* MESA_htable_inner_t, ����print_switch */
#define HTABLE_INNER_COMPLEX_KEY_LEN	(112) /* MESA_htable_inner_t, ����complex_key */

#define THREAD_PID_INIT1	((pthread_t)0)
#define THREAD_PID_INIT2	((pthread_t)~0)

#define MHT_PRINT(table, format, args...)    do{if(((MESA_htable_inner_t *)table)->print_switch){fprintf(stderr, format, ##args);}}while(0)

#define MHT_DEFAULT_LOG_FILE_PATTERN  "./log/htable_runtime_%d_%u.%u.log" 


/*
   �����ܼ�������ͻ��ÿN��Hash-slot����һ��������,
   (HASH_Index % HASH_TABLE_MUTEX_NUM)��ֵ��ͬ��item����һ��mutex.

   ͨ������֤��, ����������������1024��, ����������΢�����, �������ֵΪ1024.
*/
#define HASH_TABLE_MUTEX_NUM		(1024)     

/*
 * hash element structure.
 *
 * key : a copy of key;
 * size: size of key;
 * hash_index: index which use this key and key2index_fun_t() calculated;
 * data: pointer to attached data;
 * prev, next: pointer to prev and next item;
 */
typedef struct struct_hash_elem {
	uchar  *key;
	void   *data;
	uint   size; /* size of key */
	uint hash_value; /* ��key���������ԭʼhashֵ, 2017-11-08, �����Զ���չ����, ��ҪԭʼHASHֵ, ��Ϊhash_index���Ѿ�ӳ��ΪHASH_SLOT��λ��, ��չʱ�޷�������ӳ�䵽�µ�SLOT_INDEX */
	uint   hash_index; 
	uint op_time; /* ����ֻ���뼶, ʹ��uint����, ϵͳ��time_t����Ϊ8�ֽ�, û��Ҫ */
	struct struct_hash_elem *prev;
	struct struct_hash_elem *next;
	MESA_list_count_t list_node;
} htable_elem_t;


typedef struct{
	int opt_switch; /* �Ƿ��� */
	volatile uint current_time;
	pthread_t timer_thread_pid;
}htable_opt_time_t;


typedef struct{
	int max_item_search_times; /* ������ͻ�������������(����) */
	long long total_api_search_times; /* �ⲿ�����ܼƵ���MESA_htable_search()�Ĵ��� */
	long long total_item_search_times; /* �ⲿ��������ʱ, ����������ͻ������ܼƲ���Ԫ�ش��� */
}htable_search_status_t;


/*
 * hash structure.
 *
 * size: number of slots;
 * key_comp: pointer to the function that compares 2 keys;
 * key2index: pointer to the function that computes index from key;
 * expire: pointer to the function that do somthing when data expired;
 * free: pointer to the function that cleans up attached data;
 * elems: array of slots;
 * elem_count: number of items;
 * threshold_lo, threshold_hi: low and high threshold; when elem_count reaches
 * 	one of them, an iteration will be launched to clean up expired items;
 */
typedef struct {
	uint size;
	uint thread_safe;
	/************** 8byte separator ***********/
	int recursive;
	union{
		volatile uint elem_count_unsafe;
		volatile MESA_ATOMIC_T elem_count_safe;
	};
	/************** 8byte separator ***********/
	key_comp_fun_t * key_comp;
	key2index_fun_t * key2index;
	int (* expire)(void * data, int type);
	void (* free)(void * data);
	htable_elem_t ** elems;
	/************** 8byte separator ***********/
	unsigned int  max_elem_num;
	char eliminate_type;
	char print_switch;	
	unsigned char caller_hargs_len;
	char create_type; /* 0:init; 1:by MESA_htable_create(); 2:by MESA_htable_born(); */
	/************** 8byte separator ***********/
	int  expire_time;
	char is_running; /* htable����MESA_htable_mature֮��, is_running=1, �������ٵ���MESA_htable_set_opt() */
	unsigned char hash_list_collide_threshold; /* hash list number������ֵ��д������־�ļ�, Ĭ��100 */
	unsigned short mutex_num;
	/************** 8byte separator ***********/
	volatile multi_thread_cache_align_t *htable_in_use_flag; /* ���ڱ�ʶ��ǰhtable�Ƿ��ڱ�����, ���̰߳�ȫģʽÿ������¼һ����־, ���������߳�ģʽ */
	/************** 8byte separator ***********/
	pthread_mutex_t *htable_mutex;
	MESA_list_count_t *hlist_head;
	uchar* (*complex_key_dup)(const uchar *key, uint key_size);
	void (* complex_key_free)(uchar *key, uint key_size);
	/************** 8byte separator ***********/
	void *htable_option[__MHO_MAX_VAL]; /* 2016-01-27 lijia add, �����¹���ʹ��ѡ��, ��ȷ����ʲôѡ������, ʹ��void *�洢 */
	/************** 8byte separator ***********/
	unsigned char *hash_bucket_item_num; /* ÿ��bucket�´洢��item����, ���ʹ������, ��hash��ͻ����, ���255, �Ѿ��ǳ�Ӱ�������� */
	/************** 8byte separator ***********/
	uint initialize_slot_size; /* ��ʼ��ʱ�趨�����SLOT_SIZE, �����Զ���չ */
	htable_search_status_t hash_search_status;
	const char *htable_log_filename; /* htable��־�ļ���, malloc���ڴ�, destroyʱҪfree. */
	/************** 8byte separator ***********/
	volatile MESA_ATOMIC_T auto_expand_spin_lock;
	unsigned int random_prime; /* 20171110 lijia add, ���������, ����murmur_hash�㷨 */
} MESA_htable_inner_t;


enum htable_create_type
{
	HTABLE_CREATE_TYPE_ORIGINAL 	= 1,
	HTABLE_CREATE_TYPE_BORN		= 2,	 /* 2016-01-31 lijia add new API */
};

typedef struct{
	enum MESA_htable_opt opt_type;	
	int (*MESA_htable_set_opt_fun)(MESA_htable_handle table, enum MESA_htable_opt opt_type, void *opt_val, int opt_len);	
	int (*MESA_htable_get_opt_fun)(MESA_htable_handle table, enum MESA_htable_opt opt_type, void *opt_val, int *opt_len);	
	/* ��Ҫ�������⴦����ѡ������, ���Զ�����ʱ�书��, Ҫ��̨������һ���߳� */
	int (*MESA_htable_process_opt_fun)(MESA_htable_handle table);	
	void (*MESA_htable_free_opt_fun)(MESA_htable_inner_t *table);
}MESA_opt_manage_t;

static void __MESA_hash_log(MESA_htable_inner_t *table, const char * format, ...);

#if MESA_HASH_LIST_COLLIDE_DETECT
static char backtrace_print_buf[4096];
static int __MH_exec_shell(const char*cmd ,char* buff,int buff_size)
{
	FILE* fp = popen(cmd, "r");
	if(fp==NULL)
	{
		return -1;
	}
	memset(buff,0,buff_size);
	fgets(buff,buff_size,fp);
	pclose(fp);
	return strlen(buff);
}

static int __MH_get_backtrace_string(void* bt,char* buff,int buff_size)
{
	char cmd[128] = {0};
	char property[256]={0};
	char not_care1[128]={0},not_care2[128]={0},not_care3[128]={0};
	char library_path[256]={0};
	char exe_path[256]={0},function_name[256]={0};
	char maps_line[1024]={0};
	void* offset_start,*offset_end;
	int ret , maps_column_num=0;
	FILE* fd_maps=NULL;
	fd_maps=fopen("/proc/self/maps","r");
	unsigned long exe_symbol_offset=0;
	const char* unknow_position="??:0\n";
	if(fd_maps==NULL)
	{
		return -1;
	}
	while(NULL!=fgets(maps_line,sizeof(maps_line),fd_maps))
	{
		maps_column_num=sscanf(maps_line,"%p-%p\t%s\t%s\t%s\t%s\t%s"
														,&offset_start
														,&offset_end
														,property
														,not_care1
														,not_care2
														,not_care3
														,library_path);
		if(maps_column_num==7&&bt>=offset_start&&bt<=offset_end)
		{
			break;
		}
		
	}
	fclose(fd_maps);
	memset(exe_path,0,sizeof(exe_path));
	readlink("/proc/self/exe", exe_path, sizeof(exe_path));
	if(exe_path[strlen(exe_path)-1]=='\n')
	{
		exe_path[strlen(exe_path)-1]='\0';
	}
	if(0==strcmp(exe_path,library_path))
	{
		exe_symbol_offset=(unsigned long)bt;
	}
	else
	{
		exe_symbol_offset=(char*)bt-(char*)offset_start;
	}
	snprintf(cmd,sizeof(cmd),"addr2line -C -e %s 0x%lx",library_path,exe_symbol_offset);
	ret = __MH_exec_shell(cmd, buff, buff_size);
	if(ret < 0){
		return -1;
	}
	if(0==strcmp(buff,unknow_position))
	{
		snprintf(cmd,sizeof(cmd),"addr2line -Cif -e %s 0x%lx",library_path,exe_symbol_offset);
		ret = __MH_exec_shell(cmd, function_name, sizeof(function_name));
		if(ret < 0){
			return -1;
		}		
		function_name[strlen(function_name)-1]='\0';
		snprintf(buff,buff_size,"%s(%s+0x%lx)\n",library_path,function_name,exe_symbol_offset);
	}
	return 0;
}
static void __MH_backtrace_print(MESA_htable_inner_t *table, int hlist_collide_num)
{
#define SIZE 32
           int ret, j, nptrs;
           FILE *fp;
           void *buffer[SIZE];
           char **strings;
           nptrs = backtrace(buffer, SIZE);

           /* The call backtrace_symbols_fd(buffer, nptrs, STDOUT_FILENO)
 *               would produce similar output to the following: */

           strings = backtrace_symbols(buffer, nptrs);
           if (strings == NULL) {
		return;
           }

		fp = fopen(table->htable_log_filename, "a+");
		if(NULL == fp){
			return;
		}

		fprintf(fp, "--------------In this functions stack, hlist collide number:%d------------\n", hlist_collide_num);
           for (j = 0; j < nptrs; j++){
               //fprintf(fp, "%s\n", strings[j]);
               ret = __MH_get_backtrace_string(buffer[j], backtrace_print_buf, 4096);
               if(ret < 0){
			continue;
               }
               fprintf(fp, "%s", backtrace_print_buf);
           }    
           fprintf(fp, "----------------------------------------------------------------------\n");

           free(strings);
           fclose(fp);
}
#endif

static int __MHO_set_opt_thread_safe(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->thread_safe = *((unsigned int *)opt_val);

	if(0 == table->thread_safe){
		table->mutex_num = 0; /* ���̰߳�ȫģʽ��, ��������������Ϊ0, ��Ϊ__MESA_htable_set_default_opt()��Ĭ����Ϊ1 */
	}

	return 0;
}


static int __MHO_set_opt_mutex_num(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	if(*((int *)opt_val) <= 0){
		printf("Error!Hash mutex number must bigger than zero!\n");
		return -1;
	}
	
	table->mutex_num = *((int *)opt_val); 
	if(table->mutex_num > HASH_TABLE_MUTEX_NUM){
		printf("Warning! Max hash mutex num is:%d\n", HASH_TABLE_MUTEX_NUM);
		table->mutex_num = HASH_TABLE_MUTEX_NUM;
	}

	return 0;
}

static int __MHO_set_opt_slot_size(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->size = *((unsigned int *)opt_val);

	if(table->size < 1024){
		printf("Warning! Hash slot size is:%u, maybe more colliding!\n", table->size);
	}

	return 0;
}

static int __MHO_set_opt_max_ele_num(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->max_elem_num = *((unsigned int *)opt_val);

	return 0;
}

static int __MHO_set_opt_expire_time(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->expire_time = *((int *)opt_val);

	return 0;
}

static int __MHO_set_opt_expire_type(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->eliminate_type = *((int *)opt_val);

	if((HASH_ELIMINATE_ALGO_FIFO != table->eliminate_type)
	 && (HASH_ELIMINATE_ALGO_LRU != table->eliminate_type)){
		printf("Error! Hash eliminate type invalid: %d\n", table->eliminate_type);
		return -1;
	}

	return 0;
}

static int __MHO_set_opt_key_compare(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(void *)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->key_comp = opt_val;

	return 0;
}

static int __MHO_set_opt_key2index(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(void *)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->key2index = opt_val;

	return 0;
}

static int __MHO_set_opt_data_free(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(void *)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->free = opt_val;

	return 0;
}

static int __MHO_set_opt_expire_notify(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(void *)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->expire = opt_val;

	return 0;
}

static int __MHO_set_opt_key_dup(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(void *)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->complex_key_dup = opt_val;

	return 0;
}

static int __MHO_set_opt_key_free(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(void *)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->complex_key_free = opt_val;

	return 0;
}

static int __MHO_set_opt_auto_update_time(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	htable_opt_time_t *time_opt;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	if(*((int *)opt_val) != 0){
		time_opt = table->htable_option[MHO_AUTO_UPDATE_TIME];
		time_opt = (htable_opt_time_t *)HASH_MALLOC(sizeof(htable_opt_time_t));
		memset(time_opt, 0, sizeof(htable_opt_time_t));
		time_opt->opt_switch = *((int *)opt_val);
		table->htable_option[MHO_AUTO_UPDATE_TIME] = time_opt;
	}else{
		table->htable_option[MHO_AUTO_UPDATE_TIME] = NULL;
	}
	
	return 0;
}

static int __MHO_set_opt_screen_print(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;

	table->print_switch = *((int *)opt_val);

	return 0;
}

static int __MHO_set_opt_collide_threshold(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	
	if(opt_len != sizeof(int)){
		return -1;
	}

	if(*((int *)opt_val) > 255){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;
	table->hash_list_collide_threshold = (unsigned char)*((int *)opt_val);

	return 0;
}

static int __MHO_set_opt_runtime_log(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;

	table = (MESA_htable_inner_t *)apitable;

	if(table->htable_log_filename != NULL){
		table->htable_log_filename = (const char *)realloc((void *)table->htable_log_filename, opt_len + 1);
	}else{
		table->htable_log_filename = (const char *)malloc(opt_len + 1);
	}

	memcpy((void *)table->htable_log_filename, opt_val, opt_len + 1);

	return 0;
}

static void *__MESA_htable_update_time(void *arg)
{
	htable_opt_time_t *time_opt = (htable_opt_time_t *)arg;

	while(1){
		if(unlikely(time_opt->current_time < time(NULL))){
			time_opt->current_time = time(NULL);
		}
		usleep(1000 * 10);
	}

	return NULL;
}

static int __MHO_proc_opt_mutex_num(MESA_htable_handle apitable)
{
	int i, ret = 0;
	MESA_htable_inner_t *table;
	pthread_mutexattr_t attr; 
	int attr_type;

	table = (MESA_htable_inner_t *)apitable;

	if(table->mutex_num > 0){
		table->htable_mutex = (pthread_mutex_t *)HASH_MALLOC(sizeof(pthread_mutex_t) * table->mutex_num);

		for(i = 0; i < table->mutex_num; i++){
	        	pthread_mutexattr_init(&attr);
	        	pthread_mutexattr_gettype(&attr, &attr_type);
	        	attr_type |= PTHREAD_MUTEX_RECURSIVE_NP; /* can be recursive call */
	        	pthread_mutexattr_settype(&attr, attr_type);
	        	ret = pthread_mutex_init(&table->htable_mutex[i], &attr);
	        	if(ret != 0){
				break;
	        	}
	       }   

		table->hlist_head = (MESA_list_count_t *)HASH_MALLOC(sizeof(MESA_list_count_t) * table->mutex_num);      
		for(i=0; i < table->mutex_num; i++){
			MESA_list_count_init_head(&(table->hlist_head[i]));
		}
	}else{
		/* ������Ϊ0ʱ, ����һ��head�ڵ�, ���ڼ�¼��ǰMUTEX_INDEX��Ԫ������ */
		table->hlist_head = (MESA_list_count_t *)HASH_MALLOC(sizeof(MESA_list_count_t));
		MESA_list_count_init_head(&table->hlist_head[0]);
	}
        
	return ret;
}


static void __MHO_free_opt_slot_size(MESA_htable_inner_t *table)
{
	HASH_FREE(table->elems);
}

static void __MHO_free_opt_mutex_num(MESA_htable_inner_t *table)
{
	int i;

	if(table->mutex_num > 0){
		for(i = 0; i < table->mutex_num; i++){
			pthread_mutex_destroy(&table->htable_mutex[i]);
		}
		HASH_FREE(table->htable_mutex);
	}

	HASH_FREE(table->hlist_head);
}

static int __MHO_proc_opt_auto_update_time(MESA_htable_handle apitable)
{
	MESA_htable_inner_t *table;

	table = (MESA_htable_inner_t *)apitable;
	
	htable_opt_time_t *time_opt = table->htable_option[MHO_AUTO_UPDATE_TIME];
	/* 2015-01-04 lijia add, ��̨����ʱ������߳�, ����ÿ�ζ�����time(0), ���������� */
	if((time_opt != NULL) && (time_opt->opt_switch != 0)){
		pthread_create(&time_opt->timer_thread_pid, NULL, __MESA_htable_update_time, time_opt);
		pthread_detach(time_opt->timer_thread_pid);
		sched_yield();
		time_opt->current_time = time(NULL);
	}

	return 0;
}


static int __MHO_proc_opt_slot_size(MESA_htable_handle apitable)
{
	MESA_htable_inner_t *table;

	table = (MESA_htable_inner_t *)apitable;

	table->elems = (htable_elem_t **)HASH_MALLOC(table->size * sizeof(void *));
	memset(table->elems, 0, table->size * sizeof(void *));

	return 0;
}

static void __MHO_free_opt_auto_update_time(MESA_htable_inner_t *table)
{
	htable_opt_time_t *time_opt = table->htable_option[MHO_AUTO_UPDATE_TIME];
	
	if(time_opt != NULL){
		pthread_cancel(time_opt->timer_thread_pid);
		sched_yield();
		HASH_FREE(time_opt);
	}
}

static void __MHO_free_opt_runtime_log(MESA_htable_inner_t *table)
{
	free((void *)table->htable_log_filename);
}

static int __MHO_get_opt_max_search_times(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int *opt_len)
{
	MESA_htable_inner_t *table;
	int *max_times;

	if((NULL == opt_val) || (NULL == opt_len) || (*opt_len != sizeof(int))){
		return -1;
	}
	
	table = (MESA_htable_inner_t *)apitable;
	max_times = (int *)opt_val;

	*max_times = table->hash_search_status.max_item_search_times;

	return 0;
}

static int __MHO_get_opt_avg_search_times(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int *opt_len)
{
	MESA_htable_inner_t *table;
	double *avg_times;

	if((NULL == opt_val) || (NULL == opt_len) || (*opt_len != sizeof(double))){
		return -1;
	}
	
	table = (MESA_htable_inner_t *)apitable;
	avg_times = (double *)opt_val;

	*avg_times = (double)table->hash_search_status.total_item_search_times/(double)table->hash_search_status.total_api_search_times;

	return 0;
}

static int __MHO_set_opt_auto_expand(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{
	MESA_htable_inner_t *table;
	int *expand_multiple;

	if((NULL == opt_val) || (opt_len != sizeof(int))){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;
	expand_multiple = (int *)opt_val;

	table->htable_option[MHO_AUTO_EXPAND_MULTIPLE] = (void *)((long long )(*expand_multiple));

	return 0;
}

static int __MHO_get_opt_auto_expand(MESA_htable_handle apitable, enum MESA_htable_opt opt_type, void *opt_val, int *opt_len)
{
	MESA_htable_inner_t *table;
	int *expand_multiple;

	if((NULL == opt_val) || (NULL == opt_len) || (*opt_len != sizeof(int))){
		return -1;
	}

	table = (MESA_htable_inner_t *)apitable;
	expand_multiple = (int *)opt_val;

	(*expand_multiple) = (int)((long long)table->htable_option[MHO_AUTO_EXPAND_MULTIPLE]);

	return 0;
}

static int __MHO_proc_opt_auto_expand(MESA_htable_handle apitable)
{
	MESA_htable_inner_t *table;

	table = (MESA_htable_inner_t *)apitable;

	table->initialize_slot_size = table->size;

	MESA_ATOMIC_SET(table->auto_expand_spin_lock, 0);

	if(table->thread_safe > 0){
		table->htable_in_use_flag = (multi_thread_cache_align_t *)calloc(1, table->mutex_num * sizeof(multi_thread_cache_align_t));
	}else{
		/* ���̰߳�ȫģʽ, �������߳�ͬʱ��ȡ, ���ᴥ��auto_expand; ����һ���߳�д, ����auto_expandҲ����ν */
		table->htable_in_use_flag = NULL;
	}
	
	return 0;
}


static MESA_opt_manage_t MESA_OPT_MANAGE[__MHO_MAX_VAL] =
{
	{MHO_THREAD_SAFE, 		__MHO_set_opt_thread_safe, 		NULL, NULL,	NULL},
	{MHO_MUTEX_NUM, 			__MHO_set_opt_mutex_num, 		NULL, __MHO_proc_opt_mutex_num,	__MHO_free_opt_mutex_num},
	{MHO_HASH_SLOT_SIZE, 		__MHO_set_opt_slot_size,	 		NULL, __MHO_proc_opt_slot_size,	     __MHO_free_opt_slot_size},
	{MHO_HASH_MAX_ELEMENT_NUM, __MHO_set_opt_max_ele_num, 	NULL, NULL, NULL},
	{MHO_EXPIRE_TIME, 			__MHO_set_opt_expire_time, 		NULL, NULL,	NULL},
	{MHO_ELIMIMINATE_TYPE, 	__MHO_set_opt_expire_type, 		NULL, NULL,	NULL},
	{MHO_CBFUN_KEY_COMPARE, __MHO_set_opt_key_compare, 	NULL, NULL,	NULL},
	{MHO_CBFUN_KEY_TO_INDEX, __MHO_set_opt_key2index, 		NULL, NULL,	NULL},
	{MHO_CBFUN_DATA_FREE,	__MHO_set_opt_data_free, 			NULL, NULL,	NULL},
	{MHO_CBFUN_DATA_EXPIRE_NOTIFY, __MHO_set_opt_expire_notify, 	NULL, NULL,	NULL},
	{MHO_CBFUN_COMPLEX_KEY_DUP, __MHO_set_opt_key_dup, 	NULL, NULL,	NULL},
	{MHO_CBFUN_COMPLEX_KEY_FREE, __MHO_set_opt_key_free, 	NULL, NULL,	NULL},
	{MHO_AUTO_UPDATE_TIME, 	__MHO_set_opt_auto_update_time, 	NULL, __MHO_proc_opt_auto_update_time, __MHO_free_opt_auto_update_time},
	{MHO_SCREEN_PRINT_CTRL,	__MHO_set_opt_screen_print, 		NULL, NULL,	NULL},
	{MHO_HASH_LIST_COLLIDE_THRESHOLD, __MHO_set_opt_collide_threshold, NULL, NULL, NULL},
	{MHO_HASH_LOG_FILE, __MHO_set_opt_runtime_log, NULL, NULL,  __MHO_free_opt_runtime_log},
	{MHO_HASH_SEARCH_MAX_TIMES, NULL,  __MHO_get_opt_max_search_times,  NULL, NULL},
	{MHO_HASH_SEARCH_AVG_TIMES, NULL,  __MHO_get_opt_avg_search_times,  NULL, NULL},
	{MHO_AUTO_EXPAND_MULTIPLE,	__MHO_set_opt_auto_expand, __MHO_get_opt_auto_expand, __MHO_proc_opt_auto_expand, NULL}
};

void MESA_htable_print_crtl(MESA_htable_handle api_table, int print_switch)
{
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	table->print_switch = print_switch;

	return;
}
 
/*
 * hash implementation, xh, 2001-07-26
 */
 
/*Developer Notice:
    in hash_add function,hash table MALLOC memory for keys and  RECORD data pointer,
    which means need NOT malloc memory for keys before call hash_add. zhengchao

    2013-05, LiJia, add thread safe implement.
*/
   

/* return value:
	1:first time get lock success;
	0:can't get lock.
*/
static HASH_INLINE int __MESA_hash_mutex_lock(const MESA_htable_inner_t * table, uint slot_index)
{   
	int get_lock = 0;
	int mutex_index;
#if 0
	
	pthread_t my_id = pthread_self();

	
	if(table->thread_safe != 0){
		mutex_index = slot_index % table->thread_safe;
		if(pthread_equal(my_id, table->acquire_lock1[mutex_index]) 
		  && pthread_equal(my_id, table->acquire_lock2[mutex_index])){
			get_lock = 0; /* already get lock */
		}else{
			ret = pthread_mutex_lock(&table->htable_mutex[mutex_index]);
			if(0 == ret){
				table->acquire_lock1[mutex_index] = my_id;
				table->acquire_lock2[mutex_index] = my_id;
				get_lock = 1;
			}
		}
	}
	
	return get_lock;
#else
	if(table->thread_safe != 0){
		mutex_index = slot_index % table->mutex_num;
		get_lock = pthread_mutex_lock(&table->htable_mutex[mutex_index]);
	}

	return get_lock;
#endif
}

static HASH_INLINE int __MESA_hash_mutex_unlock(const MESA_htable_inner_t * table, uint slot_index)
{
	int ret = 0;
	int mutex_index;
#if 0
	pthread_t my_id = pthread_self();
	
	if(table->thread_safe != 0){
		mutex_index = slot_index % table->thread_safe;
		if(pthread_equal(my_id, table->acquire_lock1[mutex_index]) 
		  && pthread_equal(my_id, table->acquire_lock2[mutex_index])){
			table->acquire_lock1[mutex_index] = THREAD_PID_INIT1;
			table->acquire_lock2[mutex_index] = THREAD_PID_INIT2;
			ret = pthread_mutex_unlock(&table->htable_mutex[mutex_index]);
		}else{
			ret = 0;
		}
	}
#else
	if(table->thread_safe != 0){
		mutex_index = slot_index % table->mutex_num;
		ret = pthread_mutex_unlock(&table->htable_mutex[mutex_index]);
	}	
#endif
	return ret;
}

static int __MESA_hash_time_list_insert(MESA_htable_inner_t *table, 
                                       htable_elem_t *hash_elem, uint index)
{
    int ret = 0;
    MESA_list_count_t *list_head;

    if(table->thread_safe > 0){
        list_head = &table->hlist_head[index%table->mutex_num];
    }else{
        list_head = &table->hlist_head[0];
    }

    MESA_list_count_add_tail(list_head, &hash_elem->list_node);

    return ret;
}

static HASH_INLINE void __MESA_hash_time_list_delete(MESA_htable_inner_t *table,
                                             htable_elem_t *hash_elem, uint index)
{
    MESA_list_count_t *list_head;

    if(table->thread_safe > 0){
        list_head = &table->hlist_head[index%table->mutex_num];
    }else{
        list_head = &table->hlist_head[0];
    }
    MESA_list_count_del(list_head, &hash_elem->list_node);

    

    return;
}

static inline uint __MESA_htable_get_time_now(const MESA_htable_inner_t *table)
{
	htable_opt_time_t *time_opt = table->htable_option[MHO_AUTO_UPDATE_TIME];

	if((NULL == time_opt) || (0 == time_opt->opt_switch)){
		return (uint)time(NULL);
	}

	return time_opt->current_time;
}

static HASH_INLINE void __MESA_hash_time_list_lru(MESA_htable_inner_t *table, 
                                    htable_elem_t *hash_elem, uint index)
{
	MESA_list_count_t *list_head;

	if(table->expire_time != 0){
		hash_elem->op_time = __MESA_htable_get_time_now(table);
	}
	if(table->thread_safe > 0){
		list_head = &table->hlist_head[index%table->mutex_num];
	}else{
		list_head = &table->hlist_head[0];
	}

	MESA_list_count_move_tail(list_head, &hash_elem->list_node);

	return;
}

static HASH_INLINE int __MESA_hash_bucket_lru(MESA_htable_inner_t *table, 
                                    htable_elem_t *cur_elem, uint index)
{
	if(cur_elem != table->elems[index]){ 
		/* �����ǰԪ�ز��ڵ�ǰbucket��һ��λ����, ���ƶ���bucket��һλ, �´β��Ҽ������ֻ��Ҫһ�� */

		if(NULL != cur_elem->prev){ 
		    cur_elem->prev->next = cur_elem->next;
		}else{
		    assert(0); /* serious BUG! */
		}
		
		if(NULL != cur_elem->next){
		    cur_elem->next->prev = cur_elem->prev;
		}

		cur_elem->next = table->elems[index];
		table->elems[index]->prev = cur_elem;
		cur_elem->prev = NULL;
		table->elems[index] = cur_elem;
	}

	return 0;
}

/* 
    search HASH-table whether has duplicate key. 
*/
/*@null@*/ static htable_elem_t *__MESA_hash_key_search(MESA_htable_inner_t * table, 
                                    const uchar *key, uint size, uint index)
{
	htable_elem_t *ptr;
	key_comp_fun_t *keycmp_fun = table->key_comp;

	for(ptr = table->elems[index]; NULL != ptr; ptr = ptr->next) {
		if(keycmp_fun(ptr->key, ptr->size, key, size) == 0){
			break;
		}
	}

	return ptr;
}

/* 
    search HASH-table whether has duplicate key. 
    ���ڷ���������������Ϣ, ֻ��MESA_htable_search��MESA_htable_search_cb()����.
*/
static htable_elem_t *__MESA_hash_key_search_with_status_feedback(
			MESA_htable_inner_t * table, const uchar *key, uint size, uint index)
{
	htable_elem_t *ptr;
	key_comp_fun_t *keycmp_fun = table->key_comp;
	int this_item_search_times = 1; /* ����һ��, �޳�ͻʱΪ1 */

	for(ptr = table->elems[index]; NULL != ptr; ptr = ptr->next) {
		if(keycmp_fun(ptr->key, ptr->size, key, size) == 0){
			break;
		}
		this_item_search_times++;
	}

	if(this_item_search_times > table->hash_search_status.max_item_search_times){
		table->hash_search_status.max_item_search_times = this_item_search_times;
	}

	table->hash_search_status.total_api_search_times++;
	table->hash_search_status.total_item_search_times += (long long)this_item_search_times;

	return ptr;
}

static HASH_INLINE unsigned short __MESA_hash_list_insert(MESA_htable_inner_t * table, 
                                         htable_elem_t * ptr, uint index)
{
	unsigned short ret;
	htable_elem_t **helems = table->elems;
	
	ptr->prev = NULL;
	ptr->next = helems[index];
	if(NULL != helems[index]){ 
	    helems[index]->prev = ptr;
	}    
	helems[index] = ptr;
	
	if(table->thread_safe > 0){
		MESA_ATOMIC_INC(table->elem_count_safe);
	}else{
		table->elem_count_unsafe++;
	}

	/* ��¼ÿ��SLOT��ͻ�������Ԫ���� */
	if(table->hash_bucket_item_num[index] < 255){
		ret = ++table->hash_bucket_item_num[index];
	}else{
		ret = table->hash_bucket_item_num[index];
	}
	
	return ret;
}

static HASH_INLINE void __MESA_hash_list_delete(MESA_htable_inner_t * table, 
                                         htable_elem_t * ptr, uint index)
{
	if(NULL != ptr->prev){ 
	    ptr->prev->next = ptr->next;
	}else{
	    table->elems[index] = ptr->next;
	}
	
	if(NULL != ptr->next){
	    ptr->next->prev = ptr->prev;
	}

	if(table->thread_safe > 0){
		MESA_ATOMIC_DEC(table->elem_count_safe);
	}else{
		table->elem_count_unsafe--;
	}

	table->hash_bucket_item_num[index]--;
}

static HASH_INLINE htable_elem_t *__MESA_hash_alloc_resource(
      MESA_htable_inner_t *table, const uchar * key, uint size, const void *data, uint hash_val, uint slot_index)
{
	htable_elem_t *ptr = NULL;

	ptr = (htable_elem_t*)HASH_MALLOC(sizeof(htable_elem_t));

	if(table->complex_key_dup != NULL){
		ptr->key = table->complex_key_dup(key, size);
	}else{
		ptr->key = (unsigned char*)HASH_MALLOC(size);
		memcpy(ptr->key, key, size);
	}

	ptr->size = size;
	ptr->data = (void *)data; /* lijia comment, dataָ����ڴ��ǵ���������� */
	ptr->list_node.nextele = NULL;
	ptr->list_node.preele = NULL;
	ptr->list_node.quiddity = (void *)ptr;
	if(table->expire_time != 0){
		ptr->op_time = __MESA_htable_get_time_now(table);
	}
	ptr->hash_value = hash_val;
	ptr->hash_index = slot_index;
	
	return ptr;

//err_2:
//    HASH_FREE(ptr);
//err_1:
//    return NULL;
}


static HASH_INLINE void __MESA_hash_free_resource(MESA_htable_inner_t * table, 
                                htable_elem_t *ptr, void (* func)(void *))
{
	/* ���ͷ�key��Դ, ���ͷ�data��Դ, ��Ϊ�ܿ���key��data�ṹ���ڵ�һ��ָ�� */

	if((table->caller_hargs_len >= HARGS_COMPLEX_KEY_LEN) && (table->complex_key_free != NULL)){
		table->complex_key_free(ptr->key, ptr->size);
	}else{
		HASH_FREE(ptr->key);
	}

	if(NULL != func){
		func(ptr->data);
	}else if(NULL != table->free){
		table->free(ptr->data);
	}
	
	HASH_FREE(ptr);
}

/* NOTE: ֻ��HASH���Ƴ������ṹ��key, data�����ͷ� */
static HASH_INLINE void __MESA_hash_item_pick(MESA_htable_inner_t * table, 
                                htable_elem_t *ptr)
{
	if((table->caller_hargs_len >= HARGS_COMPLEX_KEY_LEN) && (table->complex_key_free != NULL)){
		table->complex_key_free(ptr->key, ptr->size);
	}else{
		HASH_FREE(ptr->key);
	}
	
	HASH_FREE(ptr);
}


static HASH_INLINE void __MESA_hash_del_node(MESA_htable_inner_t * table, 
                htable_elem_t * ptr, uint index, void (* func)(void *))
{
    __MESA_hash_list_delete(table, ptr, index);
	__MESA_hash_time_list_delete(table, ptr, index);
	__MESA_hash_free_resource(table, ptr, func);
}

static inline unsigned int __MESA_htable_get_elem_num(const MESA_htable_inner_t *table)
{
	unsigned int elenum;

	/* NOTE: likely()�÷��̰߳�ȫģʽ�µĲ�������һЩ */
	if(likely(0 == table->thread_safe)){
		elenum = table->elem_count_unsafe;
	}else{
		elenum = (unsigned int )MESA_ATOMIC_READ(table->elem_count_safe);
	}
	return elenum;
}

/*
	��¼ĳ���߳����ڲ���HTABLE��
*/
static inline void __MESA_htable_attach(const MESA_htable_inner_t *table, uint index)
{
	if(NULL == table->htable_option[MHO_AUTO_EXPAND_MULTIPLE]){
		/* δ�����Զ���չ����, ֱ�ӷ��� */
		return;
	}
	
	if(table->thread_safe > 0){
		/* NOTE: ����߳����ͬʱ����һ��index, ��Ϊ�ȵ�����__MESA_hash_mutex_lock(), ͬʱֻ����һ���̲߳���, ���Դ˴������ͻ */
		table->htable_in_use_flag[index % table->mutex_num].long_val++;
	}else{
		/* ���̰߳�ȫģʽ, �������߳�ͬʱ��ȡ, ���ᴥ��auto_expand; ����һ���߳�д, ����auto_expandҲ����ν */
		//table->htable_in_use_flag[0]++;
	}
}

/*
	��¼ĳ���̲߳�����HTABLE, ���˳���
*/
static inline void __MESA_htable_detach(const MESA_htable_inner_t *table, uint index)
{
	if(NULL == table->htable_option[MHO_AUTO_EXPAND_MULTIPLE]){
		/* δ�����Զ���չ����, ֱ�ӷ��� */
		return;
	}
	
	if(table->thread_safe > 0){
		/* NOTE: ����߳����ͬʱ����һ��index, ��Ϊ�ȵ�����__MESA_hash_mutex_lock(), ͬʱֻ����һ���̲߳���, ���Դ˴������ͻ */
		table->htable_in_use_flag[index % table->mutex_num].long_val--;
	}else{
		/* ���̰߳�ȫģʽ, �������߳�ͬʱ��ȡ, ���ᴥ��auto_expand; ����һ���߳�д, ����auto_expandҲ����ν */
		//table->htable_in_use_flag[0]--;
	}
}

/*
    kick out a oldest node from HASH-table if elements number exceed threshold, 
    or the node's operate time expired.
*/
static int __MESA_hash_eliminate(MESA_htable_inner_t *table, uint index)
{
    MESA_list_count_t *list_head, *oldest_node;
    htable_elem_t *hash_elem; 
    int do_eliminate_type = 0;
    int can_be_eliminate = 1;  
    int do_eliminate_flag = 0;

    if(table->thread_safe > 0){
        list_head = &table->hlist_head[index%table->mutex_num];
    }else{
        list_head = &table->hlist_head[0];
    }

    if(MESA_list_count_is_empty(list_head)){
        return 0;
    }

    oldest_node = list_head->nextele;
    if(oldest_node){
        hash_elem = (htable_elem_t *)oldest_node->quiddity;
        if((table->max_elem_num != 0)
           && (__MESA_htable_get_elem_num(table) >= table->max_elem_num)){ /* too many elements */
            do_eliminate_type = ELIMINATE_TYPE_NUM;
        }else if((table->expire_time != 0)
                &&(hash_elem->op_time + table->expire_time < __MESA_htable_get_time_now(table))){ /* time expired */
                do_eliminate_type  = ELIMINATE_TYPE_TIME;
        }
        if(do_eliminate_type != 0){ 
            if(table->expire){
               can_be_eliminate = table->expire(hash_elem->data, do_eliminate_type);
            }else{
               if(ELIMINATE_TYPE_NUM == do_eliminate_type){
		      can_be_eliminate = 0; /* Ϊ�˺���ǰ�汾����, ���ֵĬ�ϲ��Զ���̭, �����޷��������� */
		  }else{
			can_be_eliminate = 1;
		  }
            }

            if(0 == can_be_eliminate){
            		if(ELIMINATE_TYPE_TIME == do_eliminate_type){  /* 2018-10-09, ����ǳ�ʱ�Ҳ�����ز���ɾ��, ��renew */
            			__MESA_hash_time_list_lru(table, hash_elem, index);
            		}
            }else{
	            __MESA_hash_del_node(table ,hash_elem, hash_elem->hash_index, NULL);
	            do_eliminate_flag = 1;
            }
        }
    }

    return do_eliminate_flag;
}



/*
 * name: __default_hash_key2index
 * functionality: computes index from key, default key2index implementation
 * 	if previous hash_create() call did not provide such a function;
 * params:
 * 	table: with which table are you dealing, we want this param be present
 * 	    because we may need size of table to compute the key;
 * 	key: what is the label;
 * 	size: how long is the label;
 * returns:
 * 	index in given table for given key, never fails;
 */
#if 0 
static uint __default_hash_key2index(MESA_htable_inner_t * table, uchar * key, uint size)
{
	uchar * c;
	uint h, g;

	for (c = key, h = 0; c - key < size; c ++) {
		h = (h << 2) + c[0];
		if(0 != (g = (h & 0xf0000000))) {
			h = h ^ (g >> 24);
			h = h ^ g;
		}
	}
	return h % table->size;
}
#else
/* BKDR Hash Function */
uint BKDR_hash_algo(MESA_htable_handle api_table, const uchar *str, uint size)
{
    uint i;
	uint seed = 131; // 31 131 1313 13131 131313 etc..
	uint hash = 0;
	//MESA_htable_inner_t * table = (MESA_htable_inner_t *)api_table;
 
	for(i = 0; i < size; i++){
		hash = hash * seed + (*str++);
	}

 	/* note: 
 	  ��Ϊ������HASH���������ڲ�����, htable slot size���ɼ�, 
 	  ����, ֻ����һ��uint32_t����, ӳ�䵽ʵ�ʵ�slot indexʱ, ����Ҫ����HASH_SLOT_SIZE. 
 	 */
	return hash;
}
#endif


uint APHash_algo(MESA_htable_handle api_table, const uchar *str, uint size)  
{  
    register uint hash = 0;  
    uint i, ch;  
    
    for (i = 0; i < size; i++, str++)  
    {  
    	  ch = *str;
        if ((i & 1) == 0)  
        {  
            hash ^= ((hash << 7) ^ ch ^ (hash >> 3));  
        }  
        else  
        {  
            hash ^= (~((hash << 11) ^ ch ^ (hash >> 5)));  
        }  
    }  
    return hash;  
}  

/* ��֤�Ƿ������� */
static int __is_Prime(unsigned int n)
{
    unsigned int i = 0, sq = 0;
    if(n == 1)
        return 0;
    else if(n == 2)
        return 1;
    else if(!(n % 2))
        return 0;
    sq = (unsigned int)sqrt((double)n);
    for(i=3; i<=sq; i+=2)
    {
        if(n % i == 0)
            return 0;
    }
    return 1;
}

static unsigned int __find_a_random_big_prime_num(void)
{
	unsigned int i, rand_num = (unsigned int)random() | 0xAAA00000; 

	/* �����һ���Ƚϴ������, ��ʼֵrand_num��12λ ������0xAAA, */
	
	for(i = rand_num; i < 0xFFFFFFFFU; i++){
		if(__is_Prime(i) != 0){
			break;
		}
	}

	return i;
}


uint murmur3_32_algo(MESA_htable_handle api_table, const uchar* key, uint len) 
{
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;
  uint32_t h = table->random_prime;
  
  if (len > 3) {
    const uint32_t* key_x4 = (const uint32_t*) key;
    size_t i = len >> 2;
    do {
      uint32_t k = *key_x4++;
      k *= 0xcc9e2d51;
      k = (k << 15) | (k >> 17);
      k *= 0x1b873593;
      h ^= k;
      h = (h << 13) | (h >> 19);
      h = (h * 5) + 0xe6546b64;
    } while (--i);
    key = (const uint8_t*) key_x4;
  }
  if (len & 3) {
    size_t i = len & 3;
    uint32_t k = 0;
    key = &key[i - 1];
    do {
      k <<= 8;
      k |= *key--;
    } while (--i);
    k *= 0xcc9e2d51;
    k = (k << 15) | (k >> 17);
    k *= 0x1b873593;
    h ^= k;
  }
  h ^= len;
  h ^= h >> 16;
  h *= 0x85ebca6b;
  h ^= h >> 13;
  h *= 0xc2b2ae35;
  h ^= h >> 16;
  return h;
}


/*
 * name: __default_hash_key_comp
 * functionality: compares two key;
 * params:
 * 	key1, key2: what are the labels;
 * 	size1, size2: how long are them;
 * returns:
 * 	0, if two keys are identical; (just a simple memcmp() );
 * 	1, no.
 */
static int __default_hash_key_comp(const uchar * key1, uint size1, const uchar * key2, uint size2)
{
	if(size1 != size2) return 1;
	return memcmp(key1, key2, size1);
}


static void __MESA_hash_item_move(MESA_htable_inner_t *table)
{
	htable_elem_t **new_elems_array, *hitem;
	unsigned int i, old_size, new_size, new_slot_index;
	struct timeval begin_time, fin_time;
	int mutex_index;
	MESA_list_count_t *new_hlist_head;
	MESA_list_count_t *old_list_head;
	unsigned char *new_hash_bucket_item_num;
	unsigned short mutex_num;

	unsigned long long cur_item_num = MESA_ATOMIC_READ(table->elem_count_safe);

	old_size = table->size;
	new_size = old_size * 2;
	if(new_size > table->initialize_slot_size * (long)table->htable_option[MHO_AUTO_EXPAND_MULTIPLE]){
		//printf("htable expand size is %ld multiple of initialize_slot_size, can't expand again!\n", (long)table->htable_option[MHO_AUTO_EXPAND_MULTIPLE]);
		return;
	}
	gettimeofday(&begin_time, NULL);

	mutex_num = table->mutex_num;
	if(0 == mutex_num){
		/* ���̰߳�ȫģʽ��, ����ʱ����mutex_num=1, ���̰߳�ȫģʽ���̾���ͬ�� */
		mutex_num = 1;
	}
	
	new_elems_array = (htable_elem_t **)calloc(1, sizeof(htable_elem_t) * new_size);
	new_hlist_head = (MESA_list_count_t *)calloc(1, sizeof(MESA_list_count_t) * mutex_num);
	new_hash_bucket_item_num = (unsigned char *)calloc(1, sizeof(char) * new_size);
	
	for(i = 0; i < mutex_num; i++){
		MESA_list_count_init_head(&new_hlist_head[i]);		
	}
	
	/* �ƶ�Ԫ��ʱ, ��LRU����˳��ת��, ��֤ԭ���Ĳ���˳��, 
		�˴���__MESA_hash_expand_exclusive()������Χ��, �����̲߳������.
		�������.
	*/
	mutex_index = 0;
	do{
		old_list_head = &table->hlist_head[mutex_index];
		
		while(MESA_list_count_is_empty(old_list_head) == 0){
			hitem = (htable_elem_t *)old_list_head->nextele->quiddity;

			/* delete from old htable */
			__MESA_hash_list_delete(table, hitem,  hitem->hash_index);	
			MESA_list_count_del(old_list_head, &hitem->list_node);

			new_slot_index = hitem->hash_value % new_size; 
			hitem->hash_index = new_slot_index;
			
			/* insert to new htable */
			MESA_list_count_add_tail(&new_hlist_head[new_slot_index % mutex_num], &hitem->list_node);
			
			hitem->prev = NULL;
			hitem->next = new_elems_array[new_slot_index];
			if(NULL != new_elems_array[new_slot_index]){ 
			    new_elems_array[new_slot_index]->prev = hitem;
			}    
			new_elems_array[new_slot_index] = hitem;
			
			new_hash_bucket_item_num[new_slot_index]++; 
		}
			
		mutex_index++;
	}while(mutex_index < mutex_num);

	/* update new htable parameter */
	table->size = new_size;
	free(table->elems);
	table->elems = new_elems_array;
	free(table->hash_bucket_item_num);
	table->hash_bucket_item_num = new_hash_bucket_item_num;
	free(table->hlist_head);
	table->hlist_head = new_hlist_head;

	MESA_ATOMIC_SET(table->elem_count_safe, cur_item_num);
	
	gettimeofday(&fin_time, NULL);
	__MESA_hash_log(table, "Finish htable expand, MHO_HASH_SLOT_SIZE from %u to %u, time cost %ld us\n", 
				old_size, new_size, (long)(fin_time.tv_sec * 1000000 + fin_time.tv_usec) - (long)(begin_time.tv_sec * 1000000 + begin_time.tv_usec));
}

static int __MESA_hash_auto_expand(MESA_htable_inner_t *table)
{
	int i;
	int in_use_flag_sum;

	if(NULL == table->htable_option[MHO_AUTO_EXPAND_MULTIPLE]){
		/* δ�����Զ���չ����, ֱ�ӷ��� */
		return -1;
	}

	/* �����ж���߳�ͬʱ���ô˺���, ������̲߳�������(ʹ�ò�ͬ��mutex_index, ������ͻ), 
	   auto_expand_spin_lock��ֵΪ0, ԭ�Ӳ�����ֻ֤�е�һ���̷߳���ֵΪ1, 
	   ֻ���ɵ�һ���߳̽�����չ����, �����̷߳���.
	 */
	if(MESA_ATOMIC_INC(table->auto_expand_spin_lock) != 1){
		return -1;
	}

	/* �Զ���չʱ, ���뱣֤���κ������߳��ڲ���Htable, ���������̻߳���htable��ĳ������ջ�ڲ�,
	   Ҫ���׵ȴ������̶߳��˳����е�htable����ջ, 
	   ��������__MESA_htable_detach()֮��!
	  */
	if(table->thread_safe > 0){
		do{
			in_use_flag_sum = 0;
			for(i = 0; i < table->mutex_num; i++){
				in_use_flag_sum += table->htable_in_use_flag[i].long_val;
			}
		}while(in_use_flag_sum > 1); /* ������һ���ǵ�ǰ�߳�����ռ�� */
	}else{
		;/* ���̰߳�ȫģʽ, �������߳�ͬʱ��ȡ, ���ᴥ��auto_expand; ����һ���߳�д, ����auto_expandҲ����ν */
	}

	__MESA_hash_item_move(table);

	/* ��չ��Ϻ�, �ָ�spin_lock��ֵΪ0, �˴�������MESA_ATOMIC_DEC, ��Ϊ���̲߳���auto_expand_spin_lock��ֵ���ܴܺ�, ȡ���ڲ����߳��� */
	MESA_ATOMIC_SET(table->auto_expand_spin_lock, 0);
	
	return 0;
}

/*
	note:
	2017-11-08�����Զ���չ����,
	���ȼ�����htable�ڲ��Ļ�����, 
	Ҫ��֤����չ���ڼ�, �����̶߳����ܲ���HTABLE!!
*/
static inline void __MESA_hash_expand_exclusive(MESA_htable_inner_t *table)
{
	if(NULL == table->htable_option[MHO_AUTO_EXPAND_MULTIPLE]){
		/* δ�����Զ���չ����, ֱ�ӷ��� */
		return;
	}
	
	while(MESA_ATOMIC_READ(table->auto_expand_spin_lock) > 0){
		sched_yield();
		usleep(1);
	}
}

static void __MESA_hash_log(MESA_htable_inner_t *table, const char * format, ...)
{
    FILE *fp = NULL;
    va_list ap;
    char log_buf[1024];
    
	fp = fopen(table->htable_log_filename, "a+");
	if(NULL == fp){
		return;
	}
    
    va_start(ap, format);
    vsnprintf(log_buf, 1024, format, ap);
    va_end(ap);
	
   fprintf(fp, (char *)"%s", log_buf);

	fclose(fp);
}


/* �����Ƿ�2��N�η� */
static HASH_INLINE int number_is_2N(uint n)
{
#if 0
	uint s;
	for(s = n; s != 0; ) {
		if(0x01 != s && 0x01 == (0x01 & s)) return 0;
		s = s >> 1;
	}
#else
    if(n & (n-1)){
        return 0;
    }    
#endif

	return 1;
}



/*
 * get total number of HASH element.
*/
unsigned int MESA_htable_get_elem_num(const MESA_htable_handle api_table)
{	
	return __MESA_htable_get_elem_num((const MESA_htable_inner_t *)api_table);
}



/*
 * name: hash_create
 *  functionality: allocats memory for hash slots, and fill in hash structure;
 *
 *   args:
 *	thread_safe: 0:create hashtable without thread safe features; 
 *                positive:the bigger number has more performance, but less timeout accuracy.
 *                         max number is 1024.
 *   recursive: 0:can't recursive call MESA_htable_xxx series function
 *			  1:can recursive call MESA_htable_xxx series function, low performance when enable.
 * 	hash_slot_size: how big do you want the table to be, must be 2^N;
 *  max_elem_num: the maximum elements of the HASH-table,0 means infinite;
 * 	key_comp: hash key compare function, use default function if NULL;
 *			suggest: implement by yourself.
 *  key2index: hash key->index computing function, use default function if NULL;
 *			suggest: use MESA_htable built-in function.
 *  data_free: release resources function, only free attached data pointer if NULL;
 *  data_expire_with_condition: if expire_time > 0, call this function when a element expire, eliminate always if NULL;
 *				args:
 *					data: pointer to attached data;
 *					type: eliminate reason, ELIMINATE_TYPE_NUM or ELIMINATE_TYPE_TIME;
 *				return value of 'data_expire_with_condition':
 *					1: can be eliminated;
 *					0: can't be eliminated, renew the item.
 *  eliminate_type: the algorithm of elimanate a expired element, 0:FIFO; 1:LRU.
 *  expire_time: the element expire time in second, 0 means infinite.
 */
MESA_htable_handle MESA_htable_create(const MESA_htable_create_args_t *args, int args_struct_len)
{
	MESA_htable_inner_t *table = NULL;
	unsigned int i = 0, j = 0;
	int ret = 0;
	pthread_mutexattr_t attr; 
	int attr_type;

	if(args_struct_len > (int)sizeof(MESA_htable_create_args_t)){
		printf("\033[41mError! Caller MESA_htable header version is newer, please update libMESA_htable.x!\033[0m\n");
		return NULL;
	 }

	if(args_struct_len != (int)sizeof(MESA_htable_create_args_t)){
		printf("\033[41mWarning!!\033[0m\n");
		printf("\033[41mMESA_htable  header version is different with library! Program action is unpredictable!\033[0m\n");
		//return NULL;
	}

	if(number_is_2N(args->hash_slot_size) == 0){
		printf("\033[41mHtable error! hash_slot_size must be power 2!\033[0m\n");
		return NULL;
	}

	table = (MESA_htable_inner_t *)HASH_MALLOC(sizeof(MESA_htable_inner_t));
	memset(table, 0, sizeof(MESA_htable_inner_t));
	
	table->elems = (htable_elem_t**)HASH_MALLOC(sizeof(htable_elem_t *) * args->hash_slot_size);
	memset(table->elems, 0, sizeof(htable_elem_t *) * args->hash_slot_size);

	table->caller_hargs_len = args_struct_len;
	table->size = args->hash_slot_size;

	table->hash_bucket_item_num = (unsigned char *)HASH_MALLOC(sizeof(char) * args->hash_slot_size);
	memset(table->hash_bucket_item_num, 0, sizeof(char) * args->hash_slot_size);
	
	if(NULL == args->key_comp){
		table->key_comp = __default_hash_key_comp;
	}else{
		table->key_comp = args->key_comp;
	}
	if(NULL == args->key2index){
		table->key2index = BKDR_hash_algo;
	}else{
		table->key2index = args->key2index;
	}	

	table->expire = args->data_expire_with_condition;
	//if(NULL == data_free) return -1; /* 2013-05-06 modify, can be NULL */
	table->free = args->data_free;

	if(args->thread_safe > 0){
		MESA_ATOMIC_SET(table->elem_count_safe, 0);
	}else{
		table->elem_count_unsafe = 0;
	}
	table->thread_safe = args->thread_safe;
	table->mutex_num = args->thread_safe; /* ������ǰģʽ, thread_safe��˫�غ���, 0��ʾ���̰߳�ȫ; >0��ʾ�̰߳�ȫ��ͬʱ������������ */
	table->max_elem_num = args->max_elem_num;
	table->eliminate_type = args->eliminate_type;
	table->expire_time = args->expire_time;
	table->recursive = args->recursive;
	table->print_switch = 1; /* default print switch is open */

	/* NOTE: �Ϸ��Լ��;  ������Ϸ��ռ�� */
	if((HASH_ELIMINATE_ALGO_LRU == table->eliminate_type) &&(0 == table->thread_safe)){
		if((0 == table->max_elem_num) && (0 == table->expire_time)){
			printf("\033[33mWarning!MESA_htable_create(): thread_safe is 0, max_elem_num is 0 and expire_time is 0, but eliminate_type is LRU! Reset eliminate_type to FIFO!\033[0m\n");
		}else{
			printf("\033[33mWarning!MESA_htable_create(): thread_safe is 0, but eliminate_type is LRU!\nThe action is inscrutable if running in multi-thread mode, be careful!\033[0m\n");
		}	
	}
	
	if(args_struct_len >= HARGS_COMPLEX_KEY_LEN){
		table->complex_key_dup = args->complex_key_dup;
		table->complex_key_free = args->complex_key_free;

		if((table->complex_key_dup != NULL)
		    && (NULL == table->complex_key_free)){
			fprintf(stderr, "Error! Set 'complex_key_dup' but no 'complex_key_free', maybe memory leak!\n ");
			goto err_1;
		}

		if((table->complex_key_dup != NULL)
		    && (NULL == table->key_comp)){
			fprintf(stderr, "Error! Set 'complex_key_dup' but no 'key_comp',  compare result maybe incorrect!\n ");
			goto err_1;
		}
		
		if((table->complex_key_dup != NULL)
		    && (NULL == table->key2index)){
			fprintf(stderr, "Error! Set 'complex_key_dup' but no 'key2index',  HASH index maybe incorrect!\n ");
			goto err_1;
		}

	}else{
		table->complex_key_dup = NULL;
		table->complex_key_free = NULL;
	}

    if(table->thread_safe > 0){
        if(table->thread_safe > HASH_TABLE_MUTEX_NUM){
        	printf("\033[33mWarning!thread_safe max value is :%d, set to %d.\033[0m\n", 
        	        HASH_TABLE_MUTEX_NUM, HASH_TABLE_MUTEX_NUM);
		table->thread_safe = HASH_TABLE_MUTEX_NUM;
        }
        
        table->htable_mutex = (pthread_mutex_t *)HASH_MALLOC(sizeof(pthread_mutex_t) * table->mutex_num);
        if(NULL == table->htable_mutex){
            ret = -1;
            goto err_1;
        }
        for(i = 0; i < table->mutex_num; i++){
        	if(table->recursive != 0){
	        	pthread_mutexattr_init(&attr);
	        	pthread_mutexattr_gettype(&attr, &attr_type);
	        	attr_type |= PTHREAD_MUTEX_RECURSIVE_NP; /* can be recursive call */
	        	pthread_mutexattr_settype(&attr, attr_type);
	        	ret = pthread_mutex_init(&table->htable_mutex[i], &attr);
        	}else{
			ret = pthread_mutex_init(&table->htable_mutex[i], NULL);
        	}
            if(ret !=0){
                ret = -1;
                goto err_2;
            }   
#if 0
            table->acquire_lock1[i] = THREAD_PID_INIT1;
            table->acquire_lock2[i] = THREAD_PID_INIT2;
#endif            
        }   
        table->hlist_head = (MESA_list_count_t *)HASH_MALLOC(sizeof(MESA_list_count_t) * table->mutex_num);
        if(NULL == table->hlist_head){
            ret = -1;
            goto err_2;
        }        
        for(i=0;i<table->mutex_num;i++){
            MESA_list_count_init_head(&(table->hlist_head[i]));
        }
    }else{
        table->hlist_head = (MESA_list_count_t *)HASH_MALLOC(sizeof(MESA_list_count_t));
        if(NULL == table->hlist_head){
            ret = -1;
            goto err_2;
        }
        MESA_list_count_init_head(&table->hlist_head[0]);
    }

	table->create_type = HTABLE_CREATE_TYPE_ORIGINAL; /* 2016-02-24 lijia add */

	table->hash_list_collide_threshold = 100;

	char tmp_str[128];
	struct timeval cur_time;
	
	gettimeofday(&cur_time, NULL);
	snprintf(tmp_str, 128, MHT_DEFAULT_LOG_FILE_PATTERN, (int)getpid(), (unsigned int)cur_time.tv_sec, (unsigned int)cur_time.tv_usec);
	table->htable_log_filename = (const char *)strdup(tmp_str);

	table->random_prime = __find_a_random_big_prime_num();

	return (MESA_htable_handle)table;

err_2:
    for(j = 0; (table->mutex_num> 0) &&(j < i); j++){
        pthread_mutex_destroy(&table->htable_mutex[j]);
    }
    HASH_FREE(table->htable_mutex);
err_1:
    HASH_FREE(table->elems);
    return NULL;
}



/*
 * adds data identified by key to table.
 * table->elems always points to the newest added element.
 * no two elements should have a same key, although them may have a same index.
 * returns:
 *	>0 success,return hash elems' linklist size
 * 	-1, duplicates found and can't add this one;
 * 	-2, memory failure;
 *   -3, item num full.
 *   -4, other errors.
 */
int MESA_htable_add(MESA_htable_handle api_table, const uchar * key, uint size, const void * data)
{
	uint hash_val, index;
	htable_elem_t * ptr;
	int ret = MESA_HTABLE_RET_OK, del_elem = 0;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if(unlikely((NULL == api_table) || (NULL == key))){
		return MESA_HTABLE_RET_ARG_ERR;
	}

	if(unlikely(size <= 0)){
		return MESA_HTABLE_RET_LEN_ERR;
	}

	__MESA_hash_expand_exclusive(table);

	hash_val = table->key2index(table, key, size);
	index = hash_val % table->size;

	ret = __MESA_hash_mutex_lock(table, index);
	if(unlikely(ret != 0)){
		return MESA_HTABLE_RET_CANT_GET_LOCK;
	}

	__MESA_htable_attach(table, index);

	del_elem = __MESA_hash_eliminate(table,index);/* 2013-09-12 LiJia modify, ����̭�ٲ���,����Ὣ�鵽�Ľ����̭���ַ��ظ��˵����� */

	if((table->max_elem_num > 0) && (__MESA_htable_get_elem_num(table) >= table->max_elem_num)){
		if(0 == del_elem){ /* ���������ֵ���޷���̭����Ԫ�� */
			ret = MESA_HTABLE_RET_NUM_FULL;
			goto err;
		}
	}
	    
	if(__MESA_hash_key_search(table,key,size,index)){ /* already exist */
		ret = MESA_HTABLE_RET_DUP_ITEM;
		goto err;
	}
	ptr = __MESA_hash_alloc_resource(table, key, size, data, hash_val, index);
	ret = (int )__MESA_hash_list_insert(table, ptr, index);
	__MESA_hash_time_list_insert(table, ptr, index);


#if MESA_HASH_LIST_COLLIDE_DETECT
	if((ret > table->hash_list_collide_threshold) && (table->hash_list_collide_threshold > 0)){
		__MH_backtrace_print(table, ret);	
	}
#endif

	if(ret > table->hash_list_collide_threshold){
		__MESA_hash_auto_expand(table);
	}
	
	__MESA_htable_detach(table, index);

	__MESA_hash_mutex_unlock(table, index);

	return ret;

err:	
	__MESA_htable_detach(table, index);
	__MESA_hash_mutex_unlock(table,index);
	return ret;

}



/*
 * name: hash_del
 * functionality: deletes item from table.
 * param:
 * 	table: from which table do you want to delete;
 * 	key  : what is the label;
 * 	size : how long is the label;
 * 	func : callback function to clean up data attached to hash items,
 	       if this pointer is NULL will call "data_free" in MESA_hash_create(),
 * returns:
 * 	0, success;
 * 	-1, no such thing;
 */
int MESA_htable_del(MESA_htable_handle api_table, const uchar * key, uint size,
                         void (* func)(void *))
{
	uint index;
	htable_elem_t * ptr;
	int ret = MESA_HTABLE_RET_OK;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if(unlikely((NULL == api_table) || (NULL == key))){
		return MESA_HTABLE_RET_ARG_ERR;
	}

	if(unlikely(size <= 0)){
		return MESA_HTABLE_RET_LEN_ERR;
	}

	__MESA_hash_expand_exclusive(table);
	
	index = table->key2index(table, key, size) % table->size;

	ret = __MESA_hash_mutex_lock(table,index);
	if(unlikely(ret != 0)){
		return MESA_HTABLE_RET_CANT_GET_LOCK;
	}

	__MESA_htable_attach(table, index);
	ptr = __MESA_hash_key_search(table,key,size,index);
	if(NULL == ptr){
		ret = MESA_HTABLE_RET_NOT_FOUND;
		goto err;	/* success, maybe? why? */
	}

	__MESA_hash_del_node(table ,ptr, index, func);

	__MESA_htable_detach(table, index);

	__MESA_hash_mutex_unlock(table,index);
	return ret;

err:
	__MESA_htable_detach(table, index);
	__MESA_hash_mutex_unlock(table,index);
	return ret;
}


/*
 * name: MESA_htable_del_oldest_manual
 * functionality: deletes oldest item from table.
 * param:
 * 	table: from which table do you want to delete;
 * 	func : callback function to clean up data attached to hash items,
 	       if this pointer is NULL will call "data_free" in MESA_hash_create(),
 *   batch_num: delete oldest items.      
 * returns:
 * 	0, do nothing ;
 * 	>0, delete items;
 */
int MESA_htable_del_oldest_manual(MESA_htable_handle api_table, void (* func)(void *), int batch_num)
{
	MESA_list_count_t *list_head, *oldest_node;
	htable_elem_t *del_item;
	int ret = 0;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;
	unsigned int i, del_num = 0;
	unsigned int cur_ele_num  = __MESA_htable_get_elem_num(table);
	unsigned int del_batch_num = (unsigned int )batch_num <= cur_ele_num? (unsigned int )batch_num: cur_ele_num;

	__MESA_hash_expand_exclusive(table);

	/* TODO, 
	   ��������ѭ���������ɲ�ͬ��mutex����, 
	   �����ѭ���м�, �����̲߳���������, ������auto expand����, ���޷���ʱ�˳�, �����������HTABLE, 
	   �˴���ʱʹ��index0ռ��htable������־λ 
	*/
	__MESA_htable_attach(table, 0); 
	
	while(del_num < del_batch_num){
		for(i = 0; i <= table->mutex_num; i++){
			/* ѭ������ʹ��"i<=", ��Ϊtable->thread_safe����Ϊ0, 
			   �����table->thread_safe>0, i����ʵ��==table->thread_safe, ����ѭ����������һ���ж�. */
			if((i > 0) && (i >= table->mutex_num)){
				break;
			}
			ret = __MESA_hash_mutex_lock(table,i);
			if(unlikely(ret != 0)){
				continue;
			}
			cur_ele_num = __MESA_htable_get_elem_num(table);
			del_batch_num = batch_num <= cur_ele_num? batch_num: cur_ele_num;

		    if(table->thread_safe > 0){
		        list_head = &table->hlist_head[i];
		    }else{
		        list_head = &table->hlist_head[0];
		    }

		    if(MESA_list_count_is_empty(list_head)){
		    	__MESA_hash_mutex_unlock(table,i);
			continue;
		    }

		    oldest_node = list_head->nextele;
		    del_item = (htable_elem_t *)oldest_node->quiddity;

			 if(table->expire){
	                table->expire(del_item->data, ELIMINATE_TYPE_MANUAL);
	            }
	            
			/* �˴�ʹ��hash_item�洢��hash_index */
			__MESA_hash_list_delete(table, del_item, del_item->hash_index);
			__MESA_hash_time_list_delete(table, del_item, i);
			__MESA_hash_free_resource(table, del_item, func);
		
			__MESA_hash_mutex_unlock(table,i);

			del_num++;
		}

	}

	__MESA_htable_detach(table, 0);
	
	return del_num;
}


/*
 * name: hash_sel
 * functionality: selects item from table;
 * param:
 * 	table: from which table do you want to select;
 * 	key: what is the label;
 * 	size: how long is the label;
 *
 * return:
 *  not NULL :pointer to attached data;
 *  NULL 	 :not found(thus be careful if you are attaching NULL data on purpose).
 */
void *MESA_htable_search(const MESA_htable_handle api_table, const uchar * key, uint size)
{
	uint index;
	htable_elem_t * ptr;
	void *ret;
	int res;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if(unlikely((NULL == api_table) || (NULL == key))){
		MHT_PRINT(table, "MESA_htable_search() error, Invalid args!\n");
		return NULL;
	}

	if(unlikely(size <= 0)){
		MHT_PRINT(table, "MESA_htable_search() error, Invalid key size!\n");
		return NULL;
	}
	
	if(unlikely(table->thread_safe != 0)){
		MHT_PRINT(table, "Warning! Use 'MESA_htable_search' in thread safe mode!\n\tIf you know this risk and determine to running\n\tYou should call 'MESA_htable_print_crtl' or 'MESA_htable_set_opt' to close the screen print. \n\tBut, be careful, good luck!!!\n ");
	}

	__MESA_hash_expand_exclusive(table);
	
	index = table->key2index(table, key, size) % table->size;
	 res = __MESA_hash_mutex_lock(table,index);
	if(unlikely(res != 0)){
		return NULL;
	}

	__MESA_htable_attach(table, index);

	__MESA_hash_eliminate(table,index); /* 2013-09-12 LiJia modify, ����̭�ٲ���,����Ὣ�鵽�Ľ����̭���ַ��ظ��˵����� */
	ptr = __MESA_hash_key_search_with_status_feedback(table,key,size,index);
	if(NULL != ptr){
		ret = ptr->data;
		if(HASH_ELIMINATE_ALGO_LRU==table->eliminate_type){
			__MESA_hash_time_list_lru(table, ptr, index);
			/* ע��, �˴�������LRUģʽ�Ż����, ������ܻ���̳߳�ͻ */
			__MESA_hash_bucket_lru(table, ptr, index);
		}
	}else{
		ret = NULL;
	}

	__MESA_htable_detach(table, index);
	__MESA_hash_mutex_unlock(table,index);

	return ret;
}

/*
 * name: hash_sel
 * functionality: selects item from table, reentrant;
 * in param:
 * 	table: from which table do you want to select;
 * 	key  : what is the label;
 * 	size : how long is the label;
 *  cb   : call this function when found the attached data;
 *  arg  : the argument of "cb" function.
 * out param:
 *  cb_ret: the return value of the function "cb".
 * return:
 *  not NULL :pointer to attached data;
 *  NULL 	 :not found(thus be careful if you are attaching NULL data on purpose).
 */
void *MESA_htable_search_cb(const MESA_htable_handle api_table, const uchar * key, uint size,
								          hash_cb_fun_t *cb, void *arg, long *cb_ret)
{
	uint index;
	htable_elem_t * ptr;
	void *ret;
	int res;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if(unlikely((NULL == api_table) || (NULL == key) || (size <= 0))){
		MHT_PRINT(table, "MESA_htable_search_cb() error, Invalid args!\n");
		return NULL;
	}
	
	if((NULL == cb) && (table->thread_safe != 0)){
		MHT_PRINT(table, "MESA_htable_search_cb() warning, thread_safe is %d and 'cb' is NULL!\n", table->thread_safe);
		/* �˴���ʱ��ǿ�Ʒ��ش���, ֻ��ӡ������Ϣ */
	}

	__MESA_hash_expand_exclusive(table);
	
	index = table->key2index(api_table, key, size) % table->size;

	res = __MESA_hash_mutex_lock(table,index);
	if(unlikely(res != 0)){
		return NULL;
	}

	__MESA_htable_attach(table, index);

	__MESA_hash_eliminate(table,index);/* 2013-09-12 LiJia modify, ����̭�ٲ���,����Ὣ�鵽�Ľ����̭���ַ��ظ��˵����� */

	ptr = __MESA_hash_key_search_with_status_feedback(table,key,size,index);
	if(NULL != ptr){
		ret = ptr->data;
		if(HASH_ELIMINATE_ALGO_LRU == table->eliminate_type){
			__MESA_hash_time_list_lru(table, ptr, index);
			__MESA_hash_bucket_lru(table, ptr, index);
		}
		if(cb){
			*cb_ret = cb(ptr->data, key, size, arg);
		}    
	}else{
		ret = NULL;
		if(cb){
			*cb_ret = cb(NULL, key, size, arg);
		}    
	}

	__MESA_htable_detach(table, index);
	__MESA_hash_mutex_unlock(table,index);

	return ret;
}

#if 0
int MESA_hash_iterate_v3_r(MESA_htable_handle api_table, void (* func)(uchar * key, uint size, void * data))
{
	int i, get_lock;
	htable_elem_t * ptr;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if(NULL == func){
		return -1;
	}

	for(i = 0; i < (int)table->size; i++){
		get_lock = __MESA_hash_mutex_lock(table, i);

		for(ptr = table->elems[i]; NULL != ptr; ptr = ptr->next){
			func(ptr->key, ptr->size, ptr->data);
		}

		if(get_lock){
			__MESA_hash_mutex_unlock(table, i);
		}
	}

	return 0;
}
#endif

int MESA_htable_iterate(MESA_htable_handle api_table, 
                            void (* func)(const uchar * key, uint size, void * data,  void * u),  void * user)
{
	int i, ret;
	htable_elem_t *ptr, *next;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if(NULL == func){
		return MESA_HTABLE_RET_ARG_ERR;
	}

	__MESA_hash_expand_exclusive(table);

	__MESA_htable_attach(table, 0); 
	
	for(i = 0; i < (int)table->size; i ++){ /* iterate slot  */
		ret = __MESA_hash_mutex_lock(table, i);
		if(unlikely(ret != 0)){
			continue;
		}
		/* NOTE: ֧�ֵݹ�ɾ��, ��next����ptr->next, ptr�����Ѿ���func�ͷ�, ptr->nextΪҰָ�� */		
		for(ptr = table->elems[i]; NULL != ptr; ptr = next){
			next = ptr->next;
			func(ptr->key, ptr->size, ptr->data, user);
		}

		__MESA_hash_mutex_unlock(table, i);
	}

	__MESA_htable_detach(table, 0); 

	return 0;
}

static inline int __check_ret_val(int cb_fun_ret)
{
	if((cb_fun_ret & ITERATE_CB_RET_CONTINUE_FLAG)
	 && (cb_fun_ret & ITERATE_CB_RET_BREAK_FLAG)){
		return -1;
	}
	
	if((cb_fun_ret & ITERATE_CB_RET_DEL_FLAG)
	 && (cb_fun_ret & ITERATE_CB_RET_REVERSE_FLAG)){
		return -1;
	}

	if((cb_fun_ret & ITERATE_CB_RET_DEL_FLAG)
	 && (cb_fun_ret & ITERATE_CB_RET_REMOVE_BUT_NOT_FREE)){
		return -1;
	}

	if((cb_fun_ret & ITERATE_CB_RET_REVERSE_FLAG)
	 && (cb_fun_ret & ITERATE_CB_RET_REMOVE_BUT_NOT_FREE)){
		return -1;
	}
	
	return 0;
}

/*
	iterate_type:
		1: newest item first; 2: oldest item first;
*/
int MESA_htable_iterate_bytime(MESA_htable_handle api_table,   int iterate_type,
                            int (* func)(const uchar * key, uint size, void * data,  void *u),  void * user)
{
	int ret;
	unsigned int i;
	htable_elem_t *hitem;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;
	MESA_list_count_t *list_node= NULL, *list_head, *demand_next, *anchor = NULL;

	if((NULL == api_table) || (NULL == func)){
		return MESA_HTABLE_RET_ARG_ERR;
	}
	
	if(table->thread_safe > 1){
		MHT_PRINT(table, "thread_safe is:%d, in MESA_htable_iterate_bytime(), the result is not exact!\n", table->thread_safe);
	}
	
	if(table->mutex_num > 1){
		MHT_PRINT(table, "mutex_num is:%d, in MESA_htable_iterate_bytime(), the result is not exact!\n", table->mutex_num);
	}

	__MESA_hash_expand_exclusive(table);

	__MESA_htable_attach(table, 0); 
	
	for(i = 0; (i == 0) || ((i > 0) && (i < table->thread_safe)); i++){
		__MESA_hash_mutex_lock(table, i);
		list_head = &table->hlist_head[i];
		if(1 == iterate_type){
			list_node = list_head->preele;	
		}else{
			list_node = list_head->nextele;	
		}
		while((MESA_list_count_is_empty(list_head) == 0) &&(list_node != list_head) && (list_node != anchor)){
			hitem = (htable_elem_t *)list_node->quiddity;
			if(1 == iterate_type){
				demand_next = list_node->preele;	
			}else{
				demand_next = list_node->nextele;	
			}
			ret = func(hitem->key, hitem->size, hitem->data, user);
			if(__check_ret_val(ret) < 0){
				MHT_PRINT(table, "cb_fun return value illegal!\n");		
			}

			if(ret & ITERATE_CB_RET_REVERSE_FLAG){
				if(1 == iterate_type){
					MESA_list_count_del(list_head, list_node);
					MESA_list_count_add(list_head, list_node);
				}else if (2 == iterate_type){
					MESA_list_count_del(list_head, list_node);
					MESA_list_count_add_tail(list_head, list_node);
				}else{
					MHT_PRINT(table, "iterate_type value illegal!\n");		
					goto fun_exit;
				}
				if(NULL == anchor){
					anchor = list_node; /* ��ֹ�ص�����һֱ����reverse, �����ѭ��, �˴��Ӹ�ê, �ٴ�ѭ����������� */
				}
			}else if(ret & ITERATE_CB_RET_DEL_FLAG){
				__MESA_hash_del_node(table ,hitem, hitem->hash_index, table->free);
			}else if(ret & ITERATE_CB_RET_REMOVE_BUT_NOT_FREE){
			    __MESA_hash_list_delete(table,hitem, hitem->hash_index);
				__MESA_hash_time_list_delete(table, hitem, hitem->hash_index);	
				__MESA_hash_item_pick(table, hitem);
			}
			
			if(ret & ITERATE_CB_RET_BREAK_FLAG){
				goto fun_exit;
			}
			list_node = demand_next;
		}
		__MESA_hash_mutex_unlock(table, i);
	}

	__MESA_htable_detach(table, 0); 
	
	return 0;

fun_exit:
	__MESA_htable_detach(table, 0); 
	__MESA_hash_mutex_unlock(table, i);
	return -1;
}	
#if 0
int MESA_hash_expire(MESA_htable_inner_t * table)
{
	int i, delta;
	htable_elem_t * ptr, * tmp;

	if(NULL == table->expire) return 0;
	for(i = 0; i < (int)table->size; i ++) {
		ptr = table->elems[i];
		while(NULL != ptr) {
			if(table->expire(ptr->data)) {
				if(NULL != ptr->prev)
				{
					ptr->prev->next = ptr->next;
				}
				else 
				{
					table->elems[i] = ptr->next;
				}
				if(NULL != ptr->next)
					ptr->next->prev = ptr->prev;
				tmp = ptr;
				ptr = ptr->next;
				if(NULL != table->free)
					table->free(tmp->data);
				free(tmp);

				table->elem_count --;

				continue;
			}
			ptr = ptr->next;
		}
	}
	return 0;
}
#endif



/*
	to set feature of specified MESA_htable handle.
		opt_type: option type, refer to enum MESA_htable_opt;
		opt_val : option value, depend on opt type;
		opt_len : opt_val size;
	
	return value:
		0 :OK;
		<0:error;
*/
int MESA_htable_set_opt(MESA_htable_handle api_table, enum MESA_htable_opt opt_type, void *opt_val, int opt_len)
{	
	int ret;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if((NULL == api_table) || (NULL == opt_val)){
		return -1;
	}

	if(HTABLE_CREATE_TYPE_ORIGINAL == table->create_type){
		MHT_PRINT(table, "MESA_htable_handle is create by MESA_htable_create(), not support MESA_htable_set_opt, \n");
		MHT_PRINT(table, "please use MESA_htable_born() API to create MESA_htable_handle!\n");
		return -1;
	}

	if(table->is_running){
		MHT_PRINT(table, "Can't call MESA_htable_set_opt() again after MESA_htable_mature!\n");
		return -1;
	}

	if(((int)opt_type < 0) || ((int)opt_type >= __MHO_MAX_VAL)){
		MHT_PRINT(table, "opt_type invalid!\n");
		return -1;
	}

	ret = MESA_OPT_MANAGE[opt_type].MESA_htable_set_opt_fun(api_table, opt_type, opt_val, opt_len);

	return ret;
}


int MESA_htable_get_opt(MESA_htable_handle api_table, enum MESA_htable_opt opt_type, void *opt_val, int *opt_len)
{
	int ret = 0;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if((NULL == api_table) || (NULL == opt_val)){
		return -1;
	}

	if(((int)opt_type < 0) || ((int)opt_type >= __MHO_MAX_VAL)){
		MHT_PRINT(table, "opt_type invalid!\n");
		return -1;
	}

	if(NULL == MESA_OPT_MANAGE[opt_type].MESA_htable_get_opt_fun){
		MHT_PRINT(table, "opt_type invalid or not support!\n");
		return -1;
	}

	ret = MESA_OPT_MANAGE[opt_type].MESA_htable_get_opt_fun(api_table, opt_type, opt_val, opt_len);
	
	return ret;
}

/*
	Ϊ�˼���֮ǰ�Ĵ���, ����ʹ��MESA_htable_inner_t�ṹ, 
	����һЩ���û�������, ��������߲�ʹ��MESA_htable_set_opt()���ø��Ի�����,
	Ҳ�ܱ�֤��򵥵�HASH�����ܿ���.
*/
static void __MESA_htable_set_default_opt(MESA_htable_inner_t *table)
{
	char tmp_str[128];
	struct timeval cur_time;
	
	table->size = 64 * 1024;
	table->initialize_slot_size = 64 * 1024;
	table->thread_safe = 1; /* Ĭ�����̰߳�ȫ��, ���ٱ�֤��ʲô����¶�������������. */
	table->mutex_num = 1; /* Ϊ�����������������ȷ����, Ĭ�ϼ���ģʽ */
	table->recursive = 1;
	table->elem_count_unsafe = 0;
	table->key_comp = __default_hash_key_comp;
	table->key2index = BKDR_hash_algo;
	table->expire = NULL;
	table->free = NULL; /* �˴������ɵ���������ʵ�� */
	table->max_elem_num = 0;
	table->eliminate_type = HASH_ELIMINATE_ALGO_FIFO;
	table->expire_time = 0;
	table->print_switch = 1; /* Ĭ�Ͽ�����Ļ��ӡ */
	table->complex_key_dup = NULL;
	table->complex_key_free = NULL;
	table->caller_hargs_len = sizeof(MESA_htable_create_args_t); /* ����MESA_htable_born()�����ľ��, args_lenǡ�õ��ڵ�ǰ��MESA_htable_create_args_t */
	memset(table->htable_option, 0, sizeof(table->htable_option)); 
	table->hash_list_collide_threshold = 100;

	gettimeofday(&cur_time, NULL);
	snprintf(tmp_str, 128, MHT_DEFAULT_LOG_FILE_PATTERN, (int)getpid(), (unsigned int)cur_time.tv_sec, (unsigned int)cur_time.tv_usec);
	table->htable_log_filename = (const char *)strdup(tmp_str);

	table->htable_option[MHO_AUTO_EXPAND_MULTIPLE] = (void *)0; /* �Զ���չ����Ĭ�Ϲر� */

	table->random_prime = __find_a_random_big_prime_num();
}


/*
	Create a htable handel and Alloc memory, it's struct is forbidden for caller.
	return value:
		not NULL: success.
		NULL    : error.
*/
MESA_htable_handle MESA_htable_born(void)
{
	MESA_htable_inner_t *handle;
	handle = (MESA_htable_inner_t *)HASH_MALLOC(sizeof(MESA_htable_inner_t));
	memset(handle, 0, sizeof(MESA_htable_inner_t));

	__MESA_htable_set_default_opt(handle);

	return (void *)handle;
}

/*
	Construct htable and ready to running.

	return value:
		0 : success;
		<0: error.
*/
int MESA_htable_mature(MESA_htable_handle apitable)
{
	int i, ret;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)apitable;

	if(NULL == apitable){
		return MESA_HTABLE_RET_ARG_ERR;
	}

	if(table->create_type != 0){
		printf("Error! This handle is already enabled!\n");
		return MESA_HTABLE_RET_COMMON_ERR;
	}

	for(i = 0; i < __MHO_MAX_VAL; i++){
		if(MESA_OPT_MANAGE[i].MESA_htable_process_opt_fun != NULL){
			ret = MESA_OPT_MANAGE[i].MESA_htable_process_opt_fun(apitable);
			if(ret < 0){
				goto err;
			}
		}
	}

	/* NOTE: �Ϸ��Լ��;  ������Ϸ��ռ�� */
	if((HASH_ELIMINATE_ALGO_LRU == table->eliminate_type) &&(0 == table->thread_safe)){
		if((0 == table->max_elem_num) && (0 == table->expire_time)){
			MHT_PRINT(table,"\033[33mWarning!MESA_htable_mature(): thread_safe is 0, max_elem_num is 0 and expire_time is 0, but eliminate_type is LRU! Reset eliminate_type to FIFO!\033[0m\n");
			table->eliminate_type = HASH_ELIMINATE_ALGO_FIFO;
		}else{
			MHT_PRINT(table, "\033[33mWarning!MESA_htable_mature(): thread_safe is 0, but eliminate_type is LRU!\nThe action is inscrutable if running in multi-thread mode, be careful!\033[0m\n");
		}	
	}

	table->hash_bucket_item_num = (unsigned char *)HASH_MALLOC(sizeof(char) * table->size);
	memset(table->hash_bucket_item_num, 0, sizeof(char) * table->size);
	
	table->create_type = HTABLE_CREATE_TYPE_BORN;
	table->is_running = 1;

	return MESA_HTABLE_RET_OK;

err:
	MESA_htable_destroy(table, NULL);
	return MESA_HTABLE_RET_COMMON_ERR;
}


/*
 * frees table->elems and chains attached to each element of it.
 * always returns 0.
 */
int MESA_htable_destroy(MESA_htable_handle api_table, void (* func)(void *))
{
	unsigned int i;
	htable_elem_t *cur, *next;
	MESA_htable_inner_t *table = (MESA_htable_inner_t *)api_table;

	if(NULL == api_table){
		return MESA_HTABLE_RET_ARG_ERR;
	}
	
	for(i = 0; i < table->size; i ++) {
		cur = table->elems[i];
		while(NULL != cur) {
			next = cur->next;
			/* 2015-05-13 lijia add, for complex key memory leak */
#if 0			
			if(NULL != func) func(cur->data);
			else if(NULL != table->free) table->free(cur->data);
			table->elems[i] = (table->elems[i])->next;
			
			if((table->caller_hargs_len >= HARGS_COMPLEX_KEY_LEN) && (table->complex_key_free != NULL)){
				(*table->complex_key_free)(cur->key, cur->size);
			}else
				HASH_FREE(cur->key);
			}	
			HASH_FREE(cur);
#else
			__MESA_hash_free_resource(table, cur, func);
#endif
			cur = next;
		}
	}

	if( HTABLE_CREATE_TYPE_ORIGINAL == table->create_type){
		if(table->thread_safe > 0){
			for(i=0;i<table->mutex_num;i++){
				pthread_mutex_destroy(&table->htable_mutex[i]);
			}    
			HASH_FREE(table->htable_mutex);    
		}
		free((void *)table->htable_log_filename);
	    HASH_FREE(table->hlist_head);
		HASH_FREE(table->elems);
		table->elems = NULL;
		table->size = 0;
	}else{
		for(i = 0; i < __MHO_MAX_VAL; i++){
			if(MESA_OPT_MANAGE[i].MESA_htable_free_opt_fun){
				MESA_OPT_MANAGE[i].MESA_htable_free_opt_fun(table);
			}
		}
	}
		
	HASH_FREE(table->hash_bucket_item_num);
	memset(table, 0xFE, sizeof(MESA_htable_inner_t)); /* ����֮ǰȫ���, ��ֹʹ��Ұָ�����, ����debug */
	HASH_FREE(table);

	return MESA_HTABLE_RET_OK;
}

#ifdef __cplusplus
}
#endif


