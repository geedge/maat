#ifndef _MESA_HTABLE_INTERNAL_H_
#define _MESA_HTABLE_INTERNAL_H_

#ifndef likely
#define likely(x) __builtin_expect(!!(x), 1)
#endif

#ifndef unlikely
#define unlikely(x) __builtin_expect(!!(x), 0)
#endif

typedef struct{
	char char_val;
	char __pad1;
	short short_val;
	int int_val;
	long long long_val;
	void *ptr_value;
	char __pad2[40];
}multi_thread_cache_align_t; /* ���߳�Ƶ������ȫ�ֱ���, ����Ҫ��֤64�ֽڶ��� */


int gtest_htable_old_api_simple(void);


#endif

